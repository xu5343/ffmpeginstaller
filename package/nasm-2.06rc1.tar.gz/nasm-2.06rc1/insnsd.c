/* This file auto-generated from insns.dat by insns.pl - don't edit it */

#include "nasm.h"
#include "insns.h"

static const struct itemplate instrux[] = {
    /*    0 */ {I_RESB, 1, {IMMEDIATE,0,0,0,0}, nasm_bytecodes+19033, IF_8086},
    /*    1 */ {I_AAA, 0, {0,0,0,0,0}, nasm_bytecodes+19631, IF_8086|IF_NOLONG},
    /*    2 */ {I_AAD, 0, {0,0,0,0,0}, nasm_bytecodes+18547, IF_8086|IF_NOLONG},
    /*    3 */ {I_AAD, 1, {IMMEDIATE,0,0,0,0}, nasm_bytecodes+18551, IF_8086|IF_SB|IF_NOLONG},
    /*    4 */ {I_AAM, 0, {0,0,0,0,0}, nasm_bytecodes+18555, IF_8086|IF_NOLONG},
    /*    5 */ {I_AAM, 1, {IMMEDIATE,0,0,0,0}, nasm_bytecodes+18559, IF_8086|IF_SB|IF_NOLONG},
    /*    6 */ {I_AAS, 0, {0,0,0,0,0}, nasm_bytecodes+19634, IF_8086|IF_NOLONG},
    /*    7 */ {I_ADC, 2, {MEMORY,REG8,0,0,0}, nasm_bytecodes+18563, IF_8086|IF_SM},
    /*    8 */ {I_ADC, 2, {REG8,REG8,0,0,0}, nasm_bytecodes+18563, IF_8086},
    /*    9 */ {I_ADC, 2, {MEMORY,REG16,0,0,0}, nasm_bytecodes+16672, IF_8086|IF_SM},
    /*   10 */ {I_ADC, 2, {REG16,REG16,0,0,0}, nasm_bytecodes+16672, IF_8086},
    /*   11 */ {I_ADC, 2, {MEMORY,REG32,0,0,0}, nasm_bytecodes+16677, IF_386|IF_SM},
    /*   12 */ {I_ADC, 2, {REG32,REG32,0,0,0}, nasm_bytecodes+16677, IF_386},
    /*   13 */ {I_ADC, 2, {MEMORY,REG64,0,0,0}, nasm_bytecodes+16682, IF_X64|IF_SM},
    /*   14 */ {I_ADC, 2, {REG64,REG64,0,0,0}, nasm_bytecodes+16682, IF_X64},
    /*   15 */ {I_ADC, 2, {REG8,MEMORY,0,0,0}, nasm_bytecodes+11174, IF_8086|IF_SM},
    /*   16 */ {I_ADC, 2, {REG8,REG8,0,0,0}, nasm_bytecodes+11174, IF_8086},
    /*   17 */ {I_ADC, 2, {REG16,MEMORY,0,0,0}, nasm_bytecodes+16687, IF_8086|IF_SM},
    /*   18 */ {I_ADC, 2, {REG16,REG16,0,0,0}, nasm_bytecodes+16687, IF_8086},
    /*   19 */ {I_ADC, 2, {REG32,MEMORY,0,0,0}, nasm_bytecodes+16692, IF_386|IF_SM},
    /*   20 */ {I_ADC, 2, {REG32,REG32,0,0,0}, nasm_bytecodes+16692, IF_386},
    /*   21 */ {I_ADC, 2, {REG64,MEMORY,0,0,0}, nasm_bytecodes+16697, IF_X64|IF_SM},
    /*   22 */ {I_ADC, 2, {REG64,REG64,0,0,0}, nasm_bytecodes+16697, IF_X64},
    /*   23 */ {I_ADC, 2, {RM_GPR|BITS16,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+13138, IF_8086},
    /*   24 */ {I_ADC, 2, {RM_GPR|BITS32,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+13144, IF_386},
    /*   25 */ {I_ADC, 2, {RM_GPR|BITS64,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+13150, IF_X64},
    /*   26 */ {I_ADC, 2, {REG_AL,IMMEDIATE,0,0,0}, nasm_bytecodes+18567, IF_8086|IF_SM},
    /*   27 */ {I_ADC, 2, {REG_AX,IMMEDIATE,0,0,0}, nasm_bytecodes+16702, IF_8086|IF_SM},
    /*   28 */ {I_ADC, 2, {REG_EAX,IMMEDIATE,0,0,0}, nasm_bytecodes+16707, IF_386|IF_SM},
    /*   29 */ {I_ADC, 2, {REG_RAX,IMMEDIATE,0,0,0}, nasm_bytecodes+16712, IF_X64|IF_SM},
    /*   30 */ {I_ADC, 2, {RM_GPR|BITS8,IMMEDIATE,0,0,0}, nasm_bytecodes+16717, IF_8086|IF_SM},
    /*   31 */ {I_ADC, 2, {RM_GPR|BITS16,IMMEDIATE,0,0,0}, nasm_bytecodes+13156, IF_8086|IF_SM},
    /*   32 */ {I_ADC, 2, {RM_GPR|BITS32,IMMEDIATE,0,0,0}, nasm_bytecodes+13162, IF_386|IF_SM},
    /*   33 */ {I_ADC, 2, {RM_GPR|BITS64,IMMEDIATE,0,0,0}, nasm_bytecodes+13168, IF_X64|IF_SM},
    /*   34 */ {I_ADC, 2, {MEMORY,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+16717, IF_8086|IF_SM},
    /*   35 */ {I_ADC, 2, {MEMORY,IMMEDIATE|BITS16,0,0,0}, nasm_bytecodes+13156, IF_8086|IF_SM},
    /*   36 */ {I_ADC, 2, {MEMORY,IMMEDIATE|BITS32,0,0,0}, nasm_bytecodes+13162, IF_386|IF_SM},
    /*   37 */ {I_ADD, 2, {MEMORY,REG8,0,0,0}, nasm_bytecodes+18571, IF_8086|IF_SM},
    /*   38 */ {I_ADD, 2, {REG8,REG8,0,0,0}, nasm_bytecodes+18571, IF_8086},
    /*   39 */ {I_ADD, 2, {MEMORY,REG16,0,0,0}, nasm_bytecodes+16722, IF_8086|IF_SM},
    /*   40 */ {I_ADD, 2, {REG16,REG16,0,0,0}, nasm_bytecodes+16722, IF_8086},
    /*   41 */ {I_ADD, 2, {MEMORY,REG32,0,0,0}, nasm_bytecodes+16727, IF_386|IF_SM},
    /*   42 */ {I_ADD, 2, {REG32,REG32,0,0,0}, nasm_bytecodes+16727, IF_386},
    /*   43 */ {I_ADD, 2, {MEMORY,REG64,0,0,0}, nasm_bytecodes+16732, IF_X64|IF_SM},
    /*   44 */ {I_ADD, 2, {REG64,REG64,0,0,0}, nasm_bytecodes+16732, IF_X64},
    /*   45 */ {I_ADD, 2, {REG8,MEMORY,0,0,0}, nasm_bytecodes+11825, IF_8086|IF_SM},
    /*   46 */ {I_ADD, 2, {REG8,REG8,0,0,0}, nasm_bytecodes+11825, IF_8086},
    /*   47 */ {I_ADD, 2, {REG16,MEMORY,0,0,0}, nasm_bytecodes+16737, IF_8086|IF_SM},
    /*   48 */ {I_ADD, 2, {REG16,REG16,0,0,0}, nasm_bytecodes+16737, IF_8086},
    /*   49 */ {I_ADD, 2, {REG32,MEMORY,0,0,0}, nasm_bytecodes+16742, IF_386|IF_SM},
    /*   50 */ {I_ADD, 2, {REG32,REG32,0,0,0}, nasm_bytecodes+16742, IF_386},
    /*   51 */ {I_ADD, 2, {REG64,MEMORY,0,0,0}, nasm_bytecodes+16747, IF_X64|IF_SM},
    /*   52 */ {I_ADD, 2, {REG64,REG64,0,0,0}, nasm_bytecodes+16747, IF_X64},
    /*   53 */ {I_ADD, 2, {RM_GPR|BITS16,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+13174, IF_8086},
    /*   54 */ {I_ADD, 2, {RM_GPR|BITS32,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+13180, IF_386},
    /*   55 */ {I_ADD, 2, {RM_GPR|BITS64,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+13186, IF_X64},
    /*   56 */ {I_ADD, 2, {REG_AL,IMMEDIATE,0,0,0}, nasm_bytecodes+18575, IF_8086|IF_SM},
    /*   57 */ {I_ADD, 2, {REG_AX,IMMEDIATE,0,0,0}, nasm_bytecodes+16752, IF_8086|IF_SM},
    /*   58 */ {I_ADD, 2, {REG_EAX,IMMEDIATE,0,0,0}, nasm_bytecodes+16757, IF_386|IF_SM},
    /*   59 */ {I_ADD, 2, {REG_RAX,IMMEDIATE,0,0,0}, nasm_bytecodes+16762, IF_X64|IF_SM},
    /*   60 */ {I_ADD, 2, {RM_GPR|BITS8,IMMEDIATE,0,0,0}, nasm_bytecodes+16767, IF_8086|IF_SM},
    /*   61 */ {I_ADD, 2, {RM_GPR|BITS16,IMMEDIATE,0,0,0}, nasm_bytecodes+13192, IF_8086|IF_SM},
    /*   62 */ {I_ADD, 2, {RM_GPR|BITS32,IMMEDIATE,0,0,0}, nasm_bytecodes+13198, IF_386|IF_SM},
    /*   63 */ {I_ADD, 2, {RM_GPR|BITS64,IMMEDIATE,0,0,0}, nasm_bytecodes+13204, IF_X64|IF_SM},
    /*   64 */ {I_ADD, 2, {MEMORY,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+16767, IF_8086|IF_SM},
    /*   65 */ {I_ADD, 2, {MEMORY,IMMEDIATE|BITS16,0,0,0}, nasm_bytecodes+13192, IF_8086|IF_SM},
    /*   66 */ {I_ADD, 2, {MEMORY,IMMEDIATE|BITS32,0,0,0}, nasm_bytecodes+13198, IF_386|IF_SM},
    /*   67 */ {I_AND, 2, {MEMORY,REG8,0,0,0}, nasm_bytecodes+18579, IF_8086|IF_SM},
    /*   68 */ {I_AND, 2, {REG8,REG8,0,0,0}, nasm_bytecodes+18579, IF_8086},
    /*   69 */ {I_AND, 2, {MEMORY,REG16,0,0,0}, nasm_bytecodes+16772, IF_8086|IF_SM},
    /*   70 */ {I_AND, 2, {REG16,REG16,0,0,0}, nasm_bytecodes+16772, IF_8086},
    /*   71 */ {I_AND, 2, {MEMORY,REG32,0,0,0}, nasm_bytecodes+16777, IF_386|IF_SM},
    /*   72 */ {I_AND, 2, {REG32,REG32,0,0,0}, nasm_bytecodes+16777, IF_386},
    /*   73 */ {I_AND, 2, {MEMORY,REG64,0,0,0}, nasm_bytecodes+16782, IF_X64|IF_SM},
    /*   74 */ {I_AND, 2, {REG64,REG64,0,0,0}, nasm_bytecodes+16782, IF_X64},
    /*   75 */ {I_AND, 2, {REG8,MEMORY,0,0,0}, nasm_bytecodes+12112, IF_8086|IF_SM},
    /*   76 */ {I_AND, 2, {REG8,REG8,0,0,0}, nasm_bytecodes+12112, IF_8086},
    /*   77 */ {I_AND, 2, {REG16,MEMORY,0,0,0}, nasm_bytecodes+16787, IF_8086|IF_SM},
    /*   78 */ {I_AND, 2, {REG16,REG16,0,0,0}, nasm_bytecodes+16787, IF_8086},
    /*   79 */ {I_AND, 2, {REG32,MEMORY,0,0,0}, nasm_bytecodes+16792, IF_386|IF_SM},
    /*   80 */ {I_AND, 2, {REG32,REG32,0,0,0}, nasm_bytecodes+16792, IF_386},
    /*   81 */ {I_AND, 2, {REG64,MEMORY,0,0,0}, nasm_bytecodes+16797, IF_X64|IF_SM},
    /*   82 */ {I_AND, 2, {REG64,REG64,0,0,0}, nasm_bytecodes+16797, IF_X64},
    /*   83 */ {I_AND, 2, {RM_GPR|BITS16,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+13210, IF_8086},
    /*   84 */ {I_AND, 2, {RM_GPR|BITS32,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+13216, IF_386},
    /*   85 */ {I_AND, 2, {RM_GPR|BITS64,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+13222, IF_X64},
    /*   86 */ {I_AND, 2, {REG_AL,IMMEDIATE,0,0,0}, nasm_bytecodes+18583, IF_8086|IF_SM},
    /*   87 */ {I_AND, 2, {REG_AX,IMMEDIATE,0,0,0}, nasm_bytecodes+16802, IF_8086|IF_SM},
    /*   88 */ {I_AND, 2, {REG_EAX,IMMEDIATE,0,0,0}, nasm_bytecodes+16807, IF_386|IF_SM},
    /*   89 */ {I_AND, 2, {REG_RAX,IMMEDIATE,0,0,0}, nasm_bytecodes+16812, IF_X64|IF_SM},
    /*   90 */ {I_AND, 2, {RM_GPR|BITS8,IMMEDIATE,0,0,0}, nasm_bytecodes+16817, IF_8086|IF_SM},
    /*   91 */ {I_AND, 2, {RM_GPR|BITS16,IMMEDIATE,0,0,0}, nasm_bytecodes+13228, IF_8086|IF_SM},
    /*   92 */ {I_AND, 2, {RM_GPR|BITS32,IMMEDIATE,0,0,0}, nasm_bytecodes+13234, IF_386|IF_SM},
    /*   93 */ {I_AND, 2, {RM_GPR|BITS64,IMMEDIATE,0,0,0}, nasm_bytecodes+13240, IF_X64|IF_SM},
    /*   94 */ {I_AND, 2, {MEMORY,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+16817, IF_8086|IF_SM},
    /*   95 */ {I_AND, 2, {MEMORY,IMMEDIATE|BITS16,0,0,0}, nasm_bytecodes+13228, IF_8086|IF_SM},
    /*   96 */ {I_AND, 2, {MEMORY,IMMEDIATE|BITS32,0,0,0}, nasm_bytecodes+13234, IF_386|IF_SM},
    /*   97 */ {I_ARPL, 2, {MEMORY,REG16,0,0,0}, nasm_bytecodes+18587, IF_286|IF_PROT|IF_SM|IF_NOLONG},
    /*   98 */ {I_ARPL, 2, {REG16,REG16,0,0,0}, nasm_bytecodes+18587, IF_286|IF_PROT|IF_NOLONG},
    /*   99 */ {I_BOUND, 2, {REG16,MEMORY,0,0,0}, nasm_bytecodes+16822, IF_186|IF_NOLONG},
    /*  100 */ {I_BOUND, 2, {REG32,MEMORY,0,0,0}, nasm_bytecodes+16827, IF_386|IF_NOLONG},
    /*  101 */ {I_BSF, 2, {REG16,MEMORY,0,0,0}, nasm_bytecodes+13246, IF_386|IF_SM},
    /*  102 */ {I_BSF, 2, {REG16,REG16,0,0,0}, nasm_bytecodes+13246, IF_386},
    /*  103 */ {I_BSF, 2, {REG32,MEMORY,0,0,0}, nasm_bytecodes+13252, IF_386|IF_SM},
    /*  104 */ {I_BSF, 2, {REG32,REG32,0,0,0}, nasm_bytecodes+13252, IF_386},
    /*  105 */ {I_BSF, 2, {REG64,MEMORY,0,0,0}, nasm_bytecodes+13258, IF_X64|IF_SM},
    /*  106 */ {I_BSF, 2, {REG64,REG64,0,0,0}, nasm_bytecodes+13258, IF_X64},
    /*  107 */ {I_BSR, 2, {REG16,MEMORY,0,0,0}, nasm_bytecodes+13264, IF_386|IF_SM},
    /*  108 */ {I_BSR, 2, {REG16,REG16,0,0,0}, nasm_bytecodes+13264, IF_386},
    /*  109 */ {I_BSR, 2, {REG32,MEMORY,0,0,0}, nasm_bytecodes+13270, IF_386|IF_SM},
    /*  110 */ {I_BSR, 2, {REG32,REG32,0,0,0}, nasm_bytecodes+13270, IF_386},
    /*  111 */ {I_BSR, 2, {REG64,MEMORY,0,0,0}, nasm_bytecodes+13276, IF_X64|IF_SM},
    /*  112 */ {I_BSR, 2, {REG64,REG64,0,0,0}, nasm_bytecodes+13276, IF_X64},
    /*  113 */ {I_BSWAP, 1, {REG32,0,0,0,0}, nasm_bytecodes+13282, IF_486},
    /*  114 */ {I_BSWAP, 1, {REG64,0,0,0,0}, nasm_bytecodes+13288, IF_X64},
    /*  115 */ {I_BT, 2, {MEMORY,REG16,0,0,0}, nasm_bytecodes+13294, IF_386|IF_SM},
    /*  116 */ {I_BT, 2, {REG16,REG16,0,0,0}, nasm_bytecodes+13294, IF_386},
    /*  117 */ {I_BT, 2, {MEMORY,REG32,0,0,0}, nasm_bytecodes+13300, IF_386|IF_SM},
    /*  118 */ {I_BT, 2, {REG32,REG32,0,0,0}, nasm_bytecodes+13300, IF_386},
    /*  119 */ {I_BT, 2, {MEMORY,REG64,0,0,0}, nasm_bytecodes+13306, IF_X64|IF_SM},
    /*  120 */ {I_BT, 2, {REG64,REG64,0,0,0}, nasm_bytecodes+13306, IF_X64},
    /*  121 */ {I_BT, 2, {RM_GPR|BITS16,IMMEDIATE,0,0,0}, nasm_bytecodes+7230, IF_386|IF_SB},
    /*  122 */ {I_BT, 2, {RM_GPR|BITS32,IMMEDIATE,0,0,0}, nasm_bytecodes+7237, IF_386|IF_SB},
    /*  123 */ {I_BT, 2, {RM_GPR|BITS64,IMMEDIATE,0,0,0}, nasm_bytecodes+7244, IF_X64|IF_SB},
    /*  124 */ {I_BTC, 2, {MEMORY,REG16,0,0,0}, nasm_bytecodes+13312, IF_386|IF_SM},
    /*  125 */ {I_BTC, 2, {REG16,REG16,0,0,0}, nasm_bytecodes+13312, IF_386},
    /*  126 */ {I_BTC, 2, {MEMORY,REG32,0,0,0}, nasm_bytecodes+13318, IF_386|IF_SM},
    /*  127 */ {I_BTC, 2, {REG32,REG32,0,0,0}, nasm_bytecodes+13318, IF_386},
    /*  128 */ {I_BTC, 2, {MEMORY,REG64,0,0,0}, nasm_bytecodes+13324, IF_X64|IF_SM},
    /*  129 */ {I_BTC, 2, {REG64,REG64,0,0,0}, nasm_bytecodes+13324, IF_X64},
    /*  130 */ {I_BTC, 2, {RM_GPR|BITS16,IMMEDIATE,0,0,0}, nasm_bytecodes+7251, IF_386|IF_SB},
    /*  131 */ {I_BTC, 2, {RM_GPR|BITS32,IMMEDIATE,0,0,0}, nasm_bytecodes+7258, IF_386|IF_SB},
    /*  132 */ {I_BTC, 2, {RM_GPR|BITS64,IMMEDIATE,0,0,0}, nasm_bytecodes+7265, IF_X64|IF_SB},
    /*  133 */ {I_BTR, 2, {MEMORY,REG16,0,0,0}, nasm_bytecodes+13330, IF_386|IF_SM},
    /*  134 */ {I_BTR, 2, {REG16,REG16,0,0,0}, nasm_bytecodes+13330, IF_386},
    /*  135 */ {I_BTR, 2, {MEMORY,REG32,0,0,0}, nasm_bytecodes+13336, IF_386|IF_SM},
    /*  136 */ {I_BTR, 2, {REG32,REG32,0,0,0}, nasm_bytecodes+13336, IF_386},
    /*  137 */ {I_BTR, 2, {MEMORY,REG64,0,0,0}, nasm_bytecodes+13342, IF_X64|IF_SM},
    /*  138 */ {I_BTR, 2, {REG64,REG64,0,0,0}, nasm_bytecodes+13342, IF_X64},
    /*  139 */ {I_BTR, 2, {RM_GPR|BITS16,IMMEDIATE,0,0,0}, nasm_bytecodes+7272, IF_386|IF_SB},
    /*  140 */ {I_BTR, 2, {RM_GPR|BITS32,IMMEDIATE,0,0,0}, nasm_bytecodes+7279, IF_386|IF_SB},
    /*  141 */ {I_BTR, 2, {RM_GPR|BITS64,IMMEDIATE,0,0,0}, nasm_bytecodes+7286, IF_X64|IF_SB},
    /*  142 */ {I_BTS, 2, {MEMORY,REG16,0,0,0}, nasm_bytecodes+13348, IF_386|IF_SM},
    /*  143 */ {I_BTS, 2, {REG16,REG16,0,0,0}, nasm_bytecodes+13348, IF_386},
    /*  144 */ {I_BTS, 2, {MEMORY,REG32,0,0,0}, nasm_bytecodes+13354, IF_386|IF_SM},
    /*  145 */ {I_BTS, 2, {REG32,REG32,0,0,0}, nasm_bytecodes+13354, IF_386},
    /*  146 */ {I_BTS, 2, {MEMORY,REG64,0,0,0}, nasm_bytecodes+13360, IF_X64|IF_SM},
    /*  147 */ {I_BTS, 2, {REG64,REG64,0,0,0}, nasm_bytecodes+13360, IF_X64},
    /*  148 */ {I_BTS, 2, {RM_GPR|BITS16,IMMEDIATE,0,0,0}, nasm_bytecodes+7293, IF_386|IF_SB},
    /*  149 */ {I_BTS, 2, {RM_GPR|BITS32,IMMEDIATE,0,0,0}, nasm_bytecodes+7300, IF_386|IF_SB},
    /*  150 */ {I_BTS, 2, {RM_GPR|BITS64,IMMEDIATE,0,0,0}, nasm_bytecodes+7307, IF_X64|IF_SB},
    /*  151 */ {I_CALL, 1, {IMMEDIATE,0,0,0,0}, nasm_bytecodes+16832, IF_8086},
    /*  152 */ {I_CALL, 1, {IMMEDIATE|NEAR,0,0,0,0}, nasm_bytecodes+16832, IF_8086},
    /*  153 */ {I_CALL, 1, {IMMEDIATE|BITS16,0,0,0,0}, nasm_bytecodes+16837, IF_8086},
    /*  154 */ {I_CALL, 1, {IMMEDIATE|BITS16|NEAR,0,0,0,0}, nasm_bytecodes+16837, IF_8086},
    /*  155 */ {I_CALL, 1, {IMMEDIATE|BITS32,0,0,0,0}, nasm_bytecodes+16842, IF_386},
    /*  156 */ {I_CALL, 1, {IMMEDIATE|BITS32|NEAR,0,0,0,0}, nasm_bytecodes+16842, IF_386},
    /*  157 */ {I_CALL, 2, {IMMEDIATE|COLON,IMMEDIATE,0,0,0}, nasm_bytecodes+13384, IF_8086|IF_NOLONG},
    /*  158 */ {I_CALL, 2, {IMMEDIATE|BITS16|COLON,IMMEDIATE,0,0,0}, nasm_bytecodes+13390, IF_8086|IF_NOLONG},
    /*  159 */ {I_CALL, 2, {IMMEDIATE|COLON,IMMEDIATE|BITS16,0,0,0}, nasm_bytecodes+13390, IF_8086|IF_NOLONG},
    /*  160 */ {I_CALL, 2, {IMMEDIATE|BITS32|COLON,IMMEDIATE,0,0,0}, nasm_bytecodes+13396, IF_386|IF_NOLONG},
    /*  161 */ {I_CALL, 2, {IMMEDIATE|COLON,IMMEDIATE|BITS32,0,0,0}, nasm_bytecodes+13396, IF_386|IF_NOLONG},
    /*  162 */ {I_CALL, 1, {MEMORY|FAR,0,0,0,0}, nasm_bytecodes+16847, IF_8086|IF_NOLONG},
    /*  163 */ {I_CALL, 1, {MEMORY|FAR,0,0,0,0}, nasm_bytecodes+16852, IF_X64},
    /*  164 */ {I_CALL, 1, {MEMORY|BITS16|FAR,0,0,0,0}, nasm_bytecodes+16857, IF_8086},
    /*  165 */ {I_CALL, 1, {MEMORY|BITS32|FAR,0,0,0,0}, nasm_bytecodes+16862, IF_386},
    /*  166 */ {I_CALL, 1, {MEMORY|BITS64|FAR,0,0,0,0}, nasm_bytecodes+16852, IF_X64},
    /*  167 */ {I_CALL, 1, {MEMORY|NEAR,0,0,0,0}, nasm_bytecodes+16867, IF_8086},
    /*  168 */ {I_CALL, 1, {MEMORY|BITS16|NEAR,0,0,0,0}, nasm_bytecodes+16872, IF_8086},
    /*  169 */ {I_CALL, 1, {MEMORY|BITS32|NEAR,0,0,0,0}, nasm_bytecodes+16877, IF_386|IF_NOLONG},
    /*  170 */ {I_CALL, 1, {MEMORY|BITS64|NEAR,0,0,0,0}, nasm_bytecodes+16882, IF_X64},
    /*  171 */ {I_CALL, 1, {REG16,0,0,0,0}, nasm_bytecodes+16872, IF_8086},
    /*  172 */ {I_CALL, 1, {REG32,0,0,0,0}, nasm_bytecodes+16877, IF_386|IF_NOLONG},
    /*  173 */ {I_CALL, 1, {REG64,0,0,0,0}, nasm_bytecodes+16887, IF_X64},
    /*  174 */ {I_CALL, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+16867, IF_8086},
    /*  175 */ {I_CALL, 1, {MEMORY|BITS16,0,0,0,0}, nasm_bytecodes+16872, IF_8086},
    /*  176 */ {I_CALL, 1, {MEMORY|BITS32,0,0,0,0}, nasm_bytecodes+16877, IF_386|IF_NOLONG},
    /*  177 */ {I_CALL, 1, {MEMORY|BITS64,0,0,0,0}, nasm_bytecodes+16887, IF_X64},
    /*  178 */ {I_CBW, 0, {0,0,0,0,0}, nasm_bytecodes+18599, IF_8086},
    /*  179 */ {I_CDQ, 0, {0,0,0,0,0}, nasm_bytecodes+18603, IF_386},
    /*  180 */ {I_CDQE, 0, {0,0,0,0,0}, nasm_bytecodes+18607, IF_X64},
    /*  181 */ {I_CLC, 0, {0,0,0,0,0}, nasm_bytecodes+18319, IF_8086},
    /*  182 */ {I_CLD, 0, {0,0,0,0,0}, nasm_bytecodes+19637, IF_8086},
    /*  183 */ {I_CLGI, 0, {0,0,0,0,0}, nasm_bytecodes+16892, IF_X64|IF_AMD},
    /*  184 */ {I_CLI, 0, {0,0,0,0,0}, nasm_bytecodes+19640, IF_8086},
    /*  185 */ {I_CLTS, 0, {0,0,0,0,0}, nasm_bytecodes+18611, IF_286|IF_PRIV},
    /*  186 */ {I_CMC, 0, {0,0,0,0,0}, nasm_bytecodes+19643, IF_8086},
    /*  187 */ {I_CMP, 2, {MEMORY,REG8,0,0,0}, nasm_bytecodes+18615, IF_8086|IF_SM},
    /*  188 */ {I_CMP, 2, {REG8,REG8,0,0,0}, nasm_bytecodes+18615, IF_8086},
    /*  189 */ {I_CMP, 2, {MEMORY,REG16,0,0,0}, nasm_bytecodes+16897, IF_8086|IF_SM},
    /*  190 */ {I_CMP, 2, {REG16,REG16,0,0,0}, nasm_bytecodes+16897, IF_8086},
    /*  191 */ {I_CMP, 2, {MEMORY,REG32,0,0,0}, nasm_bytecodes+16902, IF_386|IF_SM},
    /*  192 */ {I_CMP, 2, {REG32,REG32,0,0,0}, nasm_bytecodes+16902, IF_386},
    /*  193 */ {I_CMP, 2, {MEMORY,REG64,0,0,0}, nasm_bytecodes+16907, IF_X64|IF_SM},
    /*  194 */ {I_CMP, 2, {REG64,REG64,0,0,0}, nasm_bytecodes+16907, IF_X64},
    /*  195 */ {I_CMP, 2, {REG8,MEMORY,0,0,0}, nasm_bytecodes+12070, IF_8086|IF_SM},
    /*  196 */ {I_CMP, 2, {REG8,REG8,0,0,0}, nasm_bytecodes+12070, IF_8086},
    /*  197 */ {I_CMP, 2, {REG16,MEMORY,0,0,0}, nasm_bytecodes+16912, IF_8086|IF_SM},
    /*  198 */ {I_CMP, 2, {REG16,REG16,0,0,0}, nasm_bytecodes+16912, IF_8086},
    /*  199 */ {I_CMP, 2, {REG32,MEMORY,0,0,0}, nasm_bytecodes+16917, IF_386|IF_SM},
    /*  200 */ {I_CMP, 2, {REG32,REG32,0,0,0}, nasm_bytecodes+16917, IF_386},
    /*  201 */ {I_CMP, 2, {REG64,MEMORY,0,0,0}, nasm_bytecodes+16922, IF_X64|IF_SM},
    /*  202 */ {I_CMP, 2, {REG64,REG64,0,0,0}, nasm_bytecodes+16922, IF_X64},
    /*  203 */ {I_CMP, 2, {RM_GPR|BITS16,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+13402, IF_8086},
    /*  204 */ {I_CMP, 2, {RM_GPR|BITS32,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+13408, IF_386},
    /*  205 */ {I_CMP, 2, {RM_GPR|BITS64,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+13414, IF_X64},
    /*  206 */ {I_CMP, 2, {REG_AL,IMMEDIATE,0,0,0}, nasm_bytecodes+18619, IF_8086|IF_SM},
    /*  207 */ {I_CMP, 2, {REG_AX,IMMEDIATE,0,0,0}, nasm_bytecodes+16927, IF_8086|IF_SM},
    /*  208 */ {I_CMP, 2, {REG_EAX,IMMEDIATE,0,0,0}, nasm_bytecodes+16932, IF_386|IF_SM},
    /*  209 */ {I_CMP, 2, {REG_RAX,IMMEDIATE,0,0,0}, nasm_bytecodes+16937, IF_X64|IF_SM},
    /*  210 */ {I_CMP, 2, {RM_GPR|BITS8,IMMEDIATE,0,0,0}, nasm_bytecodes+16942, IF_8086|IF_SM},
    /*  211 */ {I_CMP, 2, {RM_GPR|BITS16,IMMEDIATE,0,0,0}, nasm_bytecodes+13420, IF_8086|IF_SM},
    /*  212 */ {I_CMP, 2, {RM_GPR|BITS32,IMMEDIATE,0,0,0}, nasm_bytecodes+13426, IF_386|IF_SM},
    /*  213 */ {I_CMP, 2, {RM_GPR|BITS64,IMMEDIATE,0,0,0}, nasm_bytecodes+13432, IF_X64|IF_SM},
    /*  214 */ {I_CMP, 2, {MEMORY,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+16942, IF_8086|IF_SM},
    /*  215 */ {I_CMP, 2, {MEMORY,IMMEDIATE|BITS16,0,0,0}, nasm_bytecodes+13420, IF_8086|IF_SM},
    /*  216 */ {I_CMP, 2, {MEMORY,IMMEDIATE|BITS32,0,0,0}, nasm_bytecodes+13426, IF_386|IF_SM},
    /*  217 */ {I_CMPSB, 0, {0,0,0,0,0}, nasm_bytecodes+18623, IF_8086},
    /*  218 */ {I_CMPSD, 0, {0,0,0,0,0}, nasm_bytecodes+16947, IF_386},
    /*  219 */ {I_CMPSQ, 0, {0,0,0,0,0}, nasm_bytecodes+16952, IF_X64},
    /*  220 */ {I_CMPSW, 0, {0,0,0,0,0}, nasm_bytecodes+16957, IF_8086},
    /*  221 */ {I_CMPXCHG, 2, {MEMORY,REG8,0,0,0}, nasm_bytecodes+16962, IF_PENT|IF_SM},
    /*  222 */ {I_CMPXCHG, 2, {REG8,REG8,0,0,0}, nasm_bytecodes+16962, IF_PENT},
    /*  223 */ {I_CMPXCHG, 2, {MEMORY,REG16,0,0,0}, nasm_bytecodes+13438, IF_PENT|IF_SM},
    /*  224 */ {I_CMPXCHG, 2, {REG16,REG16,0,0,0}, nasm_bytecodes+13438, IF_PENT},
    /*  225 */ {I_CMPXCHG, 2, {MEMORY,REG32,0,0,0}, nasm_bytecodes+13444, IF_PENT|IF_SM},
    /*  226 */ {I_CMPXCHG, 2, {REG32,REG32,0,0,0}, nasm_bytecodes+13444, IF_PENT},
    /*  227 */ {I_CMPXCHG, 2, {MEMORY,REG64,0,0,0}, nasm_bytecodes+13450, IF_X64|IF_SM},
    /*  228 */ {I_CMPXCHG, 2, {REG64,REG64,0,0,0}, nasm_bytecodes+13450, IF_X64},
    /*  229 */ {I_CMPXCHG8B, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+13469, IF_PENT},
    /*  230 */ {I_CMPXCHG16B, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+13468, IF_X64},
    /*  231 */ {I_CPUID, 0, {0,0,0,0,0}, nasm_bytecodes+18627, IF_PENT},
    /*  232 */ {I_CPU_READ, 0, {0,0,0,0,0}, nasm_bytecodes+18631, IF_PENT|IF_CYRIX},
    /*  233 */ {I_CPU_WRITE, 0, {0,0,0,0,0}, nasm_bytecodes+18635, IF_PENT|IF_CYRIX},
    /*  234 */ {I_CQO, 0, {0,0,0,0,0}, nasm_bytecodes+18639, IF_X64},
    /*  235 */ {I_CWD, 0, {0,0,0,0,0}, nasm_bytecodes+18643, IF_8086},
    /*  236 */ {I_CWDE, 0, {0,0,0,0,0}, nasm_bytecodes+18647, IF_386},
    /*  237 */ {I_DAA, 0, {0,0,0,0,0}, nasm_bytecodes+19646, IF_8086|IF_NOLONG},
    /*  238 */ {I_DAS, 0, {0,0,0,0,0}, nasm_bytecodes+19649, IF_8086|IF_NOLONG},
    /*  239 */ {I_DEC, 1, {REG16,0,0,0,0}, nasm_bytecodes+18651, IF_8086|IF_NOLONG},
    /*  240 */ {I_DEC, 1, {REG32,0,0,0,0}, nasm_bytecodes+18655, IF_386|IF_NOLONG},
    /*  241 */ {I_DEC, 1, {RM_GPR|BITS8,0,0,0,0}, nasm_bytecodes+18659, IF_8086},
    /*  242 */ {I_DEC, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16972, IF_8086},
    /*  243 */ {I_DEC, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16977, IF_386},
    /*  244 */ {I_DEC, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16982, IF_X64},
    /*  245 */ {I_DIV, 1, {RM_GPR|BITS8,0,0,0,0}, nasm_bytecodes+18663, IF_8086},
    /*  246 */ {I_DIV, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16987, IF_8086},
    /*  247 */ {I_DIV, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16992, IF_386},
    /*  248 */ {I_DIV, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16997, IF_X64},
    /*  249 */ {I_DMINT, 0, {0,0,0,0,0}, nasm_bytecodes+18667, IF_P6|IF_CYRIX},
    /*  250 */ {I_EMMS, 0, {0,0,0,0,0}, nasm_bytecodes+18671, IF_PENT|IF_MMX},
    /*  251 */ {I_ENTER, 2, {IMMEDIATE,IMMEDIATE,0,0,0}, nasm_bytecodes+17002, IF_186},
    /*  252 */ {I_EQU, 1, {IMMEDIATE,0,0,0,0}, nasm_bytecodes+5948, IF_8086},
    /*  253 */ {I_EQU, 2, {IMMEDIATE|COLON,IMMEDIATE,0,0,0}, nasm_bytecodes+5948, IF_8086},
    /*  254 */ {I_F2XM1, 0, {0,0,0,0,0}, nasm_bytecodes+18675, IF_8086|IF_FPU},
    /*  255 */ {I_FABS, 0, {0,0,0,0,0}, nasm_bytecodes+18679, IF_8086|IF_FPU},
    /*  256 */ {I_FADD, 1, {MEMORY|BITS32,0,0,0,0}, nasm_bytecodes+18683, IF_8086|IF_FPU},
    /*  257 */ {I_FADD, 1, {MEMORY|BITS64,0,0,0,0}, nasm_bytecodes+18687, IF_8086|IF_FPU},
    /*  258 */ {I_FADD, 1, {FPUREG|TO,0,0,0,0}, nasm_bytecodes+17007, IF_8086|IF_FPU},
    /*  259 */ {I_FADD, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+17012, IF_8086|IF_FPU},
    /*  260 */ {I_FADD, 2, {FPUREG,FPU0,0,0,0}, nasm_bytecodes+17007, IF_8086|IF_FPU},
    /*  261 */ {I_FADD, 2, {FPU0,FPUREG,0,0,0}, nasm_bytecodes+17017, IF_8086|IF_FPU},
    /*  262 */ {I_FADDP, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+17022, IF_8086|IF_FPU},
    /*  263 */ {I_FADDP, 2, {FPUREG,FPU0,0,0,0}, nasm_bytecodes+17022, IF_8086|IF_FPU},
    /*  264 */ {I_FBLD, 1, {MEMORY|BITS80,0,0,0,0}, nasm_bytecodes+18695, IF_8086|IF_FPU},
    /*  265 */ {I_FBLD, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+18695, IF_8086|IF_FPU},
    /*  266 */ {I_FBSTP, 1, {MEMORY|BITS80,0,0,0,0}, nasm_bytecodes+18699, IF_8086|IF_FPU},
    /*  267 */ {I_FBSTP, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+18699, IF_8086|IF_FPU},
    /*  268 */ {I_FCHS, 0, {0,0,0,0,0}, nasm_bytecodes+18703, IF_8086|IF_FPU},
    /*  269 */ {I_FCLEX, 0, {0,0,0,0,0}, nasm_bytecodes+17027, IF_8086|IF_FPU},
    /*  270 */ {I_FCMOVB, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+17032, IF_P6|IF_FPU},
    /*  271 */ {I_FCMOVB, 2, {FPU0,FPUREG,0,0,0}, nasm_bytecodes+17037, IF_P6|IF_FPU},
    /*  272 */ {I_FCMOVBE, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+17042, IF_P6|IF_FPU},
    /*  273 */ {I_FCMOVBE, 2, {FPU0,FPUREG,0,0,0}, nasm_bytecodes+17047, IF_P6|IF_FPU},
    /*  274 */ {I_FCMOVE, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+17052, IF_P6|IF_FPU},
    /*  275 */ {I_FCMOVE, 2, {FPU0,FPUREG,0,0,0}, nasm_bytecodes+17057, IF_P6|IF_FPU},
    /*  276 */ {I_FCMOVNB, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+17062, IF_P6|IF_FPU},
    /*  277 */ {I_FCMOVNB, 2, {FPU0,FPUREG,0,0,0}, nasm_bytecodes+17067, IF_P6|IF_FPU},
    /*  278 */ {I_FCMOVNBE, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+17072, IF_P6|IF_FPU},
    /*  279 */ {I_FCMOVNBE, 2, {FPU0,FPUREG,0,0,0}, nasm_bytecodes+17077, IF_P6|IF_FPU},
    /*  280 */ {I_FCMOVNE, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+17082, IF_P6|IF_FPU},
    /*  281 */ {I_FCMOVNE, 2, {FPU0,FPUREG,0,0,0}, nasm_bytecodes+17087, IF_P6|IF_FPU},
    /*  282 */ {I_FCMOVNU, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+17092, IF_P6|IF_FPU},
    /*  283 */ {I_FCMOVNU, 2, {FPU0,FPUREG,0,0,0}, nasm_bytecodes+17097, IF_P6|IF_FPU},
    /*  284 */ {I_FCMOVU, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+17102, IF_P6|IF_FPU},
    /*  285 */ {I_FCMOVU, 2, {FPU0,FPUREG,0,0,0}, nasm_bytecodes+17107, IF_P6|IF_FPU},
    /*  286 */ {I_FCOM, 1, {MEMORY|BITS32,0,0,0,0}, nasm_bytecodes+18739, IF_8086|IF_FPU},
    /*  287 */ {I_FCOM, 1, {MEMORY|BITS64,0,0,0,0}, nasm_bytecodes+18743, IF_8086|IF_FPU},
    /*  288 */ {I_FCOM, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+17112, IF_8086|IF_FPU},
    /*  289 */ {I_FCOM, 2, {FPU0,FPUREG,0,0,0}, nasm_bytecodes+17117, IF_8086|IF_FPU},
    /*  290 */ {I_FCOMI, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+17122, IF_P6|IF_FPU},
    /*  291 */ {I_FCOMI, 2, {FPU0,FPUREG,0,0,0}, nasm_bytecodes+17127, IF_P6|IF_FPU},
    /*  292 */ {I_FCOMIP, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+17132, IF_P6|IF_FPU},
    /*  293 */ {I_FCOMIP, 2, {FPU0,FPUREG,0,0,0}, nasm_bytecodes+17137, IF_P6|IF_FPU},
    /*  294 */ {I_FCOMP, 1, {MEMORY|BITS32,0,0,0,0}, nasm_bytecodes+18759, IF_8086|IF_FPU},
    /*  295 */ {I_FCOMP, 1, {MEMORY|BITS64,0,0,0,0}, nasm_bytecodes+18763, IF_8086|IF_FPU},
    /*  296 */ {I_FCOMP, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+17142, IF_8086|IF_FPU},
    /*  297 */ {I_FCOMP, 2, {FPU0,FPUREG,0,0,0}, nasm_bytecodes+17147, IF_8086|IF_FPU},
    /*  298 */ {I_FCOMPP, 0, {0,0,0,0,0}, nasm_bytecodes+18771, IF_8086|IF_FPU},
    /*  299 */ {I_FCOS, 0, {0,0,0,0,0}, nasm_bytecodes+18775, IF_386|IF_FPU},
    /*  300 */ {I_FDECSTP, 0, {0,0,0,0,0}, nasm_bytecodes+18779, IF_8086|IF_FPU},
    /*  301 */ {I_FDISI, 0, {0,0,0,0,0}, nasm_bytecodes+17152, IF_8086|IF_FPU},
    /*  302 */ {I_FDIV, 1, {MEMORY|BITS32,0,0,0,0}, nasm_bytecodes+18783, IF_8086|IF_FPU},
    /*  303 */ {I_FDIV, 1, {MEMORY|BITS64,0,0,0,0}, nasm_bytecodes+18787, IF_8086|IF_FPU},
    /*  304 */ {I_FDIV, 1, {FPUREG|TO,0,0,0,0}, nasm_bytecodes+17157, IF_8086|IF_FPU},
    /*  305 */ {I_FDIV, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+17162, IF_8086|IF_FPU},
    /*  306 */ {I_FDIV, 2, {FPUREG,FPU0,0,0,0}, nasm_bytecodes+17157, IF_8086|IF_FPU},
    /*  307 */ {I_FDIV, 2, {FPU0,FPUREG,0,0,0}, nasm_bytecodes+17167, IF_8086|IF_FPU},
    /*  308 */ {I_FDIVP, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+17172, IF_8086|IF_FPU},
    /*  309 */ {I_FDIVP, 2, {FPUREG,FPU0,0,0,0}, nasm_bytecodes+17172, IF_8086|IF_FPU},
    /*  310 */ {I_FDIVR, 1, {MEMORY|BITS32,0,0,0,0}, nasm_bytecodes+18795, IF_8086|IF_FPU},
    /*  311 */ {I_FDIVR, 1, {MEMORY|BITS64,0,0,0,0}, nasm_bytecodes+18799, IF_8086|IF_FPU},
    /*  312 */ {I_FDIVR, 1, {FPUREG|TO,0,0,0,0}, nasm_bytecodes+17177, IF_8086|IF_FPU},
    /*  313 */ {I_FDIVR, 2, {FPUREG,FPU0,0,0,0}, nasm_bytecodes+17177, IF_8086|IF_FPU},
    /*  314 */ {I_FDIVR, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+17182, IF_8086|IF_FPU},
    /*  315 */ {I_FDIVR, 2, {FPU0,FPUREG,0,0,0}, nasm_bytecodes+17187, IF_8086|IF_FPU},
    /*  316 */ {I_FDIVRP, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+17192, IF_8086|IF_FPU},
    /*  317 */ {I_FDIVRP, 2, {FPUREG,FPU0,0,0,0}, nasm_bytecodes+17192, IF_8086|IF_FPU},
    /*  318 */ {I_FEMMS, 0, {0,0,0,0,0}, nasm_bytecodes+18807, IF_PENT|IF_3DNOW},
    /*  319 */ {I_FENI, 0, {0,0,0,0,0}, nasm_bytecodes+17197, IF_8086|IF_FPU},
    /*  320 */ {I_FFREE, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+17202, IF_8086|IF_FPU},
    /*  321 */ {I_FFREE, 0, {0,0,0,0,0}, nasm_bytecodes+18811, IF_8086|IF_FPU},
    /*  322 */ {I_FFREEP, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+17207, IF_286|IF_FPU|IF_UNDOC},
    /*  323 */ {I_FFREEP, 0, {0,0,0,0,0}, nasm_bytecodes+18815, IF_286|IF_FPU|IF_UNDOC},
    /*  324 */ {I_FIADD, 1, {MEMORY|BITS32,0,0,0,0}, nasm_bytecodes+18819, IF_8086|IF_FPU},
    /*  325 */ {I_FIADD, 1, {MEMORY|BITS16,0,0,0,0}, nasm_bytecodes+18823, IF_8086|IF_FPU},
    /*  326 */ {I_FICOM, 1, {MEMORY|BITS32,0,0,0,0}, nasm_bytecodes+18827, IF_8086|IF_FPU},
    /*  327 */ {I_FICOM, 1, {MEMORY|BITS16,0,0,0,0}, nasm_bytecodes+18831, IF_8086|IF_FPU},
    /*  328 */ {I_FICOMP, 1, {MEMORY|BITS32,0,0,0,0}, nasm_bytecodes+18835, IF_8086|IF_FPU},
    /*  329 */ {I_FICOMP, 1, {MEMORY|BITS16,0,0,0,0}, nasm_bytecodes+18839, IF_8086|IF_FPU},
    /*  330 */ {I_FIDIV, 1, {MEMORY|BITS32,0,0,0,0}, nasm_bytecodes+18843, IF_8086|IF_FPU},
    /*  331 */ {I_FIDIV, 1, {MEMORY|BITS16,0,0,0,0}, nasm_bytecodes+18847, IF_8086|IF_FPU},
    /*  332 */ {I_FIDIVR, 1, {MEMORY|BITS32,0,0,0,0}, nasm_bytecodes+18851, IF_8086|IF_FPU},
    /*  333 */ {I_FIDIVR, 1, {MEMORY|BITS16,0,0,0,0}, nasm_bytecodes+18855, IF_8086|IF_FPU},
    /*  334 */ {I_FILD, 1, {MEMORY|BITS32,0,0,0,0}, nasm_bytecodes+18859, IF_8086|IF_FPU},
    /*  335 */ {I_FILD, 1, {MEMORY|BITS16,0,0,0,0}, nasm_bytecodes+18863, IF_8086|IF_FPU},
    /*  336 */ {I_FILD, 1, {MEMORY|BITS64,0,0,0,0}, nasm_bytecodes+18867, IF_8086|IF_FPU},
    /*  337 */ {I_FIMUL, 1, {MEMORY|BITS32,0,0,0,0}, nasm_bytecodes+18871, IF_8086|IF_FPU},
    /*  338 */ {I_FIMUL, 1, {MEMORY|BITS16,0,0,0,0}, nasm_bytecodes+18875, IF_8086|IF_FPU},
    /*  339 */ {I_FINCSTP, 0, {0,0,0,0,0}, nasm_bytecodes+18879, IF_8086|IF_FPU},
    /*  340 */ {I_FINIT, 0, {0,0,0,0,0}, nasm_bytecodes+17212, IF_8086|IF_FPU},
    /*  341 */ {I_FIST, 1, {MEMORY|BITS32,0,0,0,0}, nasm_bytecodes+18883, IF_8086|IF_FPU},
    /*  342 */ {I_FIST, 1, {MEMORY|BITS16,0,0,0,0}, nasm_bytecodes+18887, IF_8086|IF_FPU},
    /*  343 */ {I_FISTP, 1, {MEMORY|BITS32,0,0,0,0}, nasm_bytecodes+18891, IF_8086|IF_FPU},
    /*  344 */ {I_FISTP, 1, {MEMORY|BITS16,0,0,0,0}, nasm_bytecodes+18895, IF_8086|IF_FPU},
    /*  345 */ {I_FISTP, 1, {MEMORY|BITS64,0,0,0,0}, nasm_bytecodes+18899, IF_8086|IF_FPU},
    /*  346 */ {I_FISTTP, 1, {MEMORY|BITS16,0,0,0,0}, nasm_bytecodes+18903, IF_PRESCOTT|IF_FPU},
    /*  347 */ {I_FISTTP, 1, {MEMORY|BITS32,0,0,0,0}, nasm_bytecodes+18907, IF_PRESCOTT|IF_FPU},
    /*  348 */ {I_FISTTP, 1, {MEMORY|BITS64,0,0,0,0}, nasm_bytecodes+18911, IF_PRESCOTT|IF_FPU},
    /*  349 */ {I_FISUB, 1, {MEMORY|BITS32,0,0,0,0}, nasm_bytecodes+18915, IF_8086|IF_FPU},
    /*  350 */ {I_FISUB, 1, {MEMORY|BITS16,0,0,0,0}, nasm_bytecodes+18919, IF_8086|IF_FPU},
    /*  351 */ {I_FISUBR, 1, {MEMORY|BITS32,0,0,0,0}, nasm_bytecodes+18923, IF_8086|IF_FPU},
    /*  352 */ {I_FISUBR, 1, {MEMORY|BITS16,0,0,0,0}, nasm_bytecodes+18927, IF_8086|IF_FPU},
    /*  353 */ {I_FLD, 1, {MEMORY|BITS32,0,0,0,0}, nasm_bytecodes+18931, IF_8086|IF_FPU},
    /*  354 */ {I_FLD, 1, {MEMORY|BITS64,0,0,0,0}, nasm_bytecodes+18935, IF_8086|IF_FPU},
    /*  355 */ {I_FLD, 1, {MEMORY|BITS80,0,0,0,0}, nasm_bytecodes+18939, IF_8086|IF_FPU},
    /*  356 */ {I_FLD, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+17217, IF_8086|IF_FPU},
    /*  357 */ {I_FLD1, 0, {0,0,0,0,0}, nasm_bytecodes+18947, IF_8086|IF_FPU},
    /*  358 */ {I_FLDCW, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+18951, IF_8086|IF_FPU|IF_SW},
    /*  359 */ {I_FLDENV, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+18955, IF_8086|IF_FPU},
    /*  360 */ {I_FLDL2E, 0, {0,0,0,0,0}, nasm_bytecodes+18959, IF_8086|IF_FPU},
    /*  361 */ {I_FLDL2T, 0, {0,0,0,0,0}, nasm_bytecodes+18963, IF_8086|IF_FPU},
    /*  362 */ {I_FLDLG2, 0, {0,0,0,0,0}, nasm_bytecodes+18967, IF_8086|IF_FPU},
    /*  363 */ {I_FLDLN2, 0, {0,0,0,0,0}, nasm_bytecodes+18971, IF_8086|IF_FPU},
    /*  364 */ {I_FLDPI, 0, {0,0,0,0,0}, nasm_bytecodes+18975, IF_8086|IF_FPU},
    /*  365 */ {I_FLDZ, 0, {0,0,0,0,0}, nasm_bytecodes+18979, IF_8086|IF_FPU},
    /*  366 */ {I_FMUL, 1, {MEMORY|BITS32,0,0,0,0}, nasm_bytecodes+18983, IF_8086|IF_FPU},
    /*  367 */ {I_FMUL, 1, {MEMORY|BITS64,0,0,0,0}, nasm_bytecodes+18987, IF_8086|IF_FPU},
    /*  368 */ {I_FMUL, 1, {FPUREG|TO,0,0,0,0}, nasm_bytecodes+17222, IF_8086|IF_FPU},
    /*  369 */ {I_FMUL, 2, {FPUREG,FPU0,0,0,0}, nasm_bytecodes+17222, IF_8086|IF_FPU},
    /*  370 */ {I_FMUL, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+17227, IF_8086|IF_FPU},
    /*  371 */ {I_FMUL, 2, {FPU0,FPUREG,0,0,0}, nasm_bytecodes+17232, IF_8086|IF_FPU},
    /*  372 */ {I_FMULP, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+17237, IF_8086|IF_FPU},
    /*  373 */ {I_FMULP, 2, {FPUREG,FPU0,0,0,0}, nasm_bytecodes+17237, IF_8086|IF_FPU},
    /*  374 */ {I_FNCLEX, 0, {0,0,0,0,0}, nasm_bytecodes+18995, IF_8086|IF_FPU},
    /*  375 */ {I_FNDISI, 0, {0,0,0,0,0}, nasm_bytecodes+18999, IF_8086|IF_FPU},
    /*  376 */ {I_FNENI, 0, {0,0,0,0,0}, nasm_bytecodes+19003, IF_8086|IF_FPU},
    /*  377 */ {I_FNINIT, 0, {0,0,0,0,0}, nasm_bytecodes+19007, IF_8086|IF_FPU},
    /*  378 */ {I_FNOP, 0, {0,0,0,0,0}, nasm_bytecodes+19011, IF_8086|IF_FPU},
    /*  379 */ {I_FNSAVE, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+19015, IF_8086|IF_FPU},
    /*  380 */ {I_FNSTCW, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+19019, IF_8086|IF_FPU|IF_SW},
    /*  381 */ {I_FNSTENV, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+19023, IF_8086|IF_FPU},
    /*  382 */ {I_FNSTSW, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+19027, IF_8086|IF_FPU|IF_SW},
    /*  383 */ {I_FNSTSW, 1, {REG_AX,0,0,0,0}, nasm_bytecodes+19031, IF_286|IF_FPU},
    /*  384 */ {I_FPATAN, 0, {0,0,0,0,0}, nasm_bytecodes+19035, IF_8086|IF_FPU},
    /*  385 */ {I_FPREM, 0, {0,0,0,0,0}, nasm_bytecodes+19039, IF_8086|IF_FPU},
    /*  386 */ {I_FPREM1, 0, {0,0,0,0,0}, nasm_bytecodes+19043, IF_386|IF_FPU},
    /*  387 */ {I_FPTAN, 0, {0,0,0,0,0}, nasm_bytecodes+19047, IF_8086|IF_FPU},
    /*  388 */ {I_FRNDINT, 0, {0,0,0,0,0}, nasm_bytecodes+19051, IF_8086|IF_FPU},
    /*  389 */ {I_FRSTOR, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+19055, IF_8086|IF_FPU},
    /*  390 */ {I_FSAVE, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+17242, IF_8086|IF_FPU},
    /*  391 */ {I_FSCALE, 0, {0,0,0,0,0}, nasm_bytecodes+19059, IF_8086|IF_FPU},
    /*  392 */ {I_FSETPM, 0, {0,0,0,0,0}, nasm_bytecodes+19063, IF_286|IF_FPU},
    /*  393 */ {I_FSIN, 0, {0,0,0,0,0}, nasm_bytecodes+19067, IF_386|IF_FPU},
    /*  394 */ {I_FSINCOS, 0, {0,0,0,0,0}, nasm_bytecodes+19071, IF_386|IF_FPU},
    /*  395 */ {I_FSQRT, 0, {0,0,0,0,0}, nasm_bytecodes+19075, IF_8086|IF_FPU},
    /*  396 */ {I_FST, 1, {MEMORY|BITS32,0,0,0,0}, nasm_bytecodes+19079, IF_8086|IF_FPU},
    /*  397 */ {I_FST, 1, {MEMORY|BITS64,0,0,0,0}, nasm_bytecodes+19083, IF_8086|IF_FPU},
    /*  398 */ {I_FST, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+17247, IF_8086|IF_FPU},
    /*  399 */ {I_FSTCW, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+17252, IF_8086|IF_FPU|IF_SW},
    /*  400 */ {I_FSTENV, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+17257, IF_8086|IF_FPU},
    /*  401 */ {I_FSTP, 1, {MEMORY|BITS32,0,0,0,0}, nasm_bytecodes+19091, IF_8086|IF_FPU},
    /*  402 */ {I_FSTP, 1, {MEMORY|BITS64,0,0,0,0}, nasm_bytecodes+19095, IF_8086|IF_FPU},
    /*  403 */ {I_FSTP, 1, {MEMORY|BITS80,0,0,0,0}, nasm_bytecodes+19099, IF_8086|IF_FPU},
    /*  404 */ {I_FSTP, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+17262, IF_8086|IF_FPU},
    /*  405 */ {I_FSTSW, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+17267, IF_8086|IF_FPU|IF_SW},
    /*  406 */ {I_FSTSW, 1, {REG_AX,0,0,0,0}, nasm_bytecodes+17272, IF_286|IF_FPU},
    /*  407 */ {I_FSUB, 1, {MEMORY|BITS32,0,0,0,0}, nasm_bytecodes+19107, IF_8086|IF_FPU},
    /*  408 */ {I_FSUB, 1, {MEMORY|BITS64,0,0,0,0}, nasm_bytecodes+19111, IF_8086|IF_FPU},
    /*  409 */ {I_FSUB, 1, {FPUREG|TO,0,0,0,0}, nasm_bytecodes+17277, IF_8086|IF_FPU},
    /*  410 */ {I_FSUB, 2, {FPUREG,FPU0,0,0,0}, nasm_bytecodes+17277, IF_8086|IF_FPU},
    /*  411 */ {I_FSUB, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+17282, IF_8086|IF_FPU},
    /*  412 */ {I_FSUB, 2, {FPU0,FPUREG,0,0,0}, nasm_bytecodes+17287, IF_8086|IF_FPU},
    /*  413 */ {I_FSUBP, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+17292, IF_8086|IF_FPU},
    /*  414 */ {I_FSUBP, 2, {FPUREG,FPU0,0,0,0}, nasm_bytecodes+17292, IF_8086|IF_FPU},
    /*  415 */ {I_FSUBR, 1, {MEMORY|BITS32,0,0,0,0}, nasm_bytecodes+19119, IF_8086|IF_FPU},
    /*  416 */ {I_FSUBR, 1, {MEMORY|BITS64,0,0,0,0}, nasm_bytecodes+19123, IF_8086|IF_FPU},
    /*  417 */ {I_FSUBR, 1, {FPUREG|TO,0,0,0,0}, nasm_bytecodes+17297, IF_8086|IF_FPU},
    /*  418 */ {I_FSUBR, 2, {FPUREG,FPU0,0,0,0}, nasm_bytecodes+17297, IF_8086|IF_FPU},
    /*  419 */ {I_FSUBR, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+17302, IF_8086|IF_FPU},
    /*  420 */ {I_FSUBR, 2, {FPU0,FPUREG,0,0,0}, nasm_bytecodes+17307, IF_8086|IF_FPU},
    /*  421 */ {I_FSUBRP, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+17312, IF_8086|IF_FPU},
    /*  422 */ {I_FSUBRP, 2, {FPUREG,FPU0,0,0,0}, nasm_bytecodes+17312, IF_8086|IF_FPU},
    /*  423 */ {I_FTST, 0, {0,0,0,0,0}, nasm_bytecodes+19131, IF_8086|IF_FPU},
    /*  424 */ {I_FUCOM, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+17317, IF_386|IF_FPU},
    /*  425 */ {I_FUCOM, 2, {FPU0,FPUREG,0,0,0}, nasm_bytecodes+17322, IF_386|IF_FPU},
    /*  426 */ {I_FUCOMI, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+17327, IF_P6|IF_FPU},
    /*  427 */ {I_FUCOMI, 2, {FPU0,FPUREG,0,0,0}, nasm_bytecodes+17332, IF_P6|IF_FPU},
    /*  428 */ {I_FUCOMIP, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+17337, IF_P6|IF_FPU},
    /*  429 */ {I_FUCOMIP, 2, {FPU0,FPUREG,0,0,0}, nasm_bytecodes+17342, IF_P6|IF_FPU},
    /*  430 */ {I_FUCOMP, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+17347, IF_386|IF_FPU},
    /*  431 */ {I_FUCOMP, 2, {FPU0,FPUREG,0,0,0}, nasm_bytecodes+17352, IF_386|IF_FPU},
    /*  432 */ {I_FUCOMPP, 0, {0,0,0,0,0}, nasm_bytecodes+19151, IF_386|IF_FPU},
    /*  433 */ {I_FXAM, 0, {0,0,0,0,0}, nasm_bytecodes+19155, IF_8086|IF_FPU},
    /*  434 */ {I_FXCH, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+17357, IF_8086|IF_FPU},
    /*  435 */ {I_FXCH, 2, {FPUREG,FPU0,0,0,0}, nasm_bytecodes+17357, IF_8086|IF_FPU},
    /*  436 */ {I_FXCH, 2, {FPU0,FPUREG,0,0,0}, nasm_bytecodes+17362, IF_8086|IF_FPU},
    /*  437 */ {I_FXTRACT, 0, {0,0,0,0,0}, nasm_bytecodes+19163, IF_8086|IF_FPU},
    /*  438 */ {I_FYL2X, 0, {0,0,0,0,0}, nasm_bytecodes+19167, IF_8086|IF_FPU},
    /*  439 */ {I_FYL2XP1, 0, {0,0,0,0,0}, nasm_bytecodes+19171, IF_8086|IF_FPU},
    /*  440 */ {I_HLT, 0, {0,0,0,0,0}, nasm_bytecodes+19652, IF_8086|IF_PRIV},
    /*  441 */ {I_IDIV, 1, {RM_GPR|BITS8,0,0,0,0}, nasm_bytecodes+19175, IF_8086},
    /*  442 */ {I_IDIV, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+17367, IF_8086},
    /*  443 */ {I_IDIV, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+17372, IF_386},
    /*  444 */ {I_IDIV, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+17377, IF_X64},
    /*  445 */ {I_IMUL, 1, {RM_GPR|BITS8,0,0,0,0}, nasm_bytecodes+19179, IF_8086},
    /*  446 */ {I_IMUL, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+17382, IF_8086},
    /*  447 */ {I_IMUL, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+17387, IF_386},
    /*  448 */ {I_IMUL, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+17392, IF_X64},
    /*  449 */ {I_IMUL, 2, {REG16,MEMORY,0,0,0}, nasm_bytecodes+13474, IF_386|IF_SM},
    /*  450 */ {I_IMUL, 2, {REG16,REG16,0,0,0}, nasm_bytecodes+13474, IF_386},
    /*  451 */ {I_IMUL, 2, {REG32,MEMORY,0,0,0}, nasm_bytecodes+13480, IF_386|IF_SM},
    /*  452 */ {I_IMUL, 2, {REG32,REG32,0,0,0}, nasm_bytecodes+13480, IF_386},
    /*  453 */ {I_IMUL, 2, {REG64,MEMORY,0,0,0}, nasm_bytecodes+13486, IF_X64|IF_SM},
    /*  454 */ {I_IMUL, 2, {REG64,REG64,0,0,0}, nasm_bytecodes+13486, IF_X64},
    /*  455 */ {I_IMUL, 3, {REG16,MEMORY,IMMEDIATE|BITS8,0,0}, nasm_bytecodes+13492, IF_186|IF_SM},
    /*  456 */ {I_IMUL, 3, {REG16,MEMORY,IMMEDIATE|BITS16,0,0}, nasm_bytecodes+13498, IF_186|IF_SM},
    /*  457 */ {I_IMUL, 3, {REG16,REG16,IMMEDIATE|BITS8,0,0}, nasm_bytecodes+13492, IF_186},
    /*  458 */ {I_IMUL, 3, {REG16,REG16,IMMEDIATE|BITS16,0,0}, nasm_bytecodes+13498, IF_186},
    /*  459 */ {I_IMUL, 3, {REG32,MEMORY,IMMEDIATE|BITS8,0,0}, nasm_bytecodes+13510, IF_386|IF_SM},
    /*  460 */ {I_IMUL, 3, {REG32,MEMORY,IMMEDIATE|BITS32,0,0}, nasm_bytecodes+13516, IF_386|IF_SM},
    /*  461 */ {I_IMUL, 3, {REG32,REG32,IMMEDIATE|BITS8,0,0}, nasm_bytecodes+13510, IF_386},
    /*  462 */ {I_IMUL, 3, {REG32,REG32,IMMEDIATE|BITS32,0,0}, nasm_bytecodes+13516, IF_386},
    /*  463 */ {I_IMUL, 3, {REG64,MEMORY,IMMEDIATE|BITS8,0,0}, nasm_bytecodes+13528, IF_X64|IF_SM},
    /*  464 */ {I_IMUL, 3, {REG64,MEMORY,IMMEDIATE|BITS32,0,0}, nasm_bytecodes+13534, IF_X64|IF_SM},
    /*  465 */ {I_IMUL, 3, {REG64,REG64,IMMEDIATE|BITS8,0,0}, nasm_bytecodes+13528, IF_X64},
    /*  466 */ {I_IMUL, 3, {REG64,REG64,IMMEDIATE|BITS32,0,0}, nasm_bytecodes+13534, IF_X64},
    /*  467 */ {I_IMUL, 2, {REG16,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+13546, IF_186},
    /*  468 */ {I_IMUL, 2, {REG16,IMMEDIATE|BITS16,0,0,0}, nasm_bytecodes+13552, IF_186},
    /*  469 */ {I_IMUL, 2, {REG32,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+13564, IF_386},
    /*  470 */ {I_IMUL, 2, {REG32,IMMEDIATE|BITS32,0,0,0}, nasm_bytecodes+13570, IF_386},
    /*  471 */ {I_IMUL, 2, {REG64,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+13582, IF_X64},
    /*  472 */ {I_IMUL, 2, {REG64,IMMEDIATE|BITS32,0,0,0}, nasm_bytecodes+13588, IF_X64},
    /*  473 */ {I_IN, 2, {REG_AL,IMMEDIATE,0,0,0}, nasm_bytecodes+19183, IF_8086|IF_SB},
    /*  474 */ {I_IN, 2, {REG_AX,IMMEDIATE,0,0,0}, nasm_bytecodes+17397, IF_8086|IF_SB},
    /*  475 */ {I_IN, 2, {REG_EAX,IMMEDIATE,0,0,0}, nasm_bytecodes+17402, IF_386|IF_SB},
    /*  476 */ {I_IN, 2, {REG_AL,REG_DX,0,0,0}, nasm_bytecodes+19658, IF_8086},
    /*  477 */ {I_IN, 2, {REG_AX,REG_DX,0,0,0}, nasm_bytecodes+19187, IF_8086},
    /*  478 */ {I_IN, 2, {REG_EAX,REG_DX,0,0,0}, nasm_bytecodes+19191, IF_386},
    /*  479 */ {I_INC, 1, {REG16,0,0,0,0}, nasm_bytecodes+19195, IF_8086|IF_NOLONG},
    /*  480 */ {I_INC, 1, {REG32,0,0,0,0}, nasm_bytecodes+19199, IF_386|IF_NOLONG},
    /*  481 */ {I_INC, 1, {RM_GPR|BITS8,0,0,0,0}, nasm_bytecodes+19203, IF_8086},
    /*  482 */ {I_INC, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+17407, IF_8086},
    /*  483 */ {I_INC, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+17412, IF_386},
    /*  484 */ {I_INC, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+17417, IF_X64},
    /*  485 */ {I_INSB, 0, {0,0,0,0,0}, nasm_bytecodes+19661, IF_186},
    /*  486 */ {I_INSD, 0, {0,0,0,0,0}, nasm_bytecodes+19207, IF_386},
    /*  487 */ {I_INSW, 0, {0,0,0,0,0}, nasm_bytecodes+19211, IF_186},
    /*  488 */ {I_INT, 1, {IMMEDIATE,0,0,0,0}, nasm_bytecodes+19215, IF_8086|IF_SB},
    /*  489 */ {I_INT1, 0, {0,0,0,0,0}, nasm_bytecodes+19655, IF_386},
    /*  490 */ {I_INT3, 0, {0,0,0,0,0}, nasm_bytecodes+19664, IF_8086},
    /*  491 */ {I_INTO, 0, {0,0,0,0,0}, nasm_bytecodes+19667, IF_8086|IF_NOLONG},
    /*  492 */ {I_INVD, 0, {0,0,0,0,0}, nasm_bytecodes+19219, IF_486|IF_PRIV},
    /*  493 */ {I_INVLPG, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+17422, IF_486|IF_PRIV},
    /*  494 */ {I_INVLPGA, 2, {REG_AX,REG_ECX,0,0,0}, nasm_bytecodes+13600, IF_X86_64|IF_AMD|IF_NOLONG},
    /*  495 */ {I_INVLPGA, 2, {REG_EAX,REG_ECX,0,0,0}, nasm_bytecodes+13606, IF_X86_64|IF_AMD},
    /*  496 */ {I_INVLPGA, 2, {REG_RAX,REG_ECX,0,0,0}, nasm_bytecodes+7314, IF_X64|IF_AMD},
    /*  497 */ {I_INVLPGA, 0, {0,0,0,0,0}, nasm_bytecodes+13607, IF_X86_64|IF_AMD},
    /*  498 */ {I_IRET, 0, {0,0,0,0,0}, nasm_bytecodes+19223, IF_8086},
    /*  499 */ {I_IRETD, 0, {0,0,0,0,0}, nasm_bytecodes+19227, IF_386},
    /*  500 */ {I_IRETQ, 0, {0,0,0,0,0}, nasm_bytecodes+19231, IF_X64},
    /*  501 */ {I_IRETW, 0, {0,0,0,0,0}, nasm_bytecodes+19235, IF_8086},
    /*  502 */ {I_JCXZ, 1, {IMMEDIATE,0,0,0,0}, nasm_bytecodes+17427, IF_8086|IF_NOLONG},
    /*  503 */ {I_JECXZ, 1, {IMMEDIATE,0,0,0,0}, nasm_bytecodes+17432, IF_386},
    /*  504 */ {I_JMP, 1, {IMMEDIATE|SHORT,0,0,0,0}, nasm_bytecodes+17438, IF_8086},
    /*  505 */ {I_JMP, 1, {IMMEDIATE,0,0,0,0}, nasm_bytecodes+17442, IF_8086},
    /*  506 */ {I_JMP, 1, {IMMEDIATE|BITS16,0,0,0,0}, nasm_bytecodes+17447, IF_8086},
    /*  507 */ {I_JMP, 1, {IMMEDIATE|BITS32,0,0,0,0}, nasm_bytecodes+17452, IF_386},
    /*  508 */ {I_JMP, 2, {IMMEDIATE|COLON,IMMEDIATE,0,0,0}, nasm_bytecodes+13630, IF_8086|IF_NOLONG},
    /*  509 */ {I_JMP, 2, {IMMEDIATE|BITS16|COLON,IMMEDIATE,0,0,0}, nasm_bytecodes+13636, IF_8086|IF_NOLONG},
    /*  510 */ {I_JMP, 2, {IMMEDIATE|COLON,IMMEDIATE|BITS16,0,0,0}, nasm_bytecodes+13636, IF_8086|IF_NOLONG},
    /*  511 */ {I_JMP, 2, {IMMEDIATE|BITS32|COLON,IMMEDIATE,0,0,0}, nasm_bytecodes+13642, IF_386|IF_NOLONG},
    /*  512 */ {I_JMP, 2, {IMMEDIATE|COLON,IMMEDIATE|BITS32,0,0,0}, nasm_bytecodes+13642, IF_386|IF_NOLONG},
    /*  513 */ {I_JMP, 1, {MEMORY|FAR,0,0,0,0}, nasm_bytecodes+17457, IF_8086|IF_NOLONG},
    /*  514 */ {I_JMP, 1, {MEMORY|FAR,0,0,0,0}, nasm_bytecodes+17462, IF_X64},
    /*  515 */ {I_JMP, 1, {MEMORY|BITS16|FAR,0,0,0,0}, nasm_bytecodes+17467, IF_8086},
    /*  516 */ {I_JMP, 1, {MEMORY|BITS32|FAR,0,0,0,0}, nasm_bytecodes+17472, IF_386},
    /*  517 */ {I_JMP, 1, {MEMORY|BITS64|FAR,0,0,0,0}, nasm_bytecodes+17462, IF_X64},
    /*  518 */ {I_JMP, 1, {MEMORY|NEAR,0,0,0,0}, nasm_bytecodes+17477, IF_8086},
    /*  519 */ {I_JMP, 1, {MEMORY|BITS16|NEAR,0,0,0,0}, nasm_bytecodes+17482, IF_8086},
    /*  520 */ {I_JMP, 1, {MEMORY|BITS32|NEAR,0,0,0,0}, nasm_bytecodes+17487, IF_386|IF_NOLONG},
    /*  521 */ {I_JMP, 1, {MEMORY|BITS64|NEAR,0,0,0,0}, nasm_bytecodes+17492, IF_X64},
    /*  522 */ {I_JMP, 1, {REG16,0,0,0,0}, nasm_bytecodes+17482, IF_8086},
    /*  523 */ {I_JMP, 1, {REG32,0,0,0,0}, nasm_bytecodes+17487, IF_386|IF_NOLONG},
    /*  524 */ {I_JMP, 1, {REG64,0,0,0,0}, nasm_bytecodes+17492, IF_X64},
    /*  525 */ {I_JMP, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+17477, IF_8086},
    /*  526 */ {I_JMP, 1, {MEMORY|BITS16,0,0,0,0}, nasm_bytecodes+17482, IF_8086},
    /*  527 */ {I_JMP, 1, {MEMORY|BITS32,0,0,0,0}, nasm_bytecodes+17487, IF_386|IF_NOLONG},
    /*  528 */ {I_JMP, 1, {MEMORY|BITS64,0,0,0,0}, nasm_bytecodes+17492, IF_X64},
    /*  529 */ {I_JMPE, 1, {IMMEDIATE,0,0,0,0}, nasm_bytecodes+13648, IF_IA64},
    /*  530 */ {I_JMPE, 1, {IMMEDIATE|BITS16,0,0,0,0}, nasm_bytecodes+13654, IF_IA64},
    /*  531 */ {I_JMPE, 1, {IMMEDIATE|BITS32,0,0,0,0}, nasm_bytecodes+13660, IF_IA64},
    /*  532 */ {I_JMPE, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+13666, IF_IA64},
    /*  533 */ {I_JMPE, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+13672, IF_IA64},
    /*  534 */ {I_JRCXZ, 1, {IMMEDIATE,0,0,0,0}, nasm_bytecodes+17433, IF_X64},
    /*  535 */ {I_LAHF, 0, {0,0,0,0,0}, nasm_bytecodes+19670, IF_8086},
    /*  536 */ {I_LAR, 2, {REG16,MEMORY,0,0,0}, nasm_bytecodes+13678, IF_286|IF_PROT|IF_SW},
    /*  537 */ {I_LAR, 2, {REG16,REG16,0,0,0}, nasm_bytecodes+13678, IF_286|IF_PROT},
    /*  538 */ {I_LAR, 2, {REG16,REG32,0,0,0}, nasm_bytecodes+13678, IF_386|IF_PROT},
    /*  539 */ {I_LAR, 2, {REG32,MEMORY,0,0,0}, nasm_bytecodes+13684, IF_386|IF_PROT|IF_SW},
    /*  540 */ {I_LAR, 2, {REG32,REG16,0,0,0}, nasm_bytecodes+13684, IF_386|IF_PROT},
    /*  541 */ {I_LAR, 2, {REG32,REG32,0,0,0}, nasm_bytecodes+13684, IF_386|IF_PROT},
    /*  542 */ {I_LAR, 2, {REG64,MEMORY,0,0,0}, nasm_bytecodes+13690, IF_X64|IF_PROT|IF_SW},
    /*  543 */ {I_LAR, 2, {REG64,REG16,0,0,0}, nasm_bytecodes+13690, IF_X64|IF_PROT},
    /*  544 */ {I_LAR, 2, {REG64,REG32,0,0,0}, nasm_bytecodes+13690, IF_X64|IF_PROT},
    /*  545 */ {I_LAR, 2, {REG64,REG64,0,0,0}, nasm_bytecodes+13690, IF_X64|IF_PROT},
    /*  546 */ {I_LDS, 2, {REG16,MEMORY,0,0,0}, nasm_bytecodes+17497, IF_8086|IF_NOLONG},
    /*  547 */ {I_LDS, 2, {REG32,MEMORY,0,0,0}, nasm_bytecodes+17502, IF_386|IF_NOLONG},
    /*  548 */ {I_LEA, 2, {REG16,MEMORY,0,0,0}, nasm_bytecodes+17507, IF_8086},
    /*  549 */ {I_LEA, 2, {REG32,MEMORY,0,0,0}, nasm_bytecodes+17512, IF_386},
    /*  550 */ {I_LEA, 2, {REG64,MEMORY,0,0,0}, nasm_bytecodes+17517, IF_X64},
    /*  551 */ {I_LEAVE, 0, {0,0,0,0,0}, nasm_bytecodes+17754, IF_186},
    /*  552 */ {I_LES, 2, {REG16,MEMORY,0,0,0}, nasm_bytecodes+17522, IF_8086|IF_NOLONG},
    /*  553 */ {I_LES, 2, {REG32,MEMORY,0,0,0}, nasm_bytecodes+17527, IF_386|IF_NOLONG},
    /*  554 */ {I_LFENCE, 0, {0,0,0,0,0}, nasm_bytecodes+17532, IF_X64|IF_AMD},
    /*  555 */ {I_LFS, 2, {REG16,MEMORY,0,0,0}, nasm_bytecodes+13696, IF_386},
    /*  556 */ {I_LFS, 2, {REG32,MEMORY,0,0,0}, nasm_bytecodes+13702, IF_386},
    /*  557 */ {I_LGDT, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+17537, IF_286|IF_PRIV},
    /*  558 */ {I_LGS, 2, {REG16,MEMORY,0,0,0}, nasm_bytecodes+13708, IF_386},
    /*  559 */ {I_LGS, 2, {REG32,MEMORY,0,0,0}, nasm_bytecodes+13714, IF_386},
    /*  560 */ {I_LIDT, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+17542, IF_286|IF_PRIV},
    /*  561 */ {I_LLDT, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+17547, IF_286|IF_PROT|IF_PRIV},
    /*  562 */ {I_LLDT, 1, {MEMORY|BITS16,0,0,0,0}, nasm_bytecodes+17547, IF_286|IF_PROT|IF_PRIV},
    /*  563 */ {I_LLDT, 1, {REG16,0,0,0,0}, nasm_bytecodes+17547, IF_286|IF_PROT|IF_PRIV},
    /*  564 */ {I_LMSW, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+17552, IF_286|IF_PRIV},
    /*  565 */ {I_LMSW, 1, {MEMORY|BITS16,0,0,0,0}, nasm_bytecodes+17552, IF_286|IF_PRIV},
    /*  566 */ {I_LMSW, 1, {REG16,0,0,0,0}, nasm_bytecodes+17552, IF_286|IF_PRIV},
    /*  567 */ {I_LOADALL, 0, {0,0,0,0,0}, nasm_bytecodes+19239, IF_386|IF_UNDOC},
    /*  568 */ {I_LOADALL286, 0, {0,0,0,0,0}, nasm_bytecodes+19243, IF_286|IF_UNDOC},
    /*  569 */ {I_LODSB, 0, {0,0,0,0,0}, nasm_bytecodes+19673, IF_8086},
    /*  570 */ {I_LODSD, 0, {0,0,0,0,0}, nasm_bytecodes+19247, IF_386},
    /*  571 */ {I_LODSQ, 0, {0,0,0,0,0}, nasm_bytecodes+19251, IF_X64},
    /*  572 */ {I_LODSW, 0, {0,0,0,0,0}, nasm_bytecodes+19255, IF_8086},
    /*  573 */ {I_LOOP, 1, {IMMEDIATE,0,0,0,0}, nasm_bytecodes+17557, IF_8086},
    /*  574 */ {I_LOOP, 2, {IMMEDIATE,REG_CX,0,0,0}, nasm_bytecodes+17562, IF_8086|IF_NOLONG},
    /*  575 */ {I_LOOP, 2, {IMMEDIATE,REG_ECX,0,0,0}, nasm_bytecodes+17567, IF_386},
    /*  576 */ {I_LOOP, 2, {IMMEDIATE,REG_RCX,0,0,0}, nasm_bytecodes+17572, IF_X64},
    /*  577 */ {I_LOOPE, 1, {IMMEDIATE,0,0,0,0}, nasm_bytecodes+17577, IF_8086},
    /*  578 */ {I_LOOPE, 2, {IMMEDIATE,REG_CX,0,0,0}, nasm_bytecodes+17582, IF_8086|IF_NOLONG},
    /*  579 */ {I_LOOPE, 2, {IMMEDIATE,REG_ECX,0,0,0}, nasm_bytecodes+17587, IF_386},
    /*  580 */ {I_LOOPE, 2, {IMMEDIATE,REG_RCX,0,0,0}, nasm_bytecodes+17592, IF_X64},
    /*  581 */ {I_LOOPNE, 1, {IMMEDIATE,0,0,0,0}, nasm_bytecodes+17597, IF_8086},
    /*  582 */ {I_LOOPNE, 2, {IMMEDIATE,REG_CX,0,0,0}, nasm_bytecodes+17602, IF_8086|IF_NOLONG},
    /*  583 */ {I_LOOPNE, 2, {IMMEDIATE,REG_ECX,0,0,0}, nasm_bytecodes+17607, IF_386},
    /*  584 */ {I_LOOPNE, 2, {IMMEDIATE,REG_RCX,0,0,0}, nasm_bytecodes+17612, IF_X64},
    /*  585 */ {I_LOOPNZ, 1, {IMMEDIATE,0,0,0,0}, nasm_bytecodes+17597, IF_8086},
    /*  586 */ {I_LOOPNZ, 2, {IMMEDIATE,REG_CX,0,0,0}, nasm_bytecodes+17602, IF_8086|IF_NOLONG},
    /*  587 */ {I_LOOPNZ, 2, {IMMEDIATE,REG_ECX,0,0,0}, nasm_bytecodes+17607, IF_386},
    /*  588 */ {I_LOOPNZ, 2, {IMMEDIATE,REG_RCX,0,0,0}, nasm_bytecodes+17612, IF_X64},
    /*  589 */ {I_LOOPZ, 1, {IMMEDIATE,0,0,0,0}, nasm_bytecodes+17577, IF_8086},
    /*  590 */ {I_LOOPZ, 2, {IMMEDIATE,REG_CX,0,0,0}, nasm_bytecodes+17582, IF_8086|IF_NOLONG},
    /*  591 */ {I_LOOPZ, 2, {IMMEDIATE,REG_ECX,0,0,0}, nasm_bytecodes+17587, IF_386},
    /*  592 */ {I_LOOPZ, 2, {IMMEDIATE,REG_RCX,0,0,0}, nasm_bytecodes+17592, IF_X64},
    /*  593 */ {I_LSL, 2, {REG16,MEMORY,0,0,0}, nasm_bytecodes+13720, IF_286|IF_PROT|IF_SW},
    /*  594 */ {I_LSL, 2, {REG16,REG16,0,0,0}, nasm_bytecodes+13720, IF_286|IF_PROT},
    /*  595 */ {I_LSL, 2, {REG16,REG32,0,0,0}, nasm_bytecodes+13720, IF_386|IF_PROT},
    /*  596 */ {I_LSL, 2, {REG32,MEMORY,0,0,0}, nasm_bytecodes+13726, IF_386|IF_PROT|IF_SW},
    /*  597 */ {I_LSL, 2, {REG32,REG16,0,0,0}, nasm_bytecodes+13726, IF_386|IF_PROT},
    /*  598 */ {I_LSL, 2, {REG32,REG32,0,0,0}, nasm_bytecodes+13726, IF_386|IF_PROT},
    /*  599 */ {I_LSL, 2, {REG64,MEMORY,0,0,0}, nasm_bytecodes+13732, IF_X64|IF_PROT|IF_SW},
    /*  600 */ {I_LSL, 2, {REG64,REG16,0,0,0}, nasm_bytecodes+13732, IF_X64|IF_PROT},
    /*  601 */ {I_LSL, 2, {REG64,REG32,0,0,0}, nasm_bytecodes+13732, IF_X64|IF_PROT},
    /*  602 */ {I_LSL, 2, {REG64,REG64,0,0,0}, nasm_bytecodes+13732, IF_X64|IF_PROT},
    /*  603 */ {I_LSS, 2, {REG16,MEMORY,0,0,0}, nasm_bytecodes+13738, IF_386},
    /*  604 */ {I_LSS, 2, {REG32,MEMORY,0,0,0}, nasm_bytecodes+13744, IF_386},
    /*  605 */ {I_LTR, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+17617, IF_286|IF_PROT|IF_PRIV},
    /*  606 */ {I_LTR, 1, {MEMORY|BITS16,0,0,0,0}, nasm_bytecodes+17617, IF_286|IF_PROT|IF_PRIV},
    /*  607 */ {I_LTR, 1, {REG16,0,0,0,0}, nasm_bytecodes+17617, IF_286|IF_PROT|IF_PRIV},
    /*  608 */ {I_MFENCE, 0, {0,0,0,0,0}, nasm_bytecodes+17622, IF_X64|IF_AMD},
    /*  609 */ {I_MONITOR, 0, {0,0,0,0,0}, nasm_bytecodes+17627, IF_PRESCOTT},
    /*  610 */ {I_MOV, 2, {MEMORY,REG_SREG,0,0,0}, nasm_bytecodes+17638, IF_8086|IF_SM},
    /*  611 */ {I_MOV, 2, {REG16,REG_SREG,0,0,0}, nasm_bytecodes+17632, IF_8086},
    /*  612 */ {I_MOV, 2, {REG32,REG_SREG,0,0,0}, nasm_bytecodes+17637, IF_386},
    /*  613 */ {I_MOV, 2, {REG_SREG,MEMORY,0,0,0}, nasm_bytecodes+19259, IF_8086|IF_SM},
    /*  614 */ {I_MOV, 2, {REG_SREG,REG16,0,0,0}, nasm_bytecodes+19259, IF_8086},
    /*  615 */ {I_MOV, 2, {REG_SREG,REG32,0,0,0}, nasm_bytecodes+19259, IF_386},
    /*  616 */ {I_MOV, 2, {REG_AL,MEM_OFFS,0,0,0}, nasm_bytecodes+19263, IF_8086|IF_SM},
    /*  617 */ {I_MOV, 2, {REG_AX,MEM_OFFS,0,0,0}, nasm_bytecodes+17642, IF_8086|IF_SM},
    /*  618 */ {I_MOV, 2, {REG_EAX,MEM_OFFS,0,0,0}, nasm_bytecodes+17647, IF_386|IF_SM},
    /*  619 */ {I_MOV, 2, {REG_RAX,MEM_OFFS,0,0,0}, nasm_bytecodes+17652, IF_X64|IF_SM},
    /*  620 */ {I_MOV, 2, {MEM_OFFS,REG_AL,0,0,0}, nasm_bytecodes+19267, IF_8086|IF_SM},
    /*  621 */ {I_MOV, 2, {MEM_OFFS,REG_AX,0,0,0}, nasm_bytecodes+17657, IF_8086|IF_SM},
    /*  622 */ {I_MOV, 2, {MEM_OFFS,REG_EAX,0,0,0}, nasm_bytecodes+17662, IF_386|IF_SM},
    /*  623 */ {I_MOV, 2, {MEM_OFFS,REG_RAX,0,0,0}, nasm_bytecodes+17667, IF_X64|IF_SM},
    /*  624 */ {I_MOV, 2, {REG32,REG_CREG,0,0,0}, nasm_bytecodes+13750, IF_386|IF_PRIV|IF_NOLONG},
    /*  625 */ {I_MOV, 2, {REG64,REG_CREG,0,0,0}, nasm_bytecodes+13756, IF_X64|IF_PRIV},
    /*  626 */ {I_MOV, 2, {REG_CREG,REG32,0,0,0}, nasm_bytecodes+13762, IF_386|IF_PRIV|IF_NOLONG},
    /*  627 */ {I_MOV, 2, {REG_CREG,REG64,0,0,0}, nasm_bytecodes+13768, IF_X64|IF_PRIV},
    /*  628 */ {I_MOV, 2, {REG32,REG_DREG,0,0,0}, nasm_bytecodes+13775, IF_386|IF_PRIV|IF_NOLONG},
    /*  629 */ {I_MOV, 2, {REG64,REG_DREG,0,0,0}, nasm_bytecodes+13774, IF_X64|IF_PRIV},
    /*  630 */ {I_MOV, 2, {REG_DREG,REG32,0,0,0}, nasm_bytecodes+13781, IF_386|IF_PRIV|IF_NOLONG},
    /*  631 */ {I_MOV, 2, {REG_DREG,REG64,0,0,0}, nasm_bytecodes+13780, IF_X64|IF_PRIV},
    /*  632 */ {I_MOV, 2, {MEMORY,REG8,0,0,0}, nasm_bytecodes+19271, IF_8086|IF_SM},
    /*  633 */ {I_MOV, 2, {REG8,REG8,0,0,0}, nasm_bytecodes+19271, IF_8086},
    /*  634 */ {I_MOV, 2, {MEMORY,REG16,0,0,0}, nasm_bytecodes+17682, IF_8086|IF_SM},
    /*  635 */ {I_MOV, 2, {REG16,REG16,0,0,0}, nasm_bytecodes+17682, IF_8086},
    /*  636 */ {I_MOV, 2, {MEMORY,REG32,0,0,0}, nasm_bytecodes+17687, IF_386|IF_SM},
    /*  637 */ {I_MOV, 2, {REG32,REG32,0,0,0}, nasm_bytecodes+17687, IF_386},
    /*  638 */ {I_MOV, 2, {MEMORY,REG64,0,0,0}, nasm_bytecodes+17692, IF_X64|IF_SM},
    /*  639 */ {I_MOV, 2, {REG64,REG64,0,0,0}, nasm_bytecodes+17692, IF_X64},
    /*  640 */ {I_MOV, 2, {REG8,MEMORY,0,0,0}, nasm_bytecodes+19275, IF_8086|IF_SM},
    /*  641 */ {I_MOV, 2, {REG8,REG8,0,0,0}, nasm_bytecodes+19275, IF_8086},
    /*  642 */ {I_MOV, 2, {REG16,MEMORY,0,0,0}, nasm_bytecodes+17697, IF_8086|IF_SM},
    /*  643 */ {I_MOV, 2, {REG16,REG16,0,0,0}, nasm_bytecodes+17697, IF_8086},
    /*  644 */ {I_MOV, 2, {REG32,MEMORY,0,0,0}, nasm_bytecodes+17702, IF_386|IF_SM},
    /*  645 */ {I_MOV, 2, {REG32,REG32,0,0,0}, nasm_bytecodes+17702, IF_386},
    /*  646 */ {I_MOV, 2, {REG64,MEMORY,0,0,0}, nasm_bytecodes+17707, IF_X64|IF_SM},
    /*  647 */ {I_MOV, 2, {REG64,REG64,0,0,0}, nasm_bytecodes+17707, IF_X64},
    /*  648 */ {I_MOV, 2, {REG8,IMMEDIATE,0,0,0}, nasm_bytecodes+19279, IF_8086|IF_SM},
    /*  649 */ {I_MOV, 2, {REG16,IMMEDIATE,0,0,0}, nasm_bytecodes+17712, IF_8086|IF_SM},
    /*  650 */ {I_MOV, 2, {REG32,IMMEDIATE,0,0,0}, nasm_bytecodes+17717, IF_386|IF_SM},
    /*  651 */ {I_MOV, 2, {REG64,IMMEDIATE,0,0,0}, nasm_bytecodes+17722, IF_X64|IF_SM},
    /*  652 */ {I_MOV, 2, {REG64,IMMEDIATE|BITS32,0,0,0}, nasm_bytecodes+13786, IF_X64},
    /*  653 */ {I_MOV, 2, {RM_GPR|BITS8,IMMEDIATE,0,0,0}, nasm_bytecodes+17727, IF_8086|IF_SM},
    /*  654 */ {I_MOV, 2, {RM_GPR|BITS16,IMMEDIATE,0,0,0}, nasm_bytecodes+13792, IF_8086|IF_SM},
    /*  655 */ {I_MOV, 2, {RM_GPR|BITS32,IMMEDIATE,0,0,0}, nasm_bytecodes+13798, IF_386|IF_SM},
    /*  656 */ {I_MOV, 2, {RM_GPR|BITS64,IMMEDIATE,0,0,0}, nasm_bytecodes+13786, IF_X64|IF_SM},
    /*  657 */ {I_MOV, 2, {MEMORY,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+17727, IF_8086|IF_SM},
    /*  658 */ {I_MOV, 2, {MEMORY,IMMEDIATE|BITS16,0,0,0}, nasm_bytecodes+13792, IF_8086|IF_SM},
    /*  659 */ {I_MOV, 2, {MEMORY,IMMEDIATE|BITS32,0,0,0}, nasm_bytecodes+13798, IF_386|IF_SM},
    /*  660 */ {I_MOVD, 2, {MMXREG,MEMORY,0,0,0}, nasm_bytecodes+13804, IF_PENT|IF_MMX|IF_SD},
    /*  661 */ {I_MOVD, 2, {MMXREG,REG32,0,0,0}, nasm_bytecodes+13804, IF_PENT|IF_MMX},
    /*  662 */ {I_MOVD, 2, {MEMORY,MMXREG,0,0,0}, nasm_bytecodes+13810, IF_PENT|IF_MMX|IF_SD},
    /*  663 */ {I_MOVD, 2, {REG32,MMXREG,0,0,0}, nasm_bytecodes+13810, IF_PENT|IF_MMX},
    /*  664 */ {I_MOVD, 2, {XMMREG,MEMORY,0,0,0}, nasm_bytecodes+7349, IF_X64|IF_SD},
    /*  665 */ {I_MOVD, 2, {XMMREG,REG32,0,0,0}, nasm_bytecodes+7349, IF_X64},
    /*  666 */ {I_MOVD, 2, {MEMORY,XMMREG,0,0,0}, nasm_bytecodes+7356, IF_X64|IF_SD},
    /*  667 */ {I_MOVD, 2, {REG32,XMMREG,0,0,0}, nasm_bytecodes+7356, IF_X64|IF_SSE},
    /*  668 */ {I_MOVQ, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7363, IF_PENT|IF_MMX|IF_SQ},
    /*  669 */ {I_MOVQ, 2, {RM_MMX,MMXREG,0,0,0}, nasm_bytecodes+7370, IF_PENT|IF_MMX|IF_SQ},
    /*  670 */ {I_MOVQ, 2, {MMXREG,RM_GPR|BITS64,0,0,0}, nasm_bytecodes+13804, IF_X64|IF_MMX},
    /*  671 */ {I_MOVQ, 2, {RM_GPR|BITS64,MMXREG,0,0,0}, nasm_bytecodes+13810, IF_X64|IF_MMX},
    /*  672 */ {I_MOVSB, 0, {0,0,0,0,0}, nasm_bytecodes+5659, IF_8086},
    /*  673 */ {I_MOVSD, 0, {0,0,0,0,0}, nasm_bytecodes+19283, IF_386},
    /*  674 */ {I_MOVSQ, 0, {0,0,0,0,0}, nasm_bytecodes+19287, IF_X64},
    /*  675 */ {I_MOVSW, 0, {0,0,0,0,0}, nasm_bytecodes+19291, IF_8086},
    /*  676 */ {I_MOVSX, 2, {REG16,MEMORY,0,0,0}, nasm_bytecodes+13816, IF_386|IF_SB},
    /*  677 */ {I_MOVSX, 2, {REG16,REG8,0,0,0}, nasm_bytecodes+13816, IF_386},
    /*  678 */ {I_MOVSX, 2, {REG32,RM_GPR|BITS8,0,0,0}, nasm_bytecodes+13822, IF_386},
    /*  679 */ {I_MOVSX, 2, {REG32,RM_GPR|BITS16,0,0,0}, nasm_bytecodes+13828, IF_386},
    /*  680 */ {I_MOVSX, 2, {REG64,RM_GPR|BITS8,0,0,0}, nasm_bytecodes+13834, IF_X64},
    /*  681 */ {I_MOVSX, 2, {REG64,RM_GPR|BITS16,0,0,0}, nasm_bytecodes+13840, IF_X64},
    /*  682 */ {I_MOVSXD, 2, {REG64,RM_GPR|BITS32,0,0,0}, nasm_bytecodes+17732, IF_X64},
    /*  683 */ {I_MOVZX, 2, {REG16,MEMORY,0,0,0}, nasm_bytecodes+13846, IF_386|IF_SB},
    /*  684 */ {I_MOVZX, 2, {REG16,REG8,0,0,0}, nasm_bytecodes+13846, IF_386},
    /*  685 */ {I_MOVZX, 2, {REG32,RM_GPR|BITS8,0,0,0}, nasm_bytecodes+13852, IF_386},
    /*  686 */ {I_MOVZX, 2, {REG32,RM_GPR|BITS16,0,0,0}, nasm_bytecodes+13858, IF_386},
    /*  687 */ {I_MOVZX, 2, {REG64,RM_GPR|BITS8,0,0,0}, nasm_bytecodes+13864, IF_X64},
    /*  688 */ {I_MOVZX, 2, {REG64,RM_GPR|BITS16,0,0,0}, nasm_bytecodes+13870, IF_X64},
    /*  689 */ {I_MUL, 1, {RM_GPR|BITS8,0,0,0,0}, nasm_bytecodes+19295, IF_8086},
    /*  690 */ {I_MUL, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+17737, IF_8086},
    /*  691 */ {I_MUL, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+17742, IF_386},
    /*  692 */ {I_MUL, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+17747, IF_X64},
    /*  693 */ {I_MWAIT, 0, {0,0,0,0,0}, nasm_bytecodes+17752, IF_PRESCOTT},
    /*  694 */ {I_NEG, 1, {RM_GPR|BITS8,0,0,0,0}, nasm_bytecodes+19299, IF_8086},
    /*  695 */ {I_NEG, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+17757, IF_8086},
    /*  696 */ {I_NEG, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+17762, IF_386},
    /*  697 */ {I_NEG, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+17767, IF_X64},
    /*  698 */ {I_NOP, 0, {0,0,0,0,0}, nasm_bytecodes+19303, IF_8086},
    /*  699 */ {I_NOP, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+13876, IF_P6},
    /*  700 */ {I_NOP, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+13882, IF_P6},
    /*  701 */ {I_NOP, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+13888, IF_X64},
    /*  702 */ {I_NOT, 1, {RM_GPR|BITS8,0,0,0,0}, nasm_bytecodes+19307, IF_8086},
    /*  703 */ {I_NOT, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+17772, IF_8086},
    /*  704 */ {I_NOT, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+17777, IF_386},
    /*  705 */ {I_NOT, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+17782, IF_X64},
    /*  706 */ {I_OR, 2, {MEMORY,REG8,0,0,0}, nasm_bytecodes+19311, IF_8086|IF_SM},
    /*  707 */ {I_OR, 2, {REG8,REG8,0,0,0}, nasm_bytecodes+19311, IF_8086},
    /*  708 */ {I_OR, 2, {MEMORY,REG16,0,0,0}, nasm_bytecodes+17787, IF_8086|IF_SM},
    /*  709 */ {I_OR, 2, {REG16,REG16,0,0,0}, nasm_bytecodes+17787, IF_8086},
    /*  710 */ {I_OR, 2, {MEMORY,REG32,0,0,0}, nasm_bytecodes+17792, IF_386|IF_SM},
    /*  711 */ {I_OR, 2, {REG32,REG32,0,0,0}, nasm_bytecodes+17792, IF_386},
    /*  712 */ {I_OR, 2, {MEMORY,REG64,0,0,0}, nasm_bytecodes+17797, IF_X64|IF_SM},
    /*  713 */ {I_OR, 2, {REG64,REG64,0,0,0}, nasm_bytecodes+17797, IF_X64},
    /*  714 */ {I_OR, 2, {REG8,MEMORY,0,0,0}, nasm_bytecodes+12357, IF_8086|IF_SM},
    /*  715 */ {I_OR, 2, {REG8,REG8,0,0,0}, nasm_bytecodes+12357, IF_8086},
    /*  716 */ {I_OR, 2, {REG16,MEMORY,0,0,0}, nasm_bytecodes+17802, IF_8086|IF_SM},
    /*  717 */ {I_OR, 2, {REG16,REG16,0,0,0}, nasm_bytecodes+17802, IF_8086},
    /*  718 */ {I_OR, 2, {REG32,MEMORY,0,0,0}, nasm_bytecodes+17807, IF_386|IF_SM},
    /*  719 */ {I_OR, 2, {REG32,REG32,0,0,0}, nasm_bytecodes+17807, IF_386},
    /*  720 */ {I_OR, 2, {REG64,MEMORY,0,0,0}, nasm_bytecodes+17812, IF_X64|IF_SM},
    /*  721 */ {I_OR, 2, {REG64,REG64,0,0,0}, nasm_bytecodes+17812, IF_X64},
    /*  722 */ {I_OR, 2, {RM_GPR|BITS16,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+13894, IF_8086},
    /*  723 */ {I_OR, 2, {RM_GPR|BITS32,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+13900, IF_386},
    /*  724 */ {I_OR, 2, {RM_GPR|BITS64,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+13906, IF_X64},
    /*  725 */ {I_OR, 2, {REG_AL,IMMEDIATE,0,0,0}, nasm_bytecodes+19315, IF_8086|IF_SM},
    /*  726 */ {I_OR, 2, {REG_AX,IMMEDIATE,0,0,0}, nasm_bytecodes+17817, IF_8086|IF_SM},
    /*  727 */ {I_OR, 2, {REG_EAX,IMMEDIATE,0,0,0}, nasm_bytecodes+17822, IF_386|IF_SM},
    /*  728 */ {I_OR, 2, {REG_RAX,IMMEDIATE,0,0,0}, nasm_bytecodes+17827, IF_X64|IF_SM},
    /*  729 */ {I_OR, 2, {RM_GPR|BITS8,IMMEDIATE,0,0,0}, nasm_bytecodes+17832, IF_8086|IF_SM},
    /*  730 */ {I_OR, 2, {RM_GPR|BITS16,IMMEDIATE,0,0,0}, nasm_bytecodes+13912, IF_8086|IF_SM},
    /*  731 */ {I_OR, 2, {RM_GPR|BITS32,IMMEDIATE,0,0,0}, nasm_bytecodes+13918, IF_386|IF_SM},
    /*  732 */ {I_OR, 2, {RM_GPR|BITS64,IMMEDIATE,0,0,0}, nasm_bytecodes+13924, IF_X64|IF_SM},
    /*  733 */ {I_OR, 2, {MEMORY,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+17832, IF_8086|IF_SM},
    /*  734 */ {I_OR, 2, {MEMORY,IMMEDIATE|BITS16,0,0,0}, nasm_bytecodes+13912, IF_8086|IF_SM},
    /*  735 */ {I_OR, 2, {MEMORY,IMMEDIATE|BITS32,0,0,0}, nasm_bytecodes+13918, IF_386|IF_SM},
    /*  736 */ {I_OUT, 2, {IMMEDIATE,REG_AL,0,0,0}, nasm_bytecodes+19319, IF_8086|IF_SB},
    /*  737 */ {I_OUT, 2, {IMMEDIATE,REG_AX,0,0,0}, nasm_bytecodes+17837, IF_8086|IF_SB},
    /*  738 */ {I_OUT, 2, {IMMEDIATE,REG_EAX,0,0,0}, nasm_bytecodes+17842, IF_386|IF_SB},
    /*  739 */ {I_OUT, 2, {REG_DX,REG_AL,0,0,0}, nasm_bytecodes+19676, IF_8086},
    /*  740 */ {I_OUT, 2, {REG_DX,REG_AX,0,0,0}, nasm_bytecodes+19323, IF_8086},
    /*  741 */ {I_OUT, 2, {REG_DX,REG_EAX,0,0,0}, nasm_bytecodes+19327, IF_386},
    /*  742 */ {I_OUTSB, 0, {0,0,0,0,0}, nasm_bytecodes+19679, IF_186},
    /*  743 */ {I_OUTSD, 0, {0,0,0,0,0}, nasm_bytecodes+19331, IF_386},
    /*  744 */ {I_OUTSW, 0, {0,0,0,0,0}, nasm_bytecodes+19335, IF_186},
    /*  745 */ {I_PACKSSDW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7377, IF_PENT|IF_MMX|IF_SQ},
    /*  746 */ {I_PACKSSWB, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7384, IF_PENT|IF_MMX|IF_SQ},
    /*  747 */ {I_PACKUSWB, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7391, IF_PENT|IF_MMX|IF_SQ},
    /*  748 */ {I_PADDB, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7398, IF_PENT|IF_MMX|IF_SQ},
    /*  749 */ {I_PADDD, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7405, IF_PENT|IF_MMX|IF_SQ},
    /*  750 */ {I_PADDSB, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7412, IF_PENT|IF_MMX|IF_SQ},
    /*  751 */ {I_PADDSIW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+13930, IF_PENT|IF_MMX|IF_SQ|IF_CYRIX},
    /*  752 */ {I_PADDSW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7419, IF_PENT|IF_MMX|IF_SQ},
    /*  753 */ {I_PADDUSB, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7426, IF_PENT|IF_MMX|IF_SQ},
    /*  754 */ {I_PADDUSW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7433, IF_PENT|IF_MMX|IF_SQ},
    /*  755 */ {I_PADDW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7440, IF_PENT|IF_MMX|IF_SQ},
    /*  756 */ {I_PAND, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7447, IF_PENT|IF_MMX|IF_SQ},
    /*  757 */ {I_PANDN, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7454, IF_PENT|IF_MMX|IF_SQ},
    /*  758 */ {I_PAUSE, 0, {0,0,0,0,0}, nasm_bytecodes+17847, IF_8086},
    /*  759 */ {I_PAVEB, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+13936, IF_PENT|IF_MMX|IF_SQ|IF_CYRIX},
    /*  760 */ {I_PAVGUSB, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+5598, IF_PENT|IF_3DNOW|IF_SQ},
    /*  761 */ {I_PCMPEQB, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7461, IF_PENT|IF_MMX|IF_SQ},
    /*  762 */ {I_PCMPEQD, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7468, IF_PENT|IF_MMX|IF_SQ},
    /*  763 */ {I_PCMPEQW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7475, IF_PENT|IF_MMX|IF_SQ},
    /*  764 */ {I_PCMPGTB, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7482, IF_PENT|IF_MMX|IF_SQ},
    /*  765 */ {I_PCMPGTD, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7489, IF_PENT|IF_MMX|IF_SQ},
    /*  766 */ {I_PCMPGTW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7496, IF_PENT|IF_MMX|IF_SQ},
    /*  767 */ {I_PDISTIB, 2, {MMXREG,MEMORY,0,0,0}, nasm_bytecodes+15107, IF_PENT|IF_MMX|IF_SM|IF_CYRIX},
    /*  768 */ {I_PF2ID, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+5606, IF_PENT|IF_3DNOW|IF_SQ},
    /*  769 */ {I_PFACC, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+5614, IF_PENT|IF_3DNOW|IF_SQ},
    /*  770 */ {I_PFADD, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+5622, IF_PENT|IF_3DNOW|IF_SQ},
    /*  771 */ {I_PFCMPEQ, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+5630, IF_PENT|IF_3DNOW|IF_SQ},
    /*  772 */ {I_PFCMPGE, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+5638, IF_PENT|IF_3DNOW|IF_SQ},
    /*  773 */ {I_PFCMPGT, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+5646, IF_PENT|IF_3DNOW|IF_SQ},
    /*  774 */ {I_PFMAX, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+5654, IF_PENT|IF_3DNOW|IF_SQ},
    /*  775 */ {I_PFMIN, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+5662, IF_PENT|IF_3DNOW|IF_SQ},
    /*  776 */ {I_PFMUL, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+5670, IF_PENT|IF_3DNOW|IF_SQ},
    /*  777 */ {I_PFRCP, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+5678, IF_PENT|IF_3DNOW|IF_SQ},
    /*  778 */ {I_PFRCPIT1, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+5686, IF_PENT|IF_3DNOW|IF_SQ},
    /*  779 */ {I_PFRCPIT2, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+5694, IF_PENT|IF_3DNOW|IF_SQ},
    /*  780 */ {I_PFRSQIT1, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+5702, IF_PENT|IF_3DNOW|IF_SQ},
    /*  781 */ {I_PFRSQRT, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+5710, IF_PENT|IF_3DNOW|IF_SQ},
    /*  782 */ {I_PFSUB, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+5718, IF_PENT|IF_3DNOW|IF_SQ},
    /*  783 */ {I_PFSUBR, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+5726, IF_PENT|IF_3DNOW|IF_SQ},
    /*  784 */ {I_PI2FD, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+5734, IF_PENT|IF_3DNOW|IF_SQ},
    /*  785 */ {I_PMACHRIW, 2, {MMXREG,MEMORY,0,0,0}, nasm_bytecodes+15203, IF_PENT|IF_MMX|IF_SM|IF_CYRIX},
    /*  786 */ {I_PMADDWD, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7503, IF_PENT|IF_MMX|IF_SQ},
    /*  787 */ {I_PMAGW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+13942, IF_PENT|IF_MMX|IF_SQ|IF_CYRIX},
    /*  788 */ {I_PMULHRIW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+13948, IF_PENT|IF_MMX|IF_SQ|IF_CYRIX},
    /*  789 */ {I_PMULHRWA, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+5742, IF_PENT|IF_3DNOW|IF_SQ},
    /*  790 */ {I_PMULHRWC, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+13954, IF_PENT|IF_MMX|IF_SQ|IF_CYRIX},
    /*  791 */ {I_PMULHW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7510, IF_PENT|IF_MMX|IF_SQ},
    /*  792 */ {I_PMULLW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7517, IF_PENT|IF_MMX|IF_SQ},
    /*  793 */ {I_PMVGEZB, 2, {MMXREG,MEMORY,0,0,0}, nasm_bytecodes+15353, IF_PENT|IF_MMX|IF_SQ|IF_CYRIX},
    /*  794 */ {I_PMVLZB, 2, {MMXREG,MEMORY,0,0,0}, nasm_bytecodes+15191, IF_PENT|IF_MMX|IF_SQ|IF_CYRIX},
    /*  795 */ {I_PMVNZB, 2, {MMXREG,MEMORY,0,0,0}, nasm_bytecodes+15173, IF_PENT|IF_MMX|IF_SQ|IF_CYRIX},
    /*  796 */ {I_PMVZB, 2, {MMXREG,MEMORY,0,0,0}, nasm_bytecodes+15095, IF_PENT|IF_MMX|IF_SQ|IF_CYRIX},
    /*  797 */ {I_POP, 1, {REG16,0,0,0,0}, nasm_bytecodes+19339, IF_8086},
    /*  798 */ {I_POP, 1, {REG32,0,0,0,0}, nasm_bytecodes+19343, IF_386|IF_NOLONG},
    /*  799 */ {I_POP, 1, {REG64,0,0,0,0}, nasm_bytecodes+19347, IF_X64},
    /*  800 */ {I_POP, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+17852, IF_8086},
    /*  801 */ {I_POP, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+17857, IF_386|IF_NOLONG},
    /*  802 */ {I_POP, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+17862, IF_X64},
    /*  803 */ {I_POP, 1, {REG_DESS,0,0,0,0}, nasm_bytecodes+19157, IF_8086|IF_NOLONG},
    /*  804 */ {I_POP, 1, {REG_FSGS,0,0,0,0}, nasm_bytecodes+19351, IF_386},
    /*  805 */ {I_POPA, 0, {0,0,0,0,0}, nasm_bytecodes+19355, IF_186|IF_NOLONG},
    /*  806 */ {I_POPAD, 0, {0,0,0,0,0}, nasm_bytecodes+19359, IF_386|IF_NOLONG},
    /*  807 */ {I_POPAW, 0, {0,0,0,0,0}, nasm_bytecodes+19363, IF_186|IF_NOLONG},
    /*  808 */ {I_POPF, 0, {0,0,0,0,0}, nasm_bytecodes+19367, IF_8086},
    /*  809 */ {I_POPFD, 0, {0,0,0,0,0}, nasm_bytecodes+19371, IF_386|IF_NOLONG},
    /*  810 */ {I_POPFQ, 0, {0,0,0,0,0}, nasm_bytecodes+19371, IF_X64},
    /*  811 */ {I_POPFW, 0, {0,0,0,0,0}, nasm_bytecodes+19375, IF_8086},
    /*  812 */ {I_POR, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7524, IF_PENT|IF_MMX|IF_SQ},
    /*  813 */ {I_PREFETCH, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+17867, IF_PENT|IF_3DNOW|IF_SQ},
    /*  814 */ {I_PREFETCHW, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+17872, IF_PENT|IF_3DNOW|IF_SQ},
    /*  815 */ {I_PSLLD, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7531, IF_PENT|IF_MMX|IF_SQ},
    /*  816 */ {I_PSLLD, 2, {MMXREG,IMMEDIATE,0,0,0}, nasm_bytecodes+7538, IF_PENT|IF_MMX},
    /*  817 */ {I_PSLLQ, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7545, IF_PENT|IF_MMX|IF_SQ},
    /*  818 */ {I_PSLLQ, 2, {MMXREG,IMMEDIATE,0,0,0}, nasm_bytecodes+7552, IF_PENT|IF_MMX},
    /*  819 */ {I_PSLLW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7559, IF_PENT|IF_MMX|IF_SQ},
    /*  820 */ {I_PSLLW, 2, {MMXREG,IMMEDIATE,0,0,0}, nasm_bytecodes+7566, IF_PENT|IF_MMX},
    /*  821 */ {I_PSRAD, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7573, IF_PENT|IF_MMX|IF_SQ},
    /*  822 */ {I_PSRAD, 2, {MMXREG,IMMEDIATE,0,0,0}, nasm_bytecodes+7580, IF_PENT|IF_MMX},
    /*  823 */ {I_PSRAW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7587, IF_PENT|IF_MMX|IF_SQ},
    /*  824 */ {I_PSRAW, 2, {MMXREG,IMMEDIATE,0,0,0}, nasm_bytecodes+7594, IF_PENT|IF_MMX},
    /*  825 */ {I_PSRLD, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7601, IF_PENT|IF_MMX|IF_SQ},
    /*  826 */ {I_PSRLD, 2, {MMXREG,IMMEDIATE,0,0,0}, nasm_bytecodes+7608, IF_PENT|IF_MMX},
    /*  827 */ {I_PSRLQ, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7615, IF_PENT|IF_MMX|IF_SQ},
    /*  828 */ {I_PSRLQ, 2, {MMXREG,IMMEDIATE,0,0,0}, nasm_bytecodes+7622, IF_PENT|IF_MMX},
    /*  829 */ {I_PSRLW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7629, IF_PENT|IF_MMX|IF_SQ},
    /*  830 */ {I_PSRLW, 2, {MMXREG,IMMEDIATE,0,0,0}, nasm_bytecodes+7636, IF_PENT|IF_MMX},
    /*  831 */ {I_PSUBB, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7643, IF_PENT|IF_MMX|IF_SQ},
    /*  832 */ {I_PSUBD, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7650, IF_PENT|IF_MMX|IF_SQ},
    /*  833 */ {I_PSUBSB, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7657, IF_PENT|IF_MMX|IF_SQ},
    /*  834 */ {I_PSUBSIW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+13960, IF_PENT|IF_MMX|IF_SQ|IF_CYRIX},
    /*  835 */ {I_PSUBSW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7664, IF_PENT|IF_MMX|IF_SQ},
    /*  836 */ {I_PSUBUSB, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7671, IF_PENT|IF_MMX|IF_SQ},
    /*  837 */ {I_PSUBUSW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7678, IF_PENT|IF_MMX|IF_SQ},
    /*  838 */ {I_PSUBW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7685, IF_PENT|IF_MMX|IF_SQ},
    /*  839 */ {I_PUNPCKHBW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7692, IF_PENT|IF_MMX|IF_SQ},
    /*  840 */ {I_PUNPCKHDQ, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7699, IF_PENT|IF_MMX|IF_SQ},
    /*  841 */ {I_PUNPCKHWD, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7706, IF_PENT|IF_MMX|IF_SQ},
    /*  842 */ {I_PUNPCKLBW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7713, IF_PENT|IF_MMX|IF_SQ},
    /*  843 */ {I_PUNPCKLDQ, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7720, IF_PENT|IF_MMX|IF_SQ},
    /*  844 */ {I_PUNPCKLWD, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7727, IF_PENT|IF_MMX|IF_SQ},
    /*  845 */ {I_PUSH, 1, {REG16,0,0,0,0}, nasm_bytecodes+19379, IF_8086},
    /*  846 */ {I_PUSH, 1, {REG32,0,0,0,0}, nasm_bytecodes+19383, IF_386|IF_NOLONG},
    /*  847 */ {I_PUSH, 1, {REG64,0,0,0,0}, nasm_bytecodes+19387, IF_X64},
    /*  848 */ {I_PUSH, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+17877, IF_8086},
    /*  849 */ {I_PUSH, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+17882, IF_386|IF_NOLONG},
    /*  850 */ {I_PUSH, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+17887, IF_X64},
    /*  851 */ {I_PUSH, 1, {REG_CS,0,0,0,0}, nasm_bytecodes+19133, IF_8086|IF_NOLONG},
    /*  852 */ {I_PUSH, 1, {REG_DESS,0,0,0,0}, nasm_bytecodes+19133, IF_8086|IF_NOLONG},
    /*  853 */ {I_PUSH, 1, {REG_FSGS,0,0,0,0}, nasm_bytecodes+19391, IF_386},
    /*  854 */ {I_PUSH, 1, {IMMEDIATE|BITS8,0,0,0,0}, nasm_bytecodes+19395, IF_186},
    /*  855 */ {I_PUSH, 1, {IMMEDIATE|BITS16,0,0,0,0}, nasm_bytecodes+17892, IF_186|IF_AR0|IF_SZ},
    /*  856 */ {I_PUSH, 1, {IMMEDIATE|BITS32,0,0,0,0}, nasm_bytecodes+17897, IF_386|IF_NOLONG|IF_AR0|IF_SZ},
    /*  857 */ {I_PUSH, 1, {IMMEDIATE|BITS32,0,0,0,0}, nasm_bytecodes+17897, IF_386|IF_NOLONG|IF_SD},
    /*  858 */ {I_PUSH, 1, {IMMEDIATE|BITS64,0,0,0,0}, nasm_bytecodes+17902, IF_X64|IF_AR0|IF_SZ},
    /*  859 */ {I_PUSHA, 0, {0,0,0,0,0}, nasm_bytecodes+19399, IF_186|IF_NOLONG},
    /*  860 */ {I_PUSHAD, 0, {0,0,0,0,0}, nasm_bytecodes+19403, IF_386|IF_NOLONG},
    /*  861 */ {I_PUSHAW, 0, {0,0,0,0,0}, nasm_bytecodes+19407, IF_186|IF_NOLONG},
    /*  862 */ {I_PUSHF, 0, {0,0,0,0,0}, nasm_bytecodes+19411, IF_8086},
    /*  863 */ {I_PUSHFD, 0, {0,0,0,0,0}, nasm_bytecodes+19415, IF_386|IF_NOLONG},
    /*  864 */ {I_PUSHFQ, 0, {0,0,0,0,0}, nasm_bytecodes+19415, IF_X64},
    /*  865 */ {I_PUSHFW, 0, {0,0,0,0,0}, nasm_bytecodes+19419, IF_8086},
    /*  866 */ {I_PXOR, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7734, IF_PENT|IF_MMX|IF_SQ},
    /*  867 */ {I_RCL, 2, {RM_GPR|BITS8,UNITY,0,0,0}, nasm_bytecodes+19423, IF_8086},
    /*  868 */ {I_RCL, 2, {RM_GPR|BITS8,REG_CL,0,0,0}, nasm_bytecodes+19427, IF_8086},
    /*  869 */ {I_RCL, 2, {RM_GPR|BITS8,IMMEDIATE,0,0,0}, nasm_bytecodes+17907, IF_186|IF_SB},
    /*  870 */ {I_RCL, 2, {RM_GPR|BITS16,UNITY,0,0,0}, nasm_bytecodes+17912, IF_8086},
    /*  871 */ {I_RCL, 2, {RM_GPR|BITS16,REG_CL,0,0,0}, nasm_bytecodes+17917, IF_8086},
    /*  872 */ {I_RCL, 2, {RM_GPR|BITS16,IMMEDIATE,0,0,0}, nasm_bytecodes+13966, IF_186|IF_SB},
    /*  873 */ {I_RCL, 2, {RM_GPR|BITS32,UNITY,0,0,0}, nasm_bytecodes+17922, IF_386},
    /*  874 */ {I_RCL, 2, {RM_GPR|BITS32,REG_CL,0,0,0}, nasm_bytecodes+17927, IF_386},
    /*  875 */ {I_RCL, 2, {RM_GPR|BITS32,IMMEDIATE,0,0,0}, nasm_bytecodes+13972, IF_386|IF_SB},
    /*  876 */ {I_RCL, 2, {RM_GPR|BITS64,UNITY,0,0,0}, nasm_bytecodes+17932, IF_X64},
    /*  877 */ {I_RCL, 2, {RM_GPR|BITS64,REG_CL,0,0,0}, nasm_bytecodes+17937, IF_X64},
    /*  878 */ {I_RCL, 2, {RM_GPR|BITS64,IMMEDIATE,0,0,0}, nasm_bytecodes+13978, IF_X64|IF_SB},
    /*  879 */ {I_RCR, 2, {RM_GPR|BITS8,UNITY,0,0,0}, nasm_bytecodes+19431, IF_8086},
    /*  880 */ {I_RCR, 2, {RM_GPR|BITS8,REG_CL,0,0,0}, nasm_bytecodes+19435, IF_8086},
    /*  881 */ {I_RCR, 2, {RM_GPR|BITS8,IMMEDIATE,0,0,0}, nasm_bytecodes+17942, IF_186|IF_SB},
    /*  882 */ {I_RCR, 2, {RM_GPR|BITS16,UNITY,0,0,0}, nasm_bytecodes+17947, IF_8086},
    /*  883 */ {I_RCR, 2, {RM_GPR|BITS16,REG_CL,0,0,0}, nasm_bytecodes+17952, IF_8086},
    /*  884 */ {I_RCR, 2, {RM_GPR|BITS16,IMMEDIATE,0,0,0}, nasm_bytecodes+13984, IF_186|IF_SB},
    /*  885 */ {I_RCR, 2, {RM_GPR|BITS32,UNITY,0,0,0}, nasm_bytecodes+17957, IF_386},
    /*  886 */ {I_RCR, 2, {RM_GPR|BITS32,REG_CL,0,0,0}, nasm_bytecodes+17962, IF_386},
    /*  887 */ {I_RCR, 2, {RM_GPR|BITS32,IMMEDIATE,0,0,0}, nasm_bytecodes+13990, IF_386|IF_SB},
    /*  888 */ {I_RCR, 2, {RM_GPR|BITS64,UNITY,0,0,0}, nasm_bytecodes+17967, IF_X64},
    /*  889 */ {I_RCR, 2, {RM_GPR|BITS64,REG_CL,0,0,0}, nasm_bytecodes+17972, IF_X64},
    /*  890 */ {I_RCR, 2, {RM_GPR|BITS64,IMMEDIATE,0,0,0}, nasm_bytecodes+13996, IF_X64|IF_SB},
    /*  891 */ {I_RDSHR, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+14002, IF_P6|IF_CYRIX|IF_SMM},
    /*  892 */ {I_RDMSR, 0, {0,0,0,0,0}, nasm_bytecodes+19439, IF_PENT|IF_PRIV},
    /*  893 */ {I_RDPMC, 0, {0,0,0,0,0}, nasm_bytecodes+19443, IF_P6},
    /*  894 */ {I_RDTSC, 0, {0,0,0,0,0}, nasm_bytecodes+19447, IF_PENT},
    /*  895 */ {I_RDTSCP, 0, {0,0,0,0,0}, nasm_bytecodes+17977, IF_X86_64},
    /*  896 */ {I_RET, 0, {0,0,0,0,0}, nasm_bytecodes+18524, IF_8086},
    /*  897 */ {I_RET, 1, {IMMEDIATE,0,0,0,0}, nasm_bytecodes+19451, IF_8086|IF_SW},
    /*  898 */ {I_RETF, 0, {0,0,0,0,0}, nasm_bytecodes+19682, IF_8086},
    /*  899 */ {I_RETF, 1, {IMMEDIATE,0,0,0,0}, nasm_bytecodes+19455, IF_8086|IF_SW},
    /*  900 */ {I_RETN, 0, {0,0,0,0,0}, nasm_bytecodes+18524, IF_8086},
    /*  901 */ {I_RETN, 1, {IMMEDIATE,0,0,0,0}, nasm_bytecodes+19451, IF_8086|IF_SW},
    /*  902 */ {I_ROL, 2, {RM_GPR|BITS8,UNITY,0,0,0}, nasm_bytecodes+19459, IF_8086},
    /*  903 */ {I_ROL, 2, {RM_GPR|BITS8,REG_CL,0,0,0}, nasm_bytecodes+19463, IF_8086},
    /*  904 */ {I_ROL, 2, {RM_GPR|BITS8,IMMEDIATE,0,0,0}, nasm_bytecodes+17982, IF_186|IF_SB},
    /*  905 */ {I_ROL, 2, {RM_GPR|BITS16,UNITY,0,0,0}, nasm_bytecodes+17987, IF_8086},
    /*  906 */ {I_ROL, 2, {RM_GPR|BITS16,REG_CL,0,0,0}, nasm_bytecodes+17992, IF_8086},
    /*  907 */ {I_ROL, 2, {RM_GPR|BITS16,IMMEDIATE,0,0,0}, nasm_bytecodes+14008, IF_186|IF_SB},
    /*  908 */ {I_ROL, 2, {RM_GPR|BITS32,UNITY,0,0,0}, nasm_bytecodes+17997, IF_386},
    /*  909 */ {I_ROL, 2, {RM_GPR|BITS32,REG_CL,0,0,0}, nasm_bytecodes+18002, IF_386},
    /*  910 */ {I_ROL, 2, {RM_GPR|BITS32,IMMEDIATE,0,0,0}, nasm_bytecodes+14014, IF_386|IF_SB},
    /*  911 */ {I_ROL, 2, {RM_GPR|BITS64,UNITY,0,0,0}, nasm_bytecodes+18007, IF_X64},
    /*  912 */ {I_ROL, 2, {RM_GPR|BITS64,REG_CL,0,0,0}, nasm_bytecodes+18012, IF_X64},
    /*  913 */ {I_ROL, 2, {RM_GPR|BITS64,IMMEDIATE,0,0,0}, nasm_bytecodes+14020, IF_X64|IF_SB},
    /*  914 */ {I_ROR, 2, {RM_GPR|BITS8,UNITY,0,0,0}, nasm_bytecodes+19467, IF_8086},
    /*  915 */ {I_ROR, 2, {RM_GPR|BITS8,REG_CL,0,0,0}, nasm_bytecodes+19471, IF_8086},
    /*  916 */ {I_ROR, 2, {RM_GPR|BITS8,IMMEDIATE,0,0,0}, nasm_bytecodes+18017, IF_186|IF_SB},
    /*  917 */ {I_ROR, 2, {RM_GPR|BITS16,UNITY,0,0,0}, nasm_bytecodes+18022, IF_8086},
    /*  918 */ {I_ROR, 2, {RM_GPR|BITS16,REG_CL,0,0,0}, nasm_bytecodes+18027, IF_8086},
    /*  919 */ {I_ROR, 2, {RM_GPR|BITS16,IMMEDIATE,0,0,0}, nasm_bytecodes+14026, IF_186|IF_SB},
    /*  920 */ {I_ROR, 2, {RM_GPR|BITS32,UNITY,0,0,0}, nasm_bytecodes+18032, IF_386},
    /*  921 */ {I_ROR, 2, {RM_GPR|BITS32,REG_CL,0,0,0}, nasm_bytecodes+18037, IF_386},
    /*  922 */ {I_ROR, 2, {RM_GPR|BITS32,IMMEDIATE,0,0,0}, nasm_bytecodes+14032, IF_386|IF_SB},
    /*  923 */ {I_ROR, 2, {RM_GPR|BITS64,UNITY,0,0,0}, nasm_bytecodes+18042, IF_X64},
    /*  924 */ {I_ROR, 2, {RM_GPR|BITS64,REG_CL,0,0,0}, nasm_bytecodes+18047, IF_X64},
    /*  925 */ {I_ROR, 2, {RM_GPR|BITS64,IMMEDIATE,0,0,0}, nasm_bytecodes+14038, IF_X64|IF_SB},
    /*  926 */ {I_RSDC, 2, {REG_SREG,MEMORY|BITS80,0,0,0}, nasm_bytecodes+15461, IF_486|IF_CYRIX|IF_SMM},
    /*  927 */ {I_RSLDT, 1, {MEMORY|BITS80,0,0,0,0}, nasm_bytecodes+18052, IF_486|IF_CYRIX|IF_SMM},
    /*  928 */ {I_RSM, 0, {0,0,0,0,0}, nasm_bytecodes+19475, IF_PENT|IF_SMM},
    /*  929 */ {I_RSTS, 1, {MEMORY|BITS80,0,0,0,0}, nasm_bytecodes+18057, IF_486|IF_CYRIX|IF_SMM},
    /*  930 */ {I_SAHF, 0, {0,0,0,0,0}, nasm_bytecodes+5627, IF_8086},
    /*  931 */ {I_SALC, 0, {0,0,0,0,0}, nasm_bytecodes+19685, IF_8086|IF_UNDOC},
    /*  932 */ {I_SAR, 2, {RM_GPR|BITS8,UNITY,0,0,0}, nasm_bytecodes+19487, IF_8086},
    /*  933 */ {I_SAR, 2, {RM_GPR|BITS8,REG_CL,0,0,0}, nasm_bytecodes+19491, IF_8086},
    /*  934 */ {I_SAR, 2, {RM_GPR|BITS8,IMMEDIATE,0,0,0}, nasm_bytecodes+18097, IF_186|IF_SB},
    /*  935 */ {I_SAR, 2, {RM_GPR|BITS16,UNITY,0,0,0}, nasm_bytecodes+18102, IF_8086},
    /*  936 */ {I_SAR, 2, {RM_GPR|BITS16,REG_CL,0,0,0}, nasm_bytecodes+18107, IF_8086},
    /*  937 */ {I_SAR, 2, {RM_GPR|BITS16,IMMEDIATE,0,0,0}, nasm_bytecodes+14062, IF_186|IF_SB},
    /*  938 */ {I_SAR, 2, {RM_GPR|BITS32,UNITY,0,0,0}, nasm_bytecodes+18112, IF_386},
    /*  939 */ {I_SAR, 2, {RM_GPR|BITS32,REG_CL,0,0,0}, nasm_bytecodes+18117, IF_386},
    /*  940 */ {I_SAR, 2, {RM_GPR|BITS32,IMMEDIATE,0,0,0}, nasm_bytecodes+14068, IF_386|IF_SB},
    /*  941 */ {I_SAR, 2, {RM_GPR|BITS64,UNITY,0,0,0}, nasm_bytecodes+18122, IF_X64},
    /*  942 */ {I_SAR, 2, {RM_GPR|BITS64,REG_CL,0,0,0}, nasm_bytecodes+18127, IF_X64},
    /*  943 */ {I_SAR, 2, {RM_GPR|BITS64,IMMEDIATE,0,0,0}, nasm_bytecodes+14074, IF_X64|IF_SB},
    /*  944 */ {I_SBB, 2, {MEMORY,REG8,0,0,0}, nasm_bytecodes+19495, IF_8086|IF_SM},
    /*  945 */ {I_SBB, 2, {REG8,REG8,0,0,0}, nasm_bytecodes+19495, IF_8086},
    /*  946 */ {I_SBB, 2, {MEMORY,REG16,0,0,0}, nasm_bytecodes+18132, IF_8086|IF_SM},
    /*  947 */ {I_SBB, 2, {REG16,REG16,0,0,0}, nasm_bytecodes+18132, IF_8086},
    /*  948 */ {I_SBB, 2, {MEMORY,REG32,0,0,0}, nasm_bytecodes+18137, IF_386|IF_SM},
    /*  949 */ {I_SBB, 2, {REG32,REG32,0,0,0}, nasm_bytecodes+18137, IF_386},
    /*  950 */ {I_SBB, 2, {MEMORY,REG64,0,0,0}, nasm_bytecodes+18142, IF_X64|IF_SM},
    /*  951 */ {I_SBB, 2, {REG64,REG64,0,0,0}, nasm_bytecodes+18142, IF_X64},
    /*  952 */ {I_SBB, 2, {REG8,MEMORY,0,0,0}, nasm_bytecodes+10061, IF_8086|IF_SM},
    /*  953 */ {I_SBB, 2, {REG8,REG8,0,0,0}, nasm_bytecodes+10061, IF_8086},
    /*  954 */ {I_SBB, 2, {REG16,MEMORY,0,0,0}, nasm_bytecodes+18147, IF_8086|IF_SM},
    /*  955 */ {I_SBB, 2, {REG16,REG16,0,0,0}, nasm_bytecodes+18147, IF_8086},
    /*  956 */ {I_SBB, 2, {REG32,MEMORY,0,0,0}, nasm_bytecodes+18152, IF_386|IF_SM},
    /*  957 */ {I_SBB, 2, {REG32,REG32,0,0,0}, nasm_bytecodes+18152, IF_386},
    /*  958 */ {I_SBB, 2, {REG64,MEMORY,0,0,0}, nasm_bytecodes+18157, IF_X64|IF_SM},
    /*  959 */ {I_SBB, 2, {REG64,REG64,0,0,0}, nasm_bytecodes+18157, IF_X64},
    /*  960 */ {I_SBB, 2, {RM_GPR|BITS16,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+14080, IF_8086},
    /*  961 */ {I_SBB, 2, {RM_GPR|BITS32,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+14086, IF_386},
    /*  962 */ {I_SBB, 2, {RM_GPR|BITS64,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+14092, IF_X64},
    /*  963 */ {I_SBB, 2, {REG_AL,IMMEDIATE,0,0,0}, nasm_bytecodes+19499, IF_8086|IF_SM},
    /*  964 */ {I_SBB, 2, {REG_AX,IMMEDIATE,0,0,0}, nasm_bytecodes+18162, IF_8086|IF_SM},
    /*  965 */ {I_SBB, 2, {REG_EAX,IMMEDIATE,0,0,0}, nasm_bytecodes+18167, IF_386|IF_SM},
    /*  966 */ {I_SBB, 2, {REG_RAX,IMMEDIATE,0,0,0}, nasm_bytecodes+18172, IF_X64|IF_SM},
    /*  967 */ {I_SBB, 2, {RM_GPR|BITS8,IMMEDIATE,0,0,0}, nasm_bytecodes+18177, IF_8086|IF_SM},
    /*  968 */ {I_SBB, 2, {RM_GPR|BITS16,IMMEDIATE,0,0,0}, nasm_bytecodes+14098, IF_8086|IF_SM},
    /*  969 */ {I_SBB, 2, {RM_GPR|BITS32,IMMEDIATE,0,0,0}, nasm_bytecodes+14104, IF_386|IF_SM},
    /*  970 */ {I_SBB, 2, {RM_GPR|BITS64,IMMEDIATE,0,0,0}, nasm_bytecodes+14110, IF_X64|IF_SM},
    /*  971 */ {I_SBB, 2, {MEMORY,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+18177, IF_8086|IF_SM},
    /*  972 */ {I_SBB, 2, {MEMORY,IMMEDIATE|BITS16,0,0,0}, nasm_bytecodes+14098, IF_8086|IF_SM},
    /*  973 */ {I_SBB, 2, {MEMORY,IMMEDIATE|BITS32,0,0,0}, nasm_bytecodes+14104, IF_386|IF_SM},
    /*  974 */ {I_SCASB, 0, {0,0,0,0,0}, nasm_bytecodes+19503, IF_8086},
    /*  975 */ {I_SCASD, 0, {0,0,0,0,0}, nasm_bytecodes+18182, IF_386},
    /*  976 */ {I_SCASQ, 0, {0,0,0,0,0}, nasm_bytecodes+18187, IF_X64},
    /*  977 */ {I_SCASW, 0, {0,0,0,0,0}, nasm_bytecodes+18192, IF_8086},
    /*  978 */ {I_SFENCE, 0, {0,0,0,0,0}, nasm_bytecodes+18197, IF_X64|IF_AMD},
    /*  979 */ {I_SGDT, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+18202, IF_286},
    /*  980 */ {I_SHL, 2, {RM_GPR|BITS8,UNITY,0,0,0}, nasm_bytecodes+19479, IF_8086},
    /*  981 */ {I_SHL, 2, {RM_GPR|BITS8,REG_CL,0,0,0}, nasm_bytecodes+19483, IF_8086},
    /*  982 */ {I_SHL, 2, {RM_GPR|BITS8,IMMEDIATE,0,0,0}, nasm_bytecodes+18062, IF_186|IF_SB},
    /*  983 */ {I_SHL, 2, {RM_GPR|BITS16,UNITY,0,0,0}, nasm_bytecodes+18067, IF_8086},
    /*  984 */ {I_SHL, 2, {RM_GPR|BITS16,REG_CL,0,0,0}, nasm_bytecodes+18072, IF_8086},
    /*  985 */ {I_SHL, 2, {RM_GPR|BITS16,IMMEDIATE,0,0,0}, nasm_bytecodes+14044, IF_186|IF_SB},
    /*  986 */ {I_SHL, 2, {RM_GPR|BITS32,UNITY,0,0,0}, nasm_bytecodes+18077, IF_386},
    /*  987 */ {I_SHL, 2, {RM_GPR|BITS32,REG_CL,0,0,0}, nasm_bytecodes+18082, IF_386},
    /*  988 */ {I_SHL, 2, {RM_GPR|BITS32,IMMEDIATE,0,0,0}, nasm_bytecodes+14050, IF_386|IF_SB},
    /*  989 */ {I_SHL, 2, {RM_GPR|BITS64,UNITY,0,0,0}, nasm_bytecodes+18087, IF_X64},
    /*  990 */ {I_SHL, 2, {RM_GPR|BITS64,REG_CL,0,0,0}, nasm_bytecodes+18092, IF_X64},
    /*  991 */ {I_SHL, 2, {RM_GPR|BITS64,IMMEDIATE,0,0,0}, nasm_bytecodes+14056, IF_X64|IF_SB},
    /*  992 */ {I_SHLD, 3, {MEMORY,REG16,IMMEDIATE,0,0}, nasm_bytecodes+7741, IF_386|IF_SM2|IF_SB|IF_AR2},
    /*  993 */ {I_SHLD, 3, {REG16,REG16,IMMEDIATE,0,0}, nasm_bytecodes+7741, IF_386|IF_SM2|IF_SB|IF_AR2},
    /*  994 */ {I_SHLD, 3, {MEMORY,REG32,IMMEDIATE,0,0}, nasm_bytecodes+7748, IF_386|IF_SM2|IF_SB|IF_AR2},
    /*  995 */ {I_SHLD, 3, {REG32,REG32,IMMEDIATE,0,0}, nasm_bytecodes+7748, IF_386|IF_SM2|IF_SB|IF_AR2},
    /*  996 */ {I_SHLD, 3, {MEMORY,REG64,IMMEDIATE,0,0}, nasm_bytecodes+7755, IF_X64|IF_SM2|IF_SB|IF_AR2},
    /*  997 */ {I_SHLD, 3, {REG64,REG64,IMMEDIATE,0,0}, nasm_bytecodes+7755, IF_X64|IF_SM2|IF_SB|IF_AR2},
    /*  998 */ {I_SHLD, 3, {MEMORY,REG16,REG_CL,0,0}, nasm_bytecodes+14116, IF_386|IF_SM},
    /*  999 */ {I_SHLD, 3, {REG16,REG16,REG_CL,0,0}, nasm_bytecodes+14116, IF_386},
    /* 1000 */ {I_SHLD, 3, {MEMORY,REG32,REG_CL,0,0}, nasm_bytecodes+14122, IF_386|IF_SM},
    /* 1001 */ {I_SHLD, 3, {REG32,REG32,REG_CL,0,0}, nasm_bytecodes+14122, IF_386},
    /* 1002 */ {I_SHLD, 3, {MEMORY,REG64,REG_CL,0,0}, nasm_bytecodes+14128, IF_X64|IF_SM},
    /* 1003 */ {I_SHLD, 3, {REG64,REG64,REG_CL,0,0}, nasm_bytecodes+14128, IF_X64},
    /* 1004 */ {I_SHR, 2, {RM_GPR|BITS8,UNITY,0,0,0}, nasm_bytecodes+19507, IF_8086},
    /* 1005 */ {I_SHR, 2, {RM_GPR|BITS8,REG_CL,0,0,0}, nasm_bytecodes+19511, IF_8086},
    /* 1006 */ {I_SHR, 2, {RM_GPR|BITS8,IMMEDIATE,0,0,0}, nasm_bytecodes+18207, IF_186|IF_SB},
    /* 1007 */ {I_SHR, 2, {RM_GPR|BITS16,UNITY,0,0,0}, nasm_bytecodes+18212, IF_8086},
    /* 1008 */ {I_SHR, 2, {RM_GPR|BITS16,REG_CL,0,0,0}, nasm_bytecodes+18217, IF_8086},
    /* 1009 */ {I_SHR, 2, {RM_GPR|BITS16,IMMEDIATE,0,0,0}, nasm_bytecodes+14134, IF_186|IF_SB},
    /* 1010 */ {I_SHR, 2, {RM_GPR|BITS32,UNITY,0,0,0}, nasm_bytecodes+18222, IF_386},
    /* 1011 */ {I_SHR, 2, {RM_GPR|BITS32,REG_CL,0,0,0}, nasm_bytecodes+18227, IF_386},
    /* 1012 */ {I_SHR, 2, {RM_GPR|BITS32,IMMEDIATE,0,0,0}, nasm_bytecodes+14140, IF_386|IF_SB},
    /* 1013 */ {I_SHR, 2, {RM_GPR|BITS64,UNITY,0,0,0}, nasm_bytecodes+18232, IF_X64},
    /* 1014 */ {I_SHR, 2, {RM_GPR|BITS64,REG_CL,0,0,0}, nasm_bytecodes+18237, IF_X64},
    /* 1015 */ {I_SHR, 2, {RM_GPR|BITS64,IMMEDIATE,0,0,0}, nasm_bytecodes+14146, IF_X64|IF_SB},
    /* 1016 */ {I_SHRD, 3, {MEMORY,REG16,IMMEDIATE,0,0}, nasm_bytecodes+7762, IF_386|IF_SM2|IF_SB|IF_AR2},
    /* 1017 */ {I_SHRD, 3, {REG16,REG16,IMMEDIATE,0,0}, nasm_bytecodes+7762, IF_386|IF_SM2|IF_SB|IF_AR2},
    /* 1018 */ {I_SHRD, 3, {MEMORY,REG32,IMMEDIATE,0,0}, nasm_bytecodes+7769, IF_386|IF_SM2|IF_SB|IF_AR2},
    /* 1019 */ {I_SHRD, 3, {REG32,REG32,IMMEDIATE,0,0}, nasm_bytecodes+7769, IF_386|IF_SM2|IF_SB|IF_AR2},
    /* 1020 */ {I_SHRD, 3, {MEMORY,REG64,IMMEDIATE,0,0}, nasm_bytecodes+7776, IF_X64|IF_SM2|IF_SB|IF_AR2},
    /* 1021 */ {I_SHRD, 3, {REG64,REG64,IMMEDIATE,0,0}, nasm_bytecodes+7776, IF_X64|IF_SM2|IF_SB|IF_AR2},
    /* 1022 */ {I_SHRD, 3, {MEMORY,REG16,REG_CL,0,0}, nasm_bytecodes+14152, IF_386|IF_SM},
    /* 1023 */ {I_SHRD, 3, {REG16,REG16,REG_CL,0,0}, nasm_bytecodes+14152, IF_386},
    /* 1024 */ {I_SHRD, 3, {MEMORY,REG32,REG_CL,0,0}, nasm_bytecodes+14158, IF_386|IF_SM},
    /* 1025 */ {I_SHRD, 3, {REG32,REG32,REG_CL,0,0}, nasm_bytecodes+14158, IF_386},
    /* 1026 */ {I_SHRD, 3, {MEMORY,REG64,REG_CL,0,0}, nasm_bytecodes+14164, IF_X64|IF_SM},
    /* 1027 */ {I_SHRD, 3, {REG64,REG64,REG_CL,0,0}, nasm_bytecodes+14164, IF_X64},
    /* 1028 */ {I_SIDT, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+18242, IF_286},
    /* 1029 */ {I_SLDT, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+14189, IF_286},
    /* 1030 */ {I_SLDT, 1, {MEMORY|BITS16,0,0,0,0}, nasm_bytecodes+14189, IF_286},
    /* 1031 */ {I_SLDT, 1, {REG16,0,0,0,0}, nasm_bytecodes+14170, IF_286},
    /* 1032 */ {I_SLDT, 1, {REG32,0,0,0,0}, nasm_bytecodes+14176, IF_386},
    /* 1033 */ {I_SLDT, 1, {REG64,0,0,0,0}, nasm_bytecodes+14188, IF_X64},
    /* 1034 */ {I_SKINIT, 0, {0,0,0,0,0}, nasm_bytecodes+18247, IF_X64},
    /* 1035 */ {I_SMI, 0, {0,0,0,0,0}, nasm_bytecodes+19655, IF_386|IF_UNDOC},
    /* 1036 */ {I_SMSW, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+14201, IF_286},
    /* 1037 */ {I_SMSW, 1, {MEMORY|BITS16,0,0,0,0}, nasm_bytecodes+14201, IF_286},
    /* 1038 */ {I_SMSW, 1, {REG16,0,0,0,0}, nasm_bytecodes+14194, IF_286},
    /* 1039 */ {I_SMSW, 1, {REG32,0,0,0,0}, nasm_bytecodes+14200, IF_386},
    /* 1040 */ {I_STC, 0, {0,0,0,0,0}, nasm_bytecodes+17979, IF_8086},
    /* 1041 */ {I_STD, 0, {0,0,0,0,0}, nasm_bytecodes+19688, IF_8086},
    /* 1042 */ {I_STGI, 0, {0,0,0,0,0}, nasm_bytecodes+18252, IF_X64},
    /* 1043 */ {I_STI, 0, {0,0,0,0,0}, nasm_bytecodes+19691, IF_8086},
    /* 1044 */ {I_STOSB, 0, {0,0,0,0,0}, nasm_bytecodes+5731, IF_8086},
    /* 1045 */ {I_STOSD, 0, {0,0,0,0,0}, nasm_bytecodes+19523, IF_386},
    /* 1046 */ {I_STOSQ, 0, {0,0,0,0,0}, nasm_bytecodes+19527, IF_X64},
    /* 1047 */ {I_STOSW, 0, {0,0,0,0,0}, nasm_bytecodes+19531, IF_8086},
    /* 1048 */ {I_STR, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+14219, IF_286|IF_PROT},
    /* 1049 */ {I_STR, 1, {MEMORY|BITS16,0,0,0,0}, nasm_bytecodes+14219, IF_286|IF_PROT},
    /* 1050 */ {I_STR, 1, {REG16,0,0,0,0}, nasm_bytecodes+14206, IF_286|IF_PROT},
    /* 1051 */ {I_STR, 1, {REG32,0,0,0,0}, nasm_bytecodes+14212, IF_386|IF_PROT},
    /* 1052 */ {I_STR, 1, {REG64,0,0,0,0}, nasm_bytecodes+14218, IF_X64},
    /* 1053 */ {I_SUB, 2, {MEMORY,REG8,0,0,0}, nasm_bytecodes+19535, IF_8086|IF_SM},
    /* 1054 */ {I_SUB, 2, {REG8,REG8,0,0,0}, nasm_bytecodes+19535, IF_8086},
    /* 1055 */ {I_SUB, 2, {MEMORY,REG16,0,0,0}, nasm_bytecodes+18257, IF_8086|IF_SM},
    /* 1056 */ {I_SUB, 2, {REG16,REG16,0,0,0}, nasm_bytecodes+18257, IF_8086},
    /* 1057 */ {I_SUB, 2, {MEMORY,REG32,0,0,0}, nasm_bytecodes+18262, IF_386|IF_SM},
    /* 1058 */ {I_SUB, 2, {REG32,REG32,0,0,0}, nasm_bytecodes+18262, IF_386},
    /* 1059 */ {I_SUB, 2, {MEMORY,REG64,0,0,0}, nasm_bytecodes+18267, IF_X64|IF_SM},
    /* 1060 */ {I_SUB, 2, {REG64,REG64,0,0,0}, nasm_bytecodes+18267, IF_X64},
    /* 1061 */ {I_SUB, 2, {REG8,MEMORY,0,0,0}, nasm_bytecodes+11076, IF_8086|IF_SM},
    /* 1062 */ {I_SUB, 2, {REG8,REG8,0,0,0}, nasm_bytecodes+11076, IF_8086},
    /* 1063 */ {I_SUB, 2, {REG16,MEMORY,0,0,0}, nasm_bytecodes+18272, IF_8086|IF_SM},
    /* 1064 */ {I_SUB, 2, {REG16,REG16,0,0,0}, nasm_bytecodes+18272, IF_8086},
    /* 1065 */ {I_SUB, 2, {REG32,MEMORY,0,0,0}, nasm_bytecodes+18277, IF_386|IF_SM},
    /* 1066 */ {I_SUB, 2, {REG32,REG32,0,0,0}, nasm_bytecodes+18277, IF_386},
    /* 1067 */ {I_SUB, 2, {REG64,MEMORY,0,0,0}, nasm_bytecodes+18282, IF_X64|IF_SM},
    /* 1068 */ {I_SUB, 2, {REG64,REG64,0,0,0}, nasm_bytecodes+18282, IF_X64},
    /* 1069 */ {I_SUB, 2, {RM_GPR|BITS16,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+14224, IF_8086},
    /* 1070 */ {I_SUB, 2, {RM_GPR|BITS32,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+14230, IF_386},
    /* 1071 */ {I_SUB, 2, {RM_GPR|BITS64,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+14236, IF_X64},
    /* 1072 */ {I_SUB, 2, {REG_AL,IMMEDIATE,0,0,0}, nasm_bytecodes+19539, IF_8086|IF_SM},
    /* 1073 */ {I_SUB, 2, {REG_AX,IMMEDIATE,0,0,0}, nasm_bytecodes+18287, IF_8086|IF_SM},
    /* 1074 */ {I_SUB, 2, {REG_EAX,IMMEDIATE,0,0,0}, nasm_bytecodes+18292, IF_386|IF_SM},
    /* 1075 */ {I_SUB, 2, {REG_RAX,IMMEDIATE,0,0,0}, nasm_bytecodes+18297, IF_X64|IF_SM},
    /* 1076 */ {I_SUB, 2, {RM_GPR|BITS8,IMMEDIATE,0,0,0}, nasm_bytecodes+18302, IF_8086|IF_SM},
    /* 1077 */ {I_SUB, 2, {RM_GPR|BITS16,IMMEDIATE,0,0,0}, nasm_bytecodes+14242, IF_8086|IF_SM},
    /* 1078 */ {I_SUB, 2, {RM_GPR|BITS32,IMMEDIATE,0,0,0}, nasm_bytecodes+14248, IF_386|IF_SM},
    /* 1079 */ {I_SUB, 2, {RM_GPR|BITS64,IMMEDIATE,0,0,0}, nasm_bytecodes+14254, IF_X64|IF_SM},
    /* 1080 */ {I_SUB, 2, {MEMORY,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+18302, IF_8086|IF_SM},
    /* 1081 */ {I_SUB, 2, {MEMORY,IMMEDIATE|BITS16,0,0,0}, nasm_bytecodes+14242, IF_8086|IF_SM},
    /* 1082 */ {I_SUB, 2, {MEMORY,IMMEDIATE|BITS32,0,0,0}, nasm_bytecodes+14248, IF_386|IF_SM},
    /* 1083 */ {I_SVDC, 2, {MEMORY|BITS80,REG_SREG,0,0,0}, nasm_bytecodes+8177, IF_486|IF_CYRIX|IF_SMM},
    /* 1084 */ {I_SVTS, 1, {MEMORY|BITS80,0,0,0,0}, nasm_bytecodes+18312, IF_486|IF_CYRIX|IF_SMM},
    /* 1085 */ {I_SWAPGS, 0, {0,0,0,0,0}, nasm_bytecodes+18317, IF_X64},
    /* 1086 */ {I_SYSCALL, 0, {0,0,0,0,0}, nasm_bytecodes+19243, IF_P6|IF_AMD},
    /* 1087 */ {I_SYSENTER, 0, {0,0,0,0,0}, nasm_bytecodes+19543, IF_P6},
    /* 1088 */ {I_SYSEXIT, 0, {0,0,0,0,0}, nasm_bytecodes+19547, IF_P6|IF_PRIV},
    /* 1089 */ {I_SYSRET, 0, {0,0,0,0,0}, nasm_bytecodes+19239, IF_P6|IF_PRIV|IF_AMD},
    /* 1090 */ {I_TEST, 2, {MEMORY,REG8,0,0,0}, nasm_bytecodes+19551, IF_8086|IF_SM},
    /* 1091 */ {I_TEST, 2, {REG8,REG8,0,0,0}, nasm_bytecodes+19551, IF_8086},
    /* 1092 */ {I_TEST, 2, {MEMORY,REG16,0,0,0}, nasm_bytecodes+18322, IF_8086|IF_SM},
    /* 1093 */ {I_TEST, 2, {REG16,REG16,0,0,0}, nasm_bytecodes+18322, IF_8086},
    /* 1094 */ {I_TEST, 2, {MEMORY,REG32,0,0,0}, nasm_bytecodes+18327, IF_386|IF_SM},
    /* 1095 */ {I_TEST, 2, {REG32,REG32,0,0,0}, nasm_bytecodes+18327, IF_386},
    /* 1096 */ {I_TEST, 2, {MEMORY,REG64,0,0,0}, nasm_bytecodes+18332, IF_X64|IF_SM},
    /* 1097 */ {I_TEST, 2, {REG64,REG64,0,0,0}, nasm_bytecodes+18332, IF_X64},
    /* 1098 */ {I_TEST, 2, {REG8,MEMORY,0,0,0}, nasm_bytecodes+19555, IF_8086|IF_SM},
    /* 1099 */ {I_TEST, 2, {REG16,MEMORY,0,0,0}, nasm_bytecodes+18337, IF_8086|IF_SM},
    /* 1100 */ {I_TEST, 2, {REG32,MEMORY,0,0,0}, nasm_bytecodes+18342, IF_386|IF_SM},
    /* 1101 */ {I_TEST, 2, {REG64,MEMORY,0,0,0}, nasm_bytecodes+18347, IF_X64|IF_SM},
    /* 1102 */ {I_TEST, 2, {REG_AL,IMMEDIATE,0,0,0}, nasm_bytecodes+19559, IF_8086|IF_SM},
    /* 1103 */ {I_TEST, 2, {REG_AX,IMMEDIATE,0,0,0}, nasm_bytecodes+18352, IF_8086|IF_SM},
    /* 1104 */ {I_TEST, 2, {REG_EAX,IMMEDIATE,0,0,0}, nasm_bytecodes+18357, IF_386|IF_SM},
    /* 1105 */ {I_TEST, 2, {REG_RAX,IMMEDIATE,0,0,0}, nasm_bytecodes+18362, IF_X64|IF_SM},
    /* 1106 */ {I_TEST, 2, {RM_GPR|BITS8,IMMEDIATE,0,0,0}, nasm_bytecodes+18367, IF_8086|IF_SM},
    /* 1107 */ {I_TEST, 2, {RM_GPR|BITS16,IMMEDIATE,0,0,0}, nasm_bytecodes+14260, IF_8086|IF_SM},
    /* 1108 */ {I_TEST, 2, {RM_GPR|BITS32,IMMEDIATE,0,0,0}, nasm_bytecodes+14266, IF_386|IF_SM},
    /* 1109 */ {I_TEST, 2, {RM_GPR|BITS64,IMMEDIATE,0,0,0}, nasm_bytecodes+14272, IF_X64|IF_SM},
    /* 1110 */ {I_TEST, 2, {MEMORY,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+18367, IF_8086|IF_SM},
    /* 1111 */ {I_TEST, 2, {MEMORY,IMMEDIATE|BITS16,0,0,0}, nasm_bytecodes+14260, IF_8086|IF_SM},
    /* 1112 */ {I_TEST, 2, {MEMORY,IMMEDIATE|BITS32,0,0,0}, nasm_bytecodes+14266, IF_386|IF_SM},
    /* 1113 */ {I_UD0, 0, {0,0,0,0,0}, nasm_bytecodes+19563, IF_186|IF_UNDOC},
    /* 1114 */ {I_UD1, 0, {0,0,0,0,0}, nasm_bytecodes+19567, IF_186|IF_UNDOC},
    /* 1115 */ {I_UD2, 0, {0,0,0,0,0}, nasm_bytecodes+19571, IF_186},
    /* 1116 */ {I_VERR, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+18372, IF_286|IF_PROT},
    /* 1117 */ {I_VERR, 1, {MEMORY|BITS16,0,0,0,0}, nasm_bytecodes+18372, IF_286|IF_PROT},
    /* 1118 */ {I_VERR, 1, {REG16,0,0,0,0}, nasm_bytecodes+18372, IF_286|IF_PROT},
    /* 1119 */ {I_VERW, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+18377, IF_286|IF_PROT},
    /* 1120 */ {I_VERW, 1, {MEMORY|BITS16,0,0,0,0}, nasm_bytecodes+18377, IF_286|IF_PROT},
    /* 1121 */ {I_VERW, 1, {REG16,0,0,0,0}, nasm_bytecodes+18377, IF_286|IF_PROT},
    /* 1122 */ {I_WAIT, 0, {0,0,0,0,0}, nasm_bytecodes+19694, IF_8086},
    /* 1123 */ {I_FWAIT, 0, {0,0,0,0,0}, nasm_bytecodes+19694, IF_8086},
    /* 1124 */ {I_WBINVD, 0, {0,0,0,0,0}, nasm_bytecodes+19575, IF_486|IF_PRIV},
    /* 1125 */ {I_WRSHR, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+14290, IF_P6|IF_CYRIX|IF_SMM},
    /* 1126 */ {I_WRMSR, 0, {0,0,0,0,0}, nasm_bytecodes+19579, IF_PENT|IF_PRIV},
    /* 1127 */ {I_XADD, 2, {MEMORY,REG8,0,0,0}, nasm_bytecodes+18382, IF_486|IF_SM},
    /* 1128 */ {I_XADD, 2, {REG8,REG8,0,0,0}, nasm_bytecodes+18382, IF_486},
    /* 1129 */ {I_XADD, 2, {MEMORY,REG16,0,0,0}, nasm_bytecodes+14296, IF_486|IF_SM},
    /* 1130 */ {I_XADD, 2, {REG16,REG16,0,0,0}, nasm_bytecodes+14296, IF_486},
    /* 1131 */ {I_XADD, 2, {MEMORY,REG32,0,0,0}, nasm_bytecodes+14302, IF_486|IF_SM},
    /* 1132 */ {I_XADD, 2, {REG32,REG32,0,0,0}, nasm_bytecodes+14302, IF_486},
    /* 1133 */ {I_XADD, 2, {MEMORY,REG64,0,0,0}, nasm_bytecodes+14308, IF_X64|IF_SM},
    /* 1134 */ {I_XADD, 2, {REG64,REG64,0,0,0}, nasm_bytecodes+14308, IF_X64},
    /* 1135 */ {I_XCHG, 2, {REG_AX,REG16,0,0,0}, nasm_bytecodes+19583, IF_8086},
    /* 1136 */ {I_XCHG, 2, {REG_EAX,REG32NA,0,0,0}, nasm_bytecodes+19587, IF_386},
    /* 1137 */ {I_XCHG, 2, {REG_RAX,REG64,0,0,0}, nasm_bytecodes+19591, IF_X64},
    /* 1138 */ {I_XCHG, 2, {REG16,REG_AX,0,0,0}, nasm_bytecodes+19595, IF_8086},
    /* 1139 */ {I_XCHG, 2, {REG32NA,REG_EAX,0,0,0}, nasm_bytecodes+19599, IF_386},
    /* 1140 */ {I_XCHG, 2, {REG64,REG_RAX,0,0,0}, nasm_bytecodes+19603, IF_X64},
    /* 1141 */ {I_XCHG, 2, {REG_EAX,REG_EAX,0,0,0}, nasm_bytecodes+19607, IF_386|IF_NOLONG},
    /* 1142 */ {I_XCHG, 2, {REG8,MEMORY,0,0,0}, nasm_bytecodes+19611, IF_8086|IF_SM},
    /* 1143 */ {I_XCHG, 2, {REG8,REG8,0,0,0}, nasm_bytecodes+19611, IF_8086},
    /* 1144 */ {I_XCHG, 2, {REG16,MEMORY,0,0,0}, nasm_bytecodes+18387, IF_8086|IF_SM},
    /* 1145 */ {I_XCHG, 2, {REG16,REG16,0,0,0}, nasm_bytecodes+18387, IF_8086},
    /* 1146 */ {I_XCHG, 2, {REG32,MEMORY,0,0,0}, nasm_bytecodes+18392, IF_386|IF_SM},
    /* 1147 */ {I_XCHG, 2, {REG32,REG32,0,0,0}, nasm_bytecodes+18392, IF_386},
    /* 1148 */ {I_XCHG, 2, {REG64,MEMORY,0,0,0}, nasm_bytecodes+18397, IF_X64|IF_SM},
    /* 1149 */ {I_XCHG, 2, {REG64,REG64,0,0,0}, nasm_bytecodes+18397, IF_X64},
    /* 1150 */ {I_XCHG, 2, {MEMORY,REG8,0,0,0}, nasm_bytecodes+19615, IF_8086|IF_SM},
    /* 1151 */ {I_XCHG, 2, {REG8,REG8,0,0,0}, nasm_bytecodes+19615, IF_8086},
    /* 1152 */ {I_XCHG, 2, {MEMORY,REG16,0,0,0}, nasm_bytecodes+18402, IF_8086|IF_SM},
    /* 1153 */ {I_XCHG, 2, {REG16,REG16,0,0,0}, nasm_bytecodes+18402, IF_8086},
    /* 1154 */ {I_XCHG, 2, {MEMORY,REG32,0,0,0}, nasm_bytecodes+18407, IF_386|IF_SM},
    /* 1155 */ {I_XCHG, 2, {REG32,REG32,0,0,0}, nasm_bytecodes+18407, IF_386},
    /* 1156 */ {I_XCHG, 2, {MEMORY,REG64,0,0,0}, nasm_bytecodes+18412, IF_X64|IF_SM},
    /* 1157 */ {I_XCHG, 2, {REG64,REG64,0,0,0}, nasm_bytecodes+18412, IF_X64},
    /* 1158 */ {I_XLATB, 0, {0,0,0,0,0}, nasm_bytecodes+19697, IF_8086},
    /* 1159 */ {I_XLAT, 0, {0,0,0,0,0}, nasm_bytecodes+19697, IF_8086},
    /* 1160 */ {I_XOR, 2, {MEMORY,REG8,0,0,0}, nasm_bytecodes+19619, IF_8086|IF_SM},
    /* 1161 */ {I_XOR, 2, {REG8,REG8,0,0,0}, nasm_bytecodes+19619, IF_8086},
    /* 1162 */ {I_XOR, 2, {MEMORY,REG16,0,0,0}, nasm_bytecodes+18417, IF_8086|IF_SM},
    /* 1163 */ {I_XOR, 2, {REG16,REG16,0,0,0}, nasm_bytecodes+18417, IF_8086},
    /* 1164 */ {I_XOR, 2, {MEMORY,REG32,0,0,0}, nasm_bytecodes+18422, IF_386|IF_SM},
    /* 1165 */ {I_XOR, 2, {REG32,REG32,0,0,0}, nasm_bytecodes+18422, IF_386},
    /* 1166 */ {I_XOR, 2, {MEMORY,REG64,0,0,0}, nasm_bytecodes+18427, IF_X64|IF_SM},
    /* 1167 */ {I_XOR, 2, {REG64,REG64,0,0,0}, nasm_bytecodes+18427, IF_X64},
    /* 1168 */ {I_XOR, 2, {REG8,MEMORY,0,0,0}, nasm_bytecodes+12154, IF_8086|IF_SM},
    /* 1169 */ {I_XOR, 2, {REG8,REG8,0,0,0}, nasm_bytecodes+12154, IF_8086},
    /* 1170 */ {I_XOR, 2, {REG16,MEMORY,0,0,0}, nasm_bytecodes+18432, IF_8086|IF_SM},
    /* 1171 */ {I_XOR, 2, {REG16,REG16,0,0,0}, nasm_bytecodes+18432, IF_8086},
    /* 1172 */ {I_XOR, 2, {REG32,MEMORY,0,0,0}, nasm_bytecodes+18437, IF_386|IF_SM},
    /* 1173 */ {I_XOR, 2, {REG32,REG32,0,0,0}, nasm_bytecodes+18437, IF_386},
    /* 1174 */ {I_XOR, 2, {REG64,MEMORY,0,0,0}, nasm_bytecodes+18442, IF_X64|IF_SM},
    /* 1175 */ {I_XOR, 2, {REG64,REG64,0,0,0}, nasm_bytecodes+18442, IF_X64},
    /* 1176 */ {I_XOR, 2, {RM_GPR|BITS16,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+14326, IF_8086},
    /* 1177 */ {I_XOR, 2, {RM_GPR|BITS32,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+14332, IF_386},
    /* 1178 */ {I_XOR, 2, {RM_GPR|BITS64,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+14338, IF_X64},
    /* 1179 */ {I_XOR, 2, {REG_AL,IMMEDIATE,0,0,0}, nasm_bytecodes+19623, IF_8086|IF_SM},
    /* 1180 */ {I_XOR, 2, {REG_AX,IMMEDIATE,0,0,0}, nasm_bytecodes+18447, IF_8086|IF_SM},
    /* 1181 */ {I_XOR, 2, {REG_EAX,IMMEDIATE,0,0,0}, nasm_bytecodes+18452, IF_386|IF_SM},
    /* 1182 */ {I_XOR, 2, {REG_RAX,IMMEDIATE,0,0,0}, nasm_bytecodes+18457, IF_X64|IF_SM},
    /* 1183 */ {I_XOR, 2, {RM_GPR|BITS8,IMMEDIATE,0,0,0}, nasm_bytecodes+18462, IF_8086|IF_SM},
    /* 1184 */ {I_XOR, 2, {RM_GPR|BITS16,IMMEDIATE,0,0,0}, nasm_bytecodes+14344, IF_8086|IF_SM},
    /* 1185 */ {I_XOR, 2, {RM_GPR|BITS32,IMMEDIATE,0,0,0}, nasm_bytecodes+14350, IF_386|IF_SM},
    /* 1186 */ {I_XOR, 2, {RM_GPR|BITS64,IMMEDIATE,0,0,0}, nasm_bytecodes+14356, IF_X64|IF_SM},
    /* 1187 */ {I_XOR, 2, {MEMORY,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+18462, IF_8086|IF_SM},
    /* 1188 */ {I_XOR, 2, {MEMORY,IMMEDIATE|BITS16,0,0,0}, nasm_bytecodes+14344, IF_8086|IF_SM},
    /* 1189 */ {I_XOR, 2, {MEMORY,IMMEDIATE|BITS32,0,0,0}, nasm_bytecodes+14350, IF_386|IF_SM},
    /* 1190 */ {I_CMOVcc, 2, {REG16,MEMORY,0,0,0}, nasm_bytecodes+7811, IF_P6|IF_SM},
    /* 1191 */ {I_CMOVcc, 2, {REG16,REG16,0,0,0}, nasm_bytecodes+7811, IF_P6},
    /* 1192 */ {I_CMOVcc, 2, {REG32,MEMORY,0,0,0}, nasm_bytecodes+7818, IF_P6|IF_SM},
    /* 1193 */ {I_CMOVcc, 2, {REG32,REG32,0,0,0}, nasm_bytecodes+7818, IF_P6},
    /* 1194 */ {I_CMOVcc, 2, {REG64,MEMORY,0,0,0}, nasm_bytecodes+7825, IF_X64|IF_SM},
    /* 1195 */ {I_CMOVcc, 2, {REG64,REG64,0,0,0}, nasm_bytecodes+7825, IF_X64},
    /* 1196 */ {I_Jcc, 1, {IMMEDIATE|NEAR,0,0,0,0}, nasm_bytecodes+7832, IF_386},
    /* 1197 */ {I_Jcc, 1, {IMMEDIATE|BITS16|NEAR,0,0,0,0}, nasm_bytecodes+7839, IF_386},
    /* 1198 */ {I_Jcc, 1, {IMMEDIATE|BITS32|NEAR,0,0,0,0}, nasm_bytecodes+7846, IF_386},
    /* 1199 */ {I_Jcc, 1, {IMMEDIATE,0,0,0,0}, nasm_bytecodes+18468, IF_8086},
    /* 1200 */ {I_SETcc, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+14362, IF_386|IF_SB},
    /* 1201 */ {I_SETcc, 1, {REG8,0,0,0,0}, nasm_bytecodes+14362, IF_386},
    /* 1202 */ {I_ADDPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14368, IF_KATMAI|IF_SSE},
    /* 1203 */ {I_ADDSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14374, IF_KATMAI|IF_SSE|IF_SD},
    /* 1204 */ {I_ANDNPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14380, IF_KATMAI|IF_SSE},
    /* 1205 */ {I_ANDPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14386, IF_KATMAI|IF_SSE},
    /* 1206 */ {I_CMPEQPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+5750, IF_KATMAI|IF_SSE},
    /* 1207 */ {I_CMPEQSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+5758, IF_KATMAI|IF_SSE},
    /* 1208 */ {I_CMPLEPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+5766, IF_KATMAI|IF_SSE},
    /* 1209 */ {I_CMPLESS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+5774, IF_KATMAI|IF_SSE},
    /* 1210 */ {I_CMPLTPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+5782, IF_KATMAI|IF_SSE},
    /* 1211 */ {I_CMPLTSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+5790, IF_KATMAI|IF_SSE},
    /* 1212 */ {I_CMPNEQPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+5798, IF_KATMAI|IF_SSE},
    /* 1213 */ {I_CMPNEQSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+5806, IF_KATMAI|IF_SSE},
    /* 1214 */ {I_CMPNLEPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+5814, IF_KATMAI|IF_SSE},
    /* 1215 */ {I_CMPNLESS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+5822, IF_KATMAI|IF_SSE},
    /* 1216 */ {I_CMPNLTPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+5830, IF_KATMAI|IF_SSE},
    /* 1217 */ {I_CMPNLTSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+5838, IF_KATMAI|IF_SSE},
    /* 1218 */ {I_CMPORDPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+5846, IF_KATMAI|IF_SSE},
    /* 1219 */ {I_CMPORDSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+5854, IF_KATMAI|IF_SSE},
    /* 1220 */ {I_CMPUNORDPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+5862, IF_KATMAI|IF_SSE},
    /* 1221 */ {I_CMPUNORDSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+5870, IF_KATMAI|IF_SSE},
    /* 1222 */ {I_CMPPS, 3, {XMMREG,MEMORY,IMMEDIATE,0,0}, nasm_bytecodes+7860, IF_KATMAI|IF_SSE|IF_SB|IF_AR2},
    /* 1223 */ {I_CMPPS, 3, {XMMREG,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+7860, IF_KATMAI|IF_SSE|IF_SB|IF_AR2},
    /* 1224 */ {I_CMPSS, 3, {XMMREG,MEMORY,IMMEDIATE,0,0}, nasm_bytecodes+7867, IF_KATMAI|IF_SSE|IF_SB|IF_AR2},
    /* 1225 */ {I_CMPSS, 3, {XMMREG,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+7867, IF_KATMAI|IF_SSE|IF_SB|IF_AR2},
    /* 1226 */ {I_COMISS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14392, IF_KATMAI|IF_SSE},
    /* 1227 */ {I_CVTPI2PS, 2, {XMMREG,RM_MMX,0,0,0}, nasm_bytecodes+14398, IF_KATMAI|IF_SSE|IF_MMX|IF_SQ},
    /* 1228 */ {I_CVTPS2PI, 2, {MMXREG,RM_XMM,0,0,0}, nasm_bytecodes+14404, IF_KATMAI|IF_SSE|IF_MMX|IF_SQ},
    /* 1229 */ {I_CVTSI2SS, 2, {XMMREG,RM_GPR|BITS32,0,0,0}, nasm_bytecodes+7875, IF_KATMAI|IF_SSE|IF_SD|IF_AR1},
    /* 1230 */ {I_CVTSI2SS, 2, {XMMREG,RM_GPR|BITS64,0,0,0}, nasm_bytecodes+7874, IF_X64|IF_SSE|IF_SQ|IF_AR1},
    /* 1231 */ {I_CVTSS2SI, 2, {REG32,XMMREG,0,0,0}, nasm_bytecodes+7882, IF_KATMAI|IF_SSE|IF_SD|IF_AR1},
    /* 1232 */ {I_CVTSS2SI, 2, {REG32,MEMORY,0,0,0}, nasm_bytecodes+7882, IF_KATMAI|IF_SSE|IF_SD|IF_AR1},
    /* 1233 */ {I_CVTSS2SI, 2, {REG64,XMMREG,0,0,0}, nasm_bytecodes+7881, IF_X64|IF_SSE|IF_SD|IF_AR1},
    /* 1234 */ {I_CVTSS2SI, 2, {REG64,MEMORY,0,0,0}, nasm_bytecodes+7881, IF_X64|IF_SSE|IF_SD|IF_AR1},
    /* 1235 */ {I_CVTTPS2PI, 2, {MMXREG,RM_XMM,0,0,0}, nasm_bytecodes+14410, IF_KATMAI|IF_SSE|IF_MMX|IF_SQ},
    /* 1236 */ {I_CVTTSS2SI, 2, {REG32,RM_XMM,0,0,0}, nasm_bytecodes+7889, IF_KATMAI|IF_SSE|IF_SD|IF_AR1},
    /* 1237 */ {I_CVTTSS2SI, 2, {REG64,RM_XMM,0,0,0}, nasm_bytecodes+7888, IF_X64|IF_SSE|IF_SD|IF_AR1},
    /* 1238 */ {I_DIVPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14416, IF_KATMAI|IF_SSE},
    /* 1239 */ {I_DIVSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14422, IF_KATMAI|IF_SSE},
    /* 1240 */ {I_LDMXCSR, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+18472, IF_KATMAI|IF_SSE|IF_SD},
    /* 1241 */ {I_MAXPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14428, IF_KATMAI|IF_SSE},
    /* 1242 */ {I_MAXSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14434, IF_KATMAI|IF_SSE},
    /* 1243 */ {I_MINPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14440, IF_KATMAI|IF_SSE},
    /* 1244 */ {I_MINSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14446, IF_KATMAI|IF_SSE},
    /* 1245 */ {I_MOVAPS, 2, {XMMREG,MEMORY,0,0,0}, nasm_bytecodes+14452, IF_KATMAI|IF_SSE},
    /* 1246 */ {I_MOVAPS, 2, {MEMORY,XMMREG,0,0,0}, nasm_bytecodes+14458, IF_KATMAI|IF_SSE},
    /* 1247 */ {I_MOVAPS, 2, {XMMREG,XMMREG,0,0,0}, nasm_bytecodes+14452, IF_KATMAI|IF_SSE},
    /* 1248 */ {I_MOVAPS, 2, {XMMREG,XMMREG,0,0,0}, nasm_bytecodes+14458, IF_KATMAI|IF_SSE},
    /* 1249 */ {I_MOVHPS, 2, {XMMREG,MEMORY,0,0,0}, nasm_bytecodes+14464, IF_KATMAI|IF_SSE},
    /* 1250 */ {I_MOVHPS, 2, {MEMORY,XMMREG,0,0,0}, nasm_bytecodes+14470, IF_KATMAI|IF_SSE},
    /* 1251 */ {I_MOVLHPS, 2, {XMMREG,XMMREG,0,0,0}, nasm_bytecodes+14464, IF_KATMAI|IF_SSE},
    /* 1252 */ {I_MOVLPS, 2, {XMMREG,MEMORY,0,0,0}, nasm_bytecodes+14284, IF_KATMAI|IF_SSE},
    /* 1253 */ {I_MOVLPS, 2, {MEMORY,XMMREG,0,0,0}, nasm_bytecodes+14476, IF_KATMAI|IF_SSE},
    /* 1254 */ {I_MOVHLPS, 2, {XMMREG,XMMREG,0,0,0}, nasm_bytecodes+14284, IF_KATMAI|IF_SSE},
    /* 1255 */ {I_MOVMSKPS, 2, {REG32,XMMREG,0,0,0}, nasm_bytecodes+14482, IF_KATMAI|IF_SSE},
    /* 1256 */ {I_MOVMSKPS, 2, {REG64,XMMREG,0,0,0}, nasm_bytecodes+7895, IF_X64|IF_SSE},
    /* 1257 */ {I_MOVNTPS, 2, {MEMORY,XMMREG,0,0,0}, nasm_bytecodes+14488, IF_KATMAI|IF_SSE},
    /* 1258 */ {I_MOVSS, 2, {XMMREG,MEMORY,0,0,0}, nasm_bytecodes+14494, IF_KATMAI|IF_SSE},
    /* 1259 */ {I_MOVSS, 2, {MEMORY,XMMREG,0,0,0}, nasm_bytecodes+14500, IF_KATMAI|IF_SSE},
    /* 1260 */ {I_MOVSS, 2, {XMMREG,XMMREG,0,0,0}, nasm_bytecodes+14494, IF_KATMAI|IF_SSE},
    /* 1261 */ {I_MOVSS, 2, {XMMREG,XMMREG,0,0,0}, nasm_bytecodes+14500, IF_KATMAI|IF_SSE},
    /* 1262 */ {I_MOVUPS, 2, {XMMREG,MEMORY,0,0,0}, nasm_bytecodes+14506, IF_KATMAI|IF_SSE},
    /* 1263 */ {I_MOVUPS, 2, {MEMORY,XMMREG,0,0,0}, nasm_bytecodes+14512, IF_KATMAI|IF_SSE},
    /* 1264 */ {I_MOVUPS, 2, {XMMREG,XMMREG,0,0,0}, nasm_bytecodes+14506, IF_KATMAI|IF_SSE},
    /* 1265 */ {I_MOVUPS, 2, {XMMREG,XMMREG,0,0,0}, nasm_bytecodes+14512, IF_KATMAI|IF_SSE},
    /* 1266 */ {I_MULPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14518, IF_KATMAI|IF_SSE},
    /* 1267 */ {I_MULSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14524, IF_KATMAI|IF_SSE},
    /* 1268 */ {I_ORPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14530, IF_KATMAI|IF_SSE},
    /* 1269 */ {I_RCPPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14536, IF_KATMAI|IF_SSE},
    /* 1270 */ {I_RCPSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14542, IF_KATMAI|IF_SSE},
    /* 1271 */ {I_RSQRTPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14548, IF_KATMAI|IF_SSE},
    /* 1272 */ {I_RSQRTSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14554, IF_KATMAI|IF_SSE},
    /* 1273 */ {I_SHUFPS, 3, {XMMREG,MEMORY,IMMEDIATE,0,0}, nasm_bytecodes+7902, IF_KATMAI|IF_SSE|IF_SB|IF_AR2},
    /* 1274 */ {I_SHUFPS, 3, {XMMREG,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+7902, IF_KATMAI|IF_SSE|IF_SB|IF_AR2},
    /* 1275 */ {I_SQRTPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14560, IF_KATMAI|IF_SSE},
    /* 1276 */ {I_SQRTSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14566, IF_KATMAI|IF_SSE},
    /* 1277 */ {I_STMXCSR, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+18477, IF_KATMAI|IF_SSE|IF_SD},
    /* 1278 */ {I_SUBPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14572, IF_KATMAI|IF_SSE},
    /* 1279 */ {I_SUBSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14578, IF_KATMAI|IF_SSE},
    /* 1280 */ {I_UCOMISS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14584, IF_KATMAI|IF_SSE},
    /* 1281 */ {I_UNPCKHPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14590, IF_KATMAI|IF_SSE},
    /* 1282 */ {I_UNPCKLPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14596, IF_KATMAI|IF_SSE},
    /* 1283 */ {I_XORPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14602, IF_KATMAI|IF_SSE},
    /* 1284 */ {I_FXRSTOR, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+18482, IF_P6|IF_SSE|IF_FPU},
    /* 1285 */ {I_FXSAVE, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+18487, IF_P6|IF_SSE|IF_FPU},
    /* 1286 */ {I_XGETBV, 0, {0,0,0,0,0}, nasm_bytecodes+14608, IF_NEHALEM},
    /* 1287 */ {I_XSETBV, 0, {0,0,0,0,0}, nasm_bytecodes+14614, IF_NEHALEM|IF_PRIV},
    /* 1288 */ {I_XSAVE, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+14620, IF_NEHALEM},
    /* 1289 */ {I_XRSTOR, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+14626, IF_NEHALEM},
    /* 1290 */ {I_PREFETCHNTA, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+15551, IF_KATMAI},
    /* 1291 */ {I_PREFETCHT0, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+15569, IF_KATMAI},
    /* 1292 */ {I_PREFETCHT1, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+15587, IF_KATMAI},
    /* 1293 */ {I_PREFETCHT2, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+15605, IF_KATMAI},
    /* 1294 */ {I_SFENCE, 0, {0,0,0,0,0}, nasm_bytecodes+18197, IF_KATMAI},
    /* 1295 */ {I_MASKMOVQ, 2, {MMXREG,MMXREG,0,0,0}, nasm_bytecodes+14632, IF_KATMAI|IF_MMX},
    /* 1296 */ {I_MOVNTQ, 2, {MEMORY,MMXREG,0,0,0}, nasm_bytecodes+14638, IF_KATMAI|IF_MMX|IF_SQ},
    /* 1297 */ {I_PAVGB, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7909, IF_KATMAI|IF_MMX|IF_SQ},
    /* 1298 */ {I_PAVGW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7916, IF_KATMAI|IF_MMX|IF_SQ},
    /* 1299 */ {I_PEXTRW, 3, {REG32,MMXREG,IMMEDIATE,0,0}, nasm_bytecodes+7923, IF_KATMAI|IF_MMX|IF_SB|IF_AR2},
    /* 1300 */ {I_PINSRW, 3, {MMXREG,REG16,IMMEDIATE,0,0}, nasm_bytecodes+7930, IF_KATMAI|IF_MMX|IF_SB|IF_AR2},
    /* 1301 */ {I_PINSRW, 3, {MMXREG,MEMORY,IMMEDIATE,0,0}, nasm_bytecodes+7930, IF_KATMAI|IF_MMX|IF_SB|IF_AR2},
    /* 1302 */ {I_PMAXSW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7937, IF_KATMAI|IF_MMX|IF_SQ},
    /* 1303 */ {I_PMAXUB, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7944, IF_KATMAI|IF_MMX|IF_SQ},
    /* 1304 */ {I_PMINSW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7951, IF_KATMAI|IF_MMX|IF_SQ},
    /* 1305 */ {I_PMINUB, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7958, IF_KATMAI|IF_MMX|IF_SQ},
    /* 1306 */ {I_PMOVMSKB, 2, {REG32,MMXREG,0,0,0}, nasm_bytecodes+14644, IF_KATMAI|IF_MMX},
    /* 1307 */ {I_PMULHUW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7965, IF_KATMAI|IF_MMX|IF_SQ},
    /* 1308 */ {I_PSADBW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7972, IF_KATMAI|IF_MMX|IF_SQ},
    /* 1309 */ {I_PSHUFW, 3, {MMXREG,RM_MMX,IMMEDIATE,0,0}, nasm_bytecodes+5878, IF_KATMAI|IF_MMX|IF_SM2|IF_SB|IF_AR2},
    /* 1310 */ {I_PF2IW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+5886, IF_PENT|IF_3DNOW|IF_SQ},
    /* 1311 */ {I_PFNACC, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+5894, IF_PENT|IF_3DNOW|IF_SQ},
    /* 1312 */ {I_PFPNACC, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+5902, IF_PENT|IF_3DNOW|IF_SQ},
    /* 1313 */ {I_PI2FW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+5910, IF_PENT|IF_3DNOW|IF_SQ},
    /* 1314 */ {I_PSWAPD, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+5918, IF_PENT|IF_3DNOW|IF_SQ},
    /* 1315 */ {I_MASKMOVDQU, 2, {XMMREG,XMMREG,0,0,0}, nasm_bytecodes+14650, IF_WILLAMETTE|IF_SSE2},
    /* 1316 */ {I_CLFLUSH, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+18492, IF_WILLAMETTE|IF_SSE2},
    /* 1317 */ {I_MOVNTDQ, 2, {MEMORY,XMMREG,0,0,0}, nasm_bytecodes+14656, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1318 */ {I_MOVNTI, 2, {MEMORY,REG32,0,0,0}, nasm_bytecodes+7980, IF_WILLAMETTE|IF_SD},
    /* 1319 */ {I_MOVNTI, 2, {MEMORY,REG64,0,0,0}, nasm_bytecodes+7979, IF_X64|IF_SQ},
    /* 1320 */ {I_MOVNTPD, 2, {MEMORY,XMMREG,0,0,0}, nasm_bytecodes+14662, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1321 */ {I_LFENCE, 0, {0,0,0,0,0}, nasm_bytecodes+17532, IF_WILLAMETTE|IF_SSE2},
    /* 1322 */ {I_MFENCE, 0, {0,0,0,0,0}, nasm_bytecodes+17622, IF_WILLAMETTE|IF_SSE2},
    /* 1323 */ {I_MOVD, 2, {XMMREG,REG32,0,0,0}, nasm_bytecodes+14668, IF_WILLAMETTE|IF_SSE2},
    /* 1324 */ {I_MOVD, 2, {REG32,XMMREG,0,0,0}, nasm_bytecodes+14674, IF_WILLAMETTE|IF_SSE2},
    /* 1325 */ {I_MOVD, 2, {MEMORY,XMMREG,0,0,0}, nasm_bytecodes+14674, IF_WILLAMETTE|IF_SSE2|IF_SD},
    /* 1326 */ {I_MOVD, 2, {XMMREG,MEMORY,0,0,0}, nasm_bytecodes+14668, IF_WILLAMETTE|IF_SSE2|IF_SD},
    /* 1327 */ {I_MOVDQA, 2, {XMMREG,XMMREG,0,0,0}, nasm_bytecodes+14680, IF_WILLAMETTE|IF_SSE2},
    /* 1328 */ {I_MOVDQA, 2, {MEMORY,XMMREG,0,0,0}, nasm_bytecodes+14686, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1329 */ {I_MOVDQA, 2, {XMMREG,MEMORY,0,0,0}, nasm_bytecodes+14680, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1330 */ {I_MOVDQA, 2, {XMMREG,XMMREG,0,0,0}, nasm_bytecodes+14692, IF_WILLAMETTE|IF_SSE2},
    /* 1331 */ {I_MOVDQU, 2, {XMMREG,XMMREG,0,0,0}, nasm_bytecodes+14698, IF_WILLAMETTE|IF_SSE2},
    /* 1332 */ {I_MOVDQU, 2, {MEMORY,XMMREG,0,0,0}, nasm_bytecodes+14704, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1333 */ {I_MOVDQU, 2, {XMMREG,MEMORY,0,0,0}, nasm_bytecodes+14698, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1334 */ {I_MOVDQU, 2, {XMMREG,XMMREG,0,0,0}, nasm_bytecodes+14710, IF_WILLAMETTE|IF_SSE2},
    /* 1335 */ {I_MOVDQ2Q, 2, {MMXREG,XMMREG,0,0,0}, nasm_bytecodes+7986, IF_WILLAMETTE|IF_SSE2},
    /* 1336 */ {I_MOVQ, 2, {XMMREG,XMMREG,0,0,0}, nasm_bytecodes+14716, IF_WILLAMETTE|IF_SSE2},
    /* 1337 */ {I_MOVQ, 2, {XMMREG,XMMREG,0,0,0}, nasm_bytecodes+14722, IF_WILLAMETTE|IF_SSE2},
    /* 1338 */ {I_MOVQ, 2, {MEMORY,XMMREG,0,0,0}, nasm_bytecodes+14728, IF_WILLAMETTE|IF_SSE2|IF_SQ},
    /* 1339 */ {I_MOVQ, 2, {XMMREG,MEMORY,0,0,0}, nasm_bytecodes+14716, IF_WILLAMETTE|IF_SSE2|IF_SQ},
    /* 1340 */ {I_MOVQ, 2, {XMMREG,RM_GPR|BITS64,0,0,0}, nasm_bytecodes+7993, IF_X64|IF_SSE2},
    /* 1341 */ {I_MOVQ, 2, {RM_GPR|BITS64,XMMREG,0,0,0}, nasm_bytecodes+8000, IF_X64|IF_SSE2},
    /* 1342 */ {I_MOVQ2DQ, 2, {XMMREG,MMXREG,0,0,0}, nasm_bytecodes+14734, IF_WILLAMETTE|IF_SSE2},
    /* 1343 */ {I_PACKSSWB, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14740, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1344 */ {I_PACKSSDW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14746, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1345 */ {I_PACKUSWB, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14752, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1346 */ {I_PADDB, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14758, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1347 */ {I_PADDW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14764, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1348 */ {I_PADDD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14770, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1349 */ {I_PADDQ, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+8007, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1350 */ {I_PADDQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14776, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1351 */ {I_PADDSB, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14782, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1352 */ {I_PADDSW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14788, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1353 */ {I_PADDUSB, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14794, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1354 */ {I_PADDUSW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14800, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1355 */ {I_PAND, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14806, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1356 */ {I_PANDN, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14812, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1357 */ {I_PAVGB, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14818, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1358 */ {I_PAVGW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14824, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1359 */ {I_PCMPEQB, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14830, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1360 */ {I_PCMPEQW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14836, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1361 */ {I_PCMPEQD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14842, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1362 */ {I_PCMPGTB, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14848, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1363 */ {I_PCMPGTW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14854, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1364 */ {I_PCMPGTD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14860, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1365 */ {I_PEXTRW, 3, {REG32,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+8014, IF_WILLAMETTE|IF_SSE2|IF_SB|IF_AR2},
    /* 1366 */ {I_PINSRW, 3, {XMMREG,REG16,IMMEDIATE,0,0}, nasm_bytecodes+8021, IF_WILLAMETTE|IF_SSE2|IF_SB|IF_AR2},
    /* 1367 */ {I_PINSRW, 3, {XMMREG,MEMORY,IMMEDIATE,0,0}, nasm_bytecodes+8021, IF_WILLAMETTE|IF_SSE2|IF_SB|IF_AR2},
    /* 1368 */ {I_PMADDWD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14866, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1369 */ {I_PMAXSW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14872, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1370 */ {I_PMAXUB, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14878, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1371 */ {I_PMINSW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14884, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1372 */ {I_PMINUB, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14890, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1373 */ {I_PMOVMSKB, 2, {REG32,XMMREG,0,0,0}, nasm_bytecodes+14896, IF_WILLAMETTE|IF_SSE2},
    /* 1374 */ {I_PMULHUW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14902, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1375 */ {I_PMULHW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14908, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1376 */ {I_PMULLW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14914, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1377 */ {I_PMULUDQ, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+8028, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1378 */ {I_PMULUDQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14920, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1379 */ {I_POR, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14926, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1380 */ {I_PSADBW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14932, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1381 */ {I_PSHUFD, 3, {XMMREG,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+8035, IF_WILLAMETTE|IF_SSE2|IF_SB|IF_AR2},
    /* 1382 */ {I_PSHUFD, 3, {XMMREG,MEMORY,IMMEDIATE,0,0}, nasm_bytecodes+8035, IF_WILLAMETTE|IF_SSE2|IF_SM2|IF_SB|IF_AR2},
    /* 1383 */ {I_PSHUFHW, 3, {XMMREG,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+8042, IF_WILLAMETTE|IF_SSE2|IF_SB|IF_AR2},
    /* 1384 */ {I_PSHUFHW, 3, {XMMREG,MEMORY,IMMEDIATE,0,0}, nasm_bytecodes+8042, IF_WILLAMETTE|IF_SSE2|IF_SM2|IF_SB|IF_AR2},
    /* 1385 */ {I_PSHUFLW, 3, {XMMREG,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+5926, IF_WILLAMETTE|IF_SSE2|IF_SB|IF_AR2},
    /* 1386 */ {I_PSHUFLW, 3, {XMMREG,MEMORY,IMMEDIATE,0,0}, nasm_bytecodes+5926, IF_WILLAMETTE|IF_SSE2|IF_SM2|IF_SB|IF_AR2},
    /* 1387 */ {I_PSLLDQ, 2, {XMMREG,IMMEDIATE,0,0,0}, nasm_bytecodes+8049, IF_WILLAMETTE|IF_SSE2|IF_SB|IF_AR1},
    /* 1388 */ {I_PSLLW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14938, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1389 */ {I_PSLLW, 2, {XMMREG,IMMEDIATE,0,0,0}, nasm_bytecodes+8056, IF_WILLAMETTE|IF_SSE2|IF_SB|IF_AR1},
    /* 1390 */ {I_PSLLD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14944, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1391 */ {I_PSLLD, 2, {XMMREG,IMMEDIATE,0,0,0}, nasm_bytecodes+8063, IF_WILLAMETTE|IF_SSE2|IF_SB|IF_AR1},
    /* 1392 */ {I_PSLLQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14950, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1393 */ {I_PSLLQ, 2, {XMMREG,IMMEDIATE,0,0,0}, nasm_bytecodes+8070, IF_WILLAMETTE|IF_SSE2|IF_SB|IF_AR1},
    /* 1394 */ {I_PSRAW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14956, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1395 */ {I_PSRAW, 2, {XMMREG,IMMEDIATE,0,0,0}, nasm_bytecodes+8077, IF_WILLAMETTE|IF_SSE2|IF_SB|IF_AR1},
    /* 1396 */ {I_PSRAD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14962, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1397 */ {I_PSRAD, 2, {XMMREG,IMMEDIATE,0,0,0}, nasm_bytecodes+8084, IF_WILLAMETTE|IF_SSE2|IF_SB|IF_AR1},
    /* 1398 */ {I_PSRLDQ, 2, {XMMREG,IMMEDIATE,0,0,0}, nasm_bytecodes+8091, IF_WILLAMETTE|IF_SSE2|IF_SB|IF_AR1},
    /* 1399 */ {I_PSRLW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14968, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1400 */ {I_PSRLW, 2, {XMMREG,IMMEDIATE,0,0,0}, nasm_bytecodes+8098, IF_WILLAMETTE|IF_SSE2|IF_SB|IF_AR1},
    /* 1401 */ {I_PSRLD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14974, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1402 */ {I_PSRLD, 2, {XMMREG,IMMEDIATE,0,0,0}, nasm_bytecodes+8105, IF_WILLAMETTE|IF_SSE2|IF_SB|IF_AR1},
    /* 1403 */ {I_PSRLQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14980, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1404 */ {I_PSRLQ, 2, {XMMREG,IMMEDIATE,0,0,0}, nasm_bytecodes+8112, IF_WILLAMETTE|IF_SSE2|IF_SB|IF_AR1},
    /* 1405 */ {I_PSUBB, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14986, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1406 */ {I_PSUBW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14992, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1407 */ {I_PSUBD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14998, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1408 */ {I_PSUBQ, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+8119, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1409 */ {I_PSUBQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15004, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1410 */ {I_PSUBSB, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15010, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1411 */ {I_PSUBSW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15016, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1412 */ {I_PSUBUSB, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15022, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1413 */ {I_PSUBUSW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15028, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1414 */ {I_PUNPCKHBW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15034, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1415 */ {I_PUNPCKHWD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15040, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1416 */ {I_PUNPCKHDQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15046, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1417 */ {I_PUNPCKHQDQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15052, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1418 */ {I_PUNPCKLBW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15058, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1419 */ {I_PUNPCKLWD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15064, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1420 */ {I_PUNPCKLDQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15070, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1421 */ {I_PUNPCKLQDQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15076, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1422 */ {I_PXOR, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15082, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1423 */ {I_ADDPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15088, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1424 */ {I_ADDSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15094, IF_WILLAMETTE|IF_SSE2|IF_SQ},
    /* 1425 */ {I_ANDNPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15100, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1426 */ {I_ANDPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15106, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1427 */ {I_CMPEQPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+5934, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1428 */ {I_CMPEQSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+5942, IF_WILLAMETTE|IF_SSE2},
    /* 1429 */ {I_CMPLEPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+5950, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1430 */ {I_CMPLESD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+5958, IF_WILLAMETTE|IF_SSE2},
    /* 1431 */ {I_CMPLTPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+5966, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1432 */ {I_CMPLTSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+5974, IF_WILLAMETTE|IF_SSE2},
    /* 1433 */ {I_CMPNEQPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+5982, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1434 */ {I_CMPNEQSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+5990, IF_WILLAMETTE|IF_SSE2},
    /* 1435 */ {I_CMPNLEPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+5998, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1436 */ {I_CMPNLESD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+6006, IF_WILLAMETTE|IF_SSE2},
    /* 1437 */ {I_CMPNLTPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+6014, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1438 */ {I_CMPNLTSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+6022, IF_WILLAMETTE|IF_SSE2},
    /* 1439 */ {I_CMPORDPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+6030, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1440 */ {I_CMPORDSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+6038, IF_WILLAMETTE|IF_SSE2},
    /* 1441 */ {I_CMPUNORDPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+6046, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1442 */ {I_CMPUNORDSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+6054, IF_WILLAMETTE|IF_SSE2},
    /* 1443 */ {I_CMPPD, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+8126, IF_WILLAMETTE|IF_SSE2|IF_SM2|IF_SB|IF_AR2},
    /* 1444 */ {I_CMPSD, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+8133, IF_WILLAMETTE|IF_SSE2|IF_SB|IF_AR2},
    /* 1445 */ {I_COMISD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15112, IF_WILLAMETTE|IF_SSE2},
    /* 1446 */ {I_CVTDQ2PD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15118, IF_WILLAMETTE|IF_SSE2|IF_SQ},
    /* 1447 */ {I_CVTDQ2PS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15124, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1448 */ {I_CVTPD2DQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15130, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1449 */ {I_CVTPD2PI, 2, {MMXREG,RM_XMM,0,0,0}, nasm_bytecodes+15136, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1450 */ {I_CVTPD2PS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15142, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1451 */ {I_CVTPI2PD, 2, {XMMREG,RM_MMX,0,0,0}, nasm_bytecodes+15148, IF_WILLAMETTE|IF_SSE2|IF_SQ},
    /* 1452 */ {I_CVTPS2DQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15154, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1453 */ {I_CVTPS2PD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15160, IF_WILLAMETTE|IF_SSE2|IF_SQ},
    /* 1454 */ {I_CVTSD2SI, 2, {REG32,XMMREG,0,0,0}, nasm_bytecodes+8141, IF_WILLAMETTE|IF_SSE2|IF_SQ|IF_AR1},
    /* 1455 */ {I_CVTSD2SI, 2, {REG32,MEMORY,0,0,0}, nasm_bytecodes+8141, IF_WILLAMETTE|IF_SSE2|IF_SQ|IF_AR1},
    /* 1456 */ {I_CVTSD2SI, 2, {REG64,XMMREG,0,0,0}, nasm_bytecodes+8140, IF_X64|IF_SSE2|IF_SQ|IF_AR1},
    /* 1457 */ {I_CVTSD2SI, 2, {REG64,MEMORY,0,0,0}, nasm_bytecodes+8140, IF_X64|IF_SSE2|IF_SQ|IF_AR1},
    /* 1458 */ {I_CVTSD2SS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15166, IF_WILLAMETTE|IF_SSE2|IF_SQ},
    /* 1459 */ {I_CVTSI2SD, 2, {XMMREG,RM_GPR|BITS32,0,0,0}, nasm_bytecodes+8148, IF_WILLAMETTE|IF_SSE2|IF_SD|IF_AR1},
    /* 1460 */ {I_CVTSI2SD, 2, {XMMREG,RM_GPR|BITS64,0,0,0}, nasm_bytecodes+8147, IF_X64|IF_SSE2|IF_SQ|IF_AR1},
    /* 1461 */ {I_CVTSS2SD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15172, IF_WILLAMETTE|IF_SSE2|IF_SD},
    /* 1462 */ {I_CVTTPD2PI, 2, {MMXREG,RM_XMM,0,0,0}, nasm_bytecodes+15178, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1463 */ {I_CVTTPD2DQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15184, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1464 */ {I_CVTTPS2DQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15190, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1465 */ {I_CVTTSD2SI, 2, {REG32,XMMREG,0,0,0}, nasm_bytecodes+8155, IF_WILLAMETTE|IF_SSE2|IF_SQ|IF_AR1},
    /* 1466 */ {I_CVTTSD2SI, 2, {REG32,MEMORY,0,0,0}, nasm_bytecodes+8155, IF_WILLAMETTE|IF_SSE2|IF_SQ|IF_AR1},
    /* 1467 */ {I_CVTTSD2SI, 2, {REG64,XMMREG,0,0,0}, nasm_bytecodes+8154, IF_X64|IF_SSE2|IF_SQ|IF_AR1},
    /* 1468 */ {I_CVTTSD2SI, 2, {REG64,MEMORY,0,0,0}, nasm_bytecodes+8154, IF_X64|IF_SSE2|IF_SQ|IF_AR1},
    /* 1469 */ {I_DIVPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15196, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1470 */ {I_DIVSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15202, IF_WILLAMETTE|IF_SSE2},
    /* 1471 */ {I_MAXPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15208, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1472 */ {I_MAXSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15214, IF_WILLAMETTE|IF_SSE2},
    /* 1473 */ {I_MINPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15220, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1474 */ {I_MINSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15226, IF_WILLAMETTE|IF_SSE2},
    /* 1475 */ {I_MOVAPD, 2, {XMMREG,XMMREG,0,0,0}, nasm_bytecodes+15232, IF_WILLAMETTE|IF_SSE2},
    /* 1476 */ {I_MOVAPD, 2, {XMMREG,XMMREG,0,0,0}, nasm_bytecodes+15238, IF_WILLAMETTE|IF_SSE2},
    /* 1477 */ {I_MOVAPD, 2, {MEMORY,XMMREG,0,0,0}, nasm_bytecodes+15244, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1478 */ {I_MOVAPD, 2, {XMMREG,MEMORY,0,0,0}, nasm_bytecodes+15232, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1479 */ {I_MOVHPD, 2, {MEMORY,XMMREG,0,0,0}, nasm_bytecodes+15250, IF_WILLAMETTE|IF_SSE2},
    /* 1480 */ {I_MOVHPD, 2, {XMMREG,MEMORY,0,0,0}, nasm_bytecodes+15256, IF_WILLAMETTE|IF_SSE2},
    /* 1481 */ {I_MOVLPD, 2, {MEMORY,XMMREG,0,0,0}, nasm_bytecodes+15262, IF_WILLAMETTE|IF_SSE2},
    /* 1482 */ {I_MOVLPD, 2, {XMMREG,MEMORY,0,0,0}, nasm_bytecodes+15268, IF_WILLAMETTE|IF_SSE2},
    /* 1483 */ {I_MOVMSKPD, 2, {REG32,XMMREG,0,0,0}, nasm_bytecodes+15274, IF_WILLAMETTE|IF_SSE2},
    /* 1484 */ {I_MOVMSKPD, 2, {REG64,XMMREG,0,0,0}, nasm_bytecodes+8161, IF_X64|IF_SSE2},
    /* 1485 */ {I_MOVSD, 2, {XMMREG,XMMREG,0,0,0}, nasm_bytecodes+15280, IF_WILLAMETTE|IF_SSE2},
    /* 1486 */ {I_MOVSD, 2, {XMMREG,XMMREG,0,0,0}, nasm_bytecodes+15286, IF_WILLAMETTE|IF_SSE2},
    /* 1487 */ {I_MOVSD, 2, {MEMORY,XMMREG,0,0,0}, nasm_bytecodes+15292, IF_WILLAMETTE|IF_SSE2},
    /* 1488 */ {I_MOVSD, 2, {XMMREG,MEMORY,0,0,0}, nasm_bytecodes+15280, IF_WILLAMETTE|IF_SSE2},
    /* 1489 */ {I_MOVUPD, 2, {XMMREG,XMMREG,0,0,0}, nasm_bytecodes+15298, IF_WILLAMETTE|IF_SSE2},
    /* 1490 */ {I_MOVUPD, 2, {XMMREG,XMMREG,0,0,0}, nasm_bytecodes+15304, IF_WILLAMETTE|IF_SSE2},
    /* 1491 */ {I_MOVUPD, 2, {MEMORY,XMMREG,0,0,0}, nasm_bytecodes+15310, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1492 */ {I_MOVUPD, 2, {XMMREG,MEMORY,0,0,0}, nasm_bytecodes+15298, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1493 */ {I_MULPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15316, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1494 */ {I_MULSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15322, IF_WILLAMETTE|IF_SSE2},
    /* 1495 */ {I_ORPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15328, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1496 */ {I_SHUFPD, 3, {XMMREG,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+8168, IF_WILLAMETTE|IF_SSE2|IF_SB|IF_AR2},
    /* 1497 */ {I_SHUFPD, 3, {XMMREG,MEMORY,IMMEDIATE,0,0}, nasm_bytecodes+8168, IF_WILLAMETTE|IF_SSE2|IF_SM|IF_SB|IF_AR2},
    /* 1498 */ {I_SQRTPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15334, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1499 */ {I_SQRTSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15340, IF_WILLAMETTE|IF_SSE2},
    /* 1500 */ {I_SUBPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15346, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1501 */ {I_SUBSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15352, IF_WILLAMETTE|IF_SSE2},
    /* 1502 */ {I_UCOMISD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15358, IF_WILLAMETTE|IF_SSE2},
    /* 1503 */ {I_UNPCKHPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15364, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1504 */ {I_UNPCKLPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15370, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1505 */ {I_XORPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15376, IF_WILLAMETTE|IF_SSE2|IF_SO},
    /* 1506 */ {I_ADDSUBPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15382, IF_PRESCOTT|IF_SSE3|IF_SO},
    /* 1507 */ {I_ADDSUBPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15388, IF_PRESCOTT|IF_SSE3|IF_SO},
    /* 1508 */ {I_HADDPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15394, IF_PRESCOTT|IF_SSE3|IF_SO},
    /* 1509 */ {I_HADDPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15400, IF_PRESCOTT|IF_SSE3|IF_SO},
    /* 1510 */ {I_HSUBPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15406, IF_PRESCOTT|IF_SSE3|IF_SO},
    /* 1511 */ {I_HSUBPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15412, IF_PRESCOTT|IF_SSE3|IF_SO},
    /* 1512 */ {I_LDDQU, 2, {XMMREG,MEMORY,0,0,0}, nasm_bytecodes+15418, IF_PRESCOTT|IF_SSE3|IF_SO},
    /* 1513 */ {I_MOVDDUP, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15424, IF_PRESCOTT|IF_SSE3},
    /* 1514 */ {I_MOVSHDUP, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15430, IF_PRESCOTT|IF_SSE3},
    /* 1515 */ {I_MOVSLDUP, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15436, IF_PRESCOTT|IF_SSE3},
    /* 1516 */ {I_VMCALL, 0, {0,0,0,0,0}, nasm_bytecodes+18497, IF_VMX},
    /* 1517 */ {I_VMCLEAR, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+15442, IF_VMX},
    /* 1518 */ {I_VMLAUNCH, 0, {0,0,0,0,0}, nasm_bytecodes+18502, IF_VMX},
    /* 1519 */ {I_VMLOAD, 0, {0,0,0,0,0}, nasm_bytecodes+18507, IF_X64|IF_VMX},
    /* 1520 */ {I_VMMCALL, 0, {0,0,0,0,0}, nasm_bytecodes+18512, IF_X64|IF_VMX},
    /* 1521 */ {I_VMPTRLD, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+15449, IF_VMX},
    /* 1522 */ {I_VMPTRST, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+18517, IF_VMX},
    /* 1523 */ {I_VMREAD, 2, {RM_GPR|BITS32,REG32,0,0,0}, nasm_bytecodes+8176, IF_VMX|IF_NOLONG|IF_SD},
    /* 1524 */ {I_VMREAD, 2, {RM_GPR|BITS64,REG64,0,0,0}, nasm_bytecodes+8175, IF_X64|IF_VMX|IF_SQ},
    /* 1525 */ {I_VMRESUME, 0, {0,0,0,0,0}, nasm_bytecodes+18522, IF_VMX},
    /* 1526 */ {I_VMRUN, 0, {0,0,0,0,0}, nasm_bytecodes+18527, IF_X64|IF_VMX},
    /* 1527 */ {I_VMSAVE, 0, {0,0,0,0,0}, nasm_bytecodes+18532, IF_X64|IF_VMX},
    /* 1528 */ {I_VMWRITE, 2, {REG32,RM_GPR|BITS32,0,0,0}, nasm_bytecodes+8183, IF_VMX|IF_NOLONG|IF_SD},
    /* 1529 */ {I_VMWRITE, 2, {REG64,RM_GPR|BITS64,0,0,0}, nasm_bytecodes+8182, IF_X64|IF_VMX|IF_SQ},
    /* 1530 */ {I_VMXOFF, 0, {0,0,0,0,0}, nasm_bytecodes+18537, IF_VMX},
    /* 1531 */ {I_VMXON, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+15448, IF_VMX},
    /* 1532 */ {I_INVEPT, 2, {REG32,MEMORY,0,0,0}, nasm_bytecodes+6063, IF_VMX|IF_SO|IF_NOLONG},
    /* 1533 */ {I_INVEPT, 2, {REG64,MEMORY,0,0,0}, nasm_bytecodes+6062, IF_VMX|IF_SO|IF_LONG},
    /* 1534 */ {I_INVVPID, 2, {REG32,MEMORY,0,0,0}, nasm_bytecodes+6071, IF_VMX|IF_SO|IF_NOLONG},
    /* 1535 */ {I_INVVPID, 2, {REG64,MEMORY,0,0,0}, nasm_bytecodes+6070, IF_VMX|IF_SO|IF_LONG},
    /* 1536 */ {I_PABSB, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+8189, IF_SSSE3|IF_MMX|IF_SQ},
    /* 1537 */ {I_PABSB, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8196, IF_SSSE3},
    /* 1538 */ {I_PABSW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+8203, IF_SSSE3|IF_MMX|IF_SQ},
    /* 1539 */ {I_PABSW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8210, IF_SSSE3},
    /* 1540 */ {I_PABSD, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+8217, IF_SSSE3|IF_MMX|IF_SQ},
    /* 1541 */ {I_PABSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8224, IF_SSSE3},
    /* 1542 */ {I_PALIGNR, 3, {MMXREG,RM_MMX,IMMEDIATE,0,0}, nasm_bytecodes+6078, IF_SSSE3|IF_MMX|IF_SQ},
    /* 1543 */ {I_PALIGNR, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6086, IF_SSSE3},
    /* 1544 */ {I_PHADDW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+8231, IF_SSSE3|IF_MMX|IF_SQ},
    /* 1545 */ {I_PHADDW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8238, IF_SSSE3},
    /* 1546 */ {I_PHADDD, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+8245, IF_SSSE3|IF_MMX|IF_SQ},
    /* 1547 */ {I_PHADDD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8252, IF_SSSE3},
    /* 1548 */ {I_PHADDSW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+8259, IF_SSSE3|IF_MMX|IF_SQ},
    /* 1549 */ {I_PHADDSW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8266, IF_SSSE3},
    /* 1550 */ {I_PHSUBW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+8273, IF_SSSE3|IF_MMX|IF_SQ},
    /* 1551 */ {I_PHSUBW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8280, IF_SSSE3},
    /* 1552 */ {I_PHSUBD, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+8287, IF_SSSE3|IF_MMX|IF_SQ},
    /* 1553 */ {I_PHSUBD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8294, IF_SSSE3},
    /* 1554 */ {I_PHSUBSW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+8301, IF_SSSE3|IF_MMX|IF_SQ},
    /* 1555 */ {I_PHSUBSW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8308, IF_SSSE3},
    /* 1556 */ {I_PMADDUBSW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+8315, IF_SSSE3|IF_MMX|IF_SQ},
    /* 1557 */ {I_PMADDUBSW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8322, IF_SSSE3},
    /* 1558 */ {I_PMULHRSW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+8329, IF_SSSE3|IF_MMX|IF_SQ},
    /* 1559 */ {I_PMULHRSW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8336, IF_SSSE3},
    /* 1560 */ {I_PSHUFB, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+8343, IF_SSSE3|IF_MMX|IF_SQ},
    /* 1561 */ {I_PSHUFB, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8350, IF_SSSE3},
    /* 1562 */ {I_PSIGNB, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+8357, IF_SSSE3|IF_MMX|IF_SQ},
    /* 1563 */ {I_PSIGNB, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8364, IF_SSSE3},
    /* 1564 */ {I_PSIGNW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+8371, IF_SSSE3|IF_MMX|IF_SQ},
    /* 1565 */ {I_PSIGNW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8378, IF_SSSE3},
    /* 1566 */ {I_PSIGND, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+8385, IF_SSSE3|IF_MMX|IF_SQ},
    /* 1567 */ {I_PSIGND, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8392, IF_SSSE3},
    /* 1568 */ {I_EXTRQ, 3, {XMMREG,IMMEDIATE,IMMEDIATE,0,0}, nasm_bytecodes+6094, IF_SSE4A|IF_AMD},
    /* 1569 */ {I_EXTRQ, 2, {XMMREG,XMMREG,0,0,0}, nasm_bytecodes+15454, IF_SSE4A|IF_AMD},
    /* 1570 */ {I_INSERTQ, 4, {XMMREG,XMMREG,IMMEDIATE,IMMEDIATE,0}, nasm_bytecodes+6102, IF_SSE4A|IF_AMD},
    /* 1571 */ {I_INSERTQ, 2, {XMMREG,XMMREG,0,0,0}, nasm_bytecodes+15460, IF_SSE4A|IF_AMD},
    /* 1572 */ {I_MOVNTSD, 2, {MEMORY,XMMREG,0,0,0}, nasm_bytecodes+15466, IF_SSE4A|IF_AMD|IF_SQ},
    /* 1573 */ {I_MOVNTSS, 2, {MEMORY,XMMREG,0,0,0}, nasm_bytecodes+15472, IF_SSE4A|IF_AMD|IF_SD},
    /* 1574 */ {I_LZCNT, 2, {REG16,RM_GPR|BITS16,0,0,0}, nasm_bytecodes+8399, IF_P6|IF_AMD},
    /* 1575 */ {I_LZCNT, 2, {REG32,RM_GPR|BITS32,0,0,0}, nasm_bytecodes+8406, IF_P6|IF_AMD},
    /* 1576 */ {I_LZCNT, 2, {REG64,RM_GPR|BITS64,0,0,0}, nasm_bytecodes+8413, IF_P6|IF_AMD},
    /* 1577 */ {I_BLENDPD, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6110, IF_SSE41},
    /* 1578 */ {I_BLENDPS, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6118, IF_SSE41},
    /* 1579 */ {I_BLENDVPD, 3, {XMMREG,RM_XMM,XMM0,0,0}, nasm_bytecodes+8420, IF_SSE41},
    /* 1580 */ {I_BLENDVPS, 3, {XMMREG,RM_XMM,XMM0,0,0}, nasm_bytecodes+8427, IF_SSE41},
    /* 1581 */ {I_DPPD, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6126, IF_SSE41},
    /* 1582 */ {I_DPPS, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6134, IF_SSE41},
    /* 1583 */ {I_EXTRACTPS, 3, {RM_GPR|BITS32,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+1, IF_SSE41},
    /* 1584 */ {I_EXTRACTPS, 3, {REG64,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+0, IF_SSE41|IF_X64},
    /* 1585 */ {I_INSERTPS, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6142, IF_SSE41|IF_SD},
    /* 1586 */ {I_MOVNTDQA, 2, {XMMREG,MEMORY,0,0,0}, nasm_bytecodes+8434, IF_SSE41},
    /* 1587 */ {I_MPSADBW, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6150, IF_SSE41},
    /* 1588 */ {I_PACKUSDW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8441, IF_SSE41},
    /* 1589 */ {I_PBLENDVB, 3, {XMMREG,RM_XMM,XMM0,0,0}, nasm_bytecodes+8448, IF_SSE41},
    /* 1590 */ {I_PBLENDW, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6158, IF_SSE41},
    /* 1591 */ {I_PCMPEQQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8455, IF_SSE41},
    /* 1592 */ {I_PEXTRB, 3, {REG32,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+10, IF_SSE41},
    /* 1593 */ {I_PEXTRB, 3, {MEMORY|BITS8,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+10, IF_SSE41},
    /* 1594 */ {I_PEXTRB, 3, {REG64,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+9, IF_SSE41|IF_X64},
    /* 1595 */ {I_PEXTRD, 3, {RM_GPR|BITS32,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+6166, IF_SSE41},
    /* 1596 */ {I_PEXTRQ, 3, {RM_GPR|BITS64,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+6166, IF_SSE41|IF_X64},
    /* 1597 */ {I_PEXTRW, 3, {REG32,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+19, IF_SSE41},
    /* 1598 */ {I_PEXTRW, 3, {MEMORY|BITS16,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+19, IF_SSE41},
    /* 1599 */ {I_PEXTRW, 3, {REG64,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+18, IF_SSE41|IF_X64},
    /* 1600 */ {I_PHMINPOSUW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8462, IF_SSE41},
    /* 1601 */ {I_PINSRB, 3, {XMMREG,REG32,IMMEDIATE,0,0}, nasm_bytecodes+6174, IF_SSE41},
    /* 1602 */ {I_PINSRB, 3, {XMMREG,MEMORY|BITS8,IMMEDIATE,0,0}, nasm_bytecodes+6174, IF_SSE41},
    /* 1603 */ {I_PINSRD, 3, {XMMREG,RM_GPR|BITS32,IMMEDIATE,0,0}, nasm_bytecodes+28, IF_SSE41},
    /* 1604 */ {I_PINSRQ, 3, {XMMREG,RM_GPR|BITS64,IMMEDIATE,0,0}, nasm_bytecodes+27, IF_SSE41|IF_X64},
    /* 1605 */ {I_PMAXSB, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8469, IF_SSE41},
    /* 1606 */ {I_PMAXSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8476, IF_SSE41},
    /* 1607 */ {I_PMAXUD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8483, IF_SSE41},
    /* 1608 */ {I_PMAXUW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8490, IF_SSE41},
    /* 1609 */ {I_PMINSB, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8497, IF_SSE41},
    /* 1610 */ {I_PMINSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8504, IF_SSE41},
    /* 1611 */ {I_PMINUD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8511, IF_SSE41},
    /* 1612 */ {I_PMINUW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8518, IF_SSE41},
    /* 1613 */ {I_PMOVSXBW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8525, IF_SSE41|IF_SQ},
    /* 1614 */ {I_PMOVSXBD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8532, IF_SSE41|IF_SD},
    /* 1615 */ {I_PMOVSXBQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8539, IF_SSE41|IF_SW},
    /* 1616 */ {I_PMOVSXWD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8546, IF_SSE41|IF_SQ},
    /* 1617 */ {I_PMOVSXWQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8553, IF_SSE41|IF_SD},
    /* 1618 */ {I_PMOVSXDQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8560, IF_SSE41|IF_SQ},
    /* 1619 */ {I_PMOVZXBW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8567, IF_SSE41|IF_SQ},
    /* 1620 */ {I_PMOVZXBD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8574, IF_SSE41|IF_SD},
    /* 1621 */ {I_PMOVZXBQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8581, IF_SSE41|IF_SW},
    /* 1622 */ {I_PMOVZXWD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8588, IF_SSE41|IF_SQ},
    /* 1623 */ {I_PMOVZXWQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8595, IF_SSE41|IF_SD},
    /* 1624 */ {I_PMOVZXDQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8602, IF_SSE41|IF_SQ},
    /* 1625 */ {I_PMULDQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8609, IF_SSE41},
    /* 1626 */ {I_PMULLD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8616, IF_SSE41},
    /* 1627 */ {I_PTEST, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8623, IF_SSE41},
    /* 1628 */ {I_ROUNDPD, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6182, IF_SSE41},
    /* 1629 */ {I_ROUNDPS, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6190, IF_SSE41},
    /* 1630 */ {I_ROUNDSD, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6198, IF_SSE41},
    /* 1631 */ {I_ROUNDSS, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6206, IF_SSE41},
    /* 1632 */ {I_CRC32, 2, {REG32,RM_GPR|BITS8,0,0,0}, nasm_bytecodes+6231, IF_SSE42},
    /* 1633 */ {I_CRC32, 2, {REG32,RM_GPR|BITS16,0,0,0}, nasm_bytecodes+6214, IF_SSE42},
    /* 1634 */ {I_CRC32, 2, {REG32,RM_GPR|BITS32,0,0,0}, nasm_bytecodes+6222, IF_SSE42},
    /* 1635 */ {I_CRC32, 2, {REG64,RM_GPR|BITS8,0,0,0}, nasm_bytecodes+6230, IF_SSE42|IF_X64},
    /* 1636 */ {I_CRC32, 2, {REG64,RM_GPR|BITS64,0,0,0}, nasm_bytecodes+6238, IF_SSE42|IF_X64},
    /* 1637 */ {I_PCMPESTRI, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6246, IF_SSE42},
    /* 1638 */ {I_PCMPESTRM, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6254, IF_SSE42},
    /* 1639 */ {I_PCMPISTRI, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6262, IF_SSE42},
    /* 1640 */ {I_PCMPISTRM, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6270, IF_SSE42},
    /* 1641 */ {I_PCMPGTQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8630, IF_SSE42},
    /* 1642 */ {I_POPCNT, 2, {REG16,RM_GPR|BITS16,0,0,0}, nasm_bytecodes+8637, IF_NEHALEM|IF_SW},
    /* 1643 */ {I_POPCNT, 2, {REG32,RM_GPR|BITS32,0,0,0}, nasm_bytecodes+8644, IF_NEHALEM|IF_SD},
    /* 1644 */ {I_POPCNT, 2, {REG64,RM_GPR|BITS64,0,0,0}, nasm_bytecodes+8651, IF_NEHALEM|IF_SQ|IF_X64},
    /* 1645 */ {I_FMADDPS, 4, {XMMREG,SAME_AS|0,XMMREG,RM_XMM,0}, nasm_bytecodes+8658, IF_SSE5|IF_AMD},
    /* 1646 */ {I_FMADDPS, 4, {XMMREG,SAME_AS|0,RM_XMM,XMMREG,0}, nasm_bytecodes+8665, IF_SSE5|IF_AMD},
    /* 1647 */ {I_FMADDPS, 4, {XMMREG,XMMREG,RM_XMM,SAME_AS|0,0}, nasm_bytecodes+8672, IF_SSE5|IF_AMD},
    /* 1648 */ {I_FMADDPS, 4, {XMMREG,RM_XMM,XMMREG,SAME_AS|0,0}, nasm_bytecodes+8679, IF_SSE5|IF_AMD},
    /* 1649 */ {I_FMADDPD, 4, {XMMREG,SAME_AS|0,XMMREG,RM_XMM,0}, nasm_bytecodes+8686, IF_SSE5|IF_AMD},
    /* 1650 */ {I_FMADDPD, 4, {XMMREG,SAME_AS|0,RM_XMM,XMMREG,0}, nasm_bytecodes+8693, IF_SSE5|IF_AMD},
    /* 1651 */ {I_FMADDPD, 4, {XMMREG,XMMREG,RM_XMM,SAME_AS|0,0}, nasm_bytecodes+8700, IF_SSE5|IF_AMD},
    /* 1652 */ {I_FMADDPD, 4, {XMMREG,RM_XMM,XMMREG,SAME_AS|0,0}, nasm_bytecodes+8707, IF_SSE5|IF_AMD},
    /* 1653 */ {I_FMADDSS, 4, {XMMREG,SAME_AS|0,XMMREG,RM_XMM,0}, nasm_bytecodes+8714, IF_SSE5|IF_AMD},
    /* 1654 */ {I_FMADDSS, 4, {XMMREG,SAME_AS|0,RM_XMM,XMMREG,0}, nasm_bytecodes+8721, IF_SSE5|IF_AMD},
    /* 1655 */ {I_FMADDSS, 4, {XMMREG,XMMREG,RM_XMM,SAME_AS|0,0}, nasm_bytecodes+8728, IF_SSE5|IF_AMD},
    /* 1656 */ {I_FMADDSS, 4, {XMMREG,RM_XMM,XMMREG,SAME_AS|0,0}, nasm_bytecodes+8735, IF_SSE5|IF_AMD},
    /* 1657 */ {I_FMADDSD, 4, {XMMREG,SAME_AS|0,XMMREG,RM_XMM,0}, nasm_bytecodes+8742, IF_SSE5|IF_AMD},
    /* 1658 */ {I_FMADDSD, 4, {XMMREG,SAME_AS|0,RM_XMM,XMMREG,0}, nasm_bytecodes+8749, IF_SSE5|IF_AMD},
    /* 1659 */ {I_FMADDSD, 4, {XMMREG,XMMREG,RM_XMM,SAME_AS|0,0}, nasm_bytecodes+8756, IF_SSE5|IF_AMD},
    /* 1660 */ {I_FMADDSD, 4, {XMMREG,RM_XMM,XMMREG,SAME_AS|0,0}, nasm_bytecodes+8763, IF_SSE5|IF_AMD},
    /* 1661 */ {I_FMSUBPS, 4, {XMMREG,SAME_AS|0,XMMREG,RM_XMM,0}, nasm_bytecodes+8770, IF_SSE5|IF_AMD},
    /* 1662 */ {I_FMSUBPS, 4, {XMMREG,SAME_AS|0,RM_XMM,XMMREG,0}, nasm_bytecodes+8777, IF_SSE5|IF_AMD},
    /* 1663 */ {I_FMSUBPS, 4, {XMMREG,XMMREG,RM_XMM,SAME_AS|0,0}, nasm_bytecodes+8784, IF_SSE5|IF_AMD},
    /* 1664 */ {I_FMSUBPS, 4, {XMMREG,RM_XMM,XMMREG,SAME_AS|0,0}, nasm_bytecodes+8791, IF_SSE5|IF_AMD},
    /* 1665 */ {I_FMSUBPD, 4, {XMMREG,SAME_AS|0,XMMREG,RM_XMM,0}, nasm_bytecodes+8798, IF_SSE5|IF_AMD},
    /* 1666 */ {I_FMSUBPD, 4, {XMMREG,SAME_AS|0,RM_XMM,XMMREG,0}, nasm_bytecodes+8805, IF_SSE5|IF_AMD},
    /* 1667 */ {I_FMSUBPD, 4, {XMMREG,XMMREG,RM_XMM,SAME_AS|0,0}, nasm_bytecodes+8812, IF_SSE5|IF_AMD},
    /* 1668 */ {I_FMSUBPD, 4, {XMMREG,RM_XMM,XMMREG,SAME_AS|0,0}, nasm_bytecodes+8819, IF_SSE5|IF_AMD},
    /* 1669 */ {I_FMSUBSS, 4, {XMMREG,SAME_AS|0,XMMREG,RM_XMM,0}, nasm_bytecodes+8826, IF_SSE5|IF_AMD},
    /* 1670 */ {I_FMSUBSS, 4, {XMMREG,SAME_AS|0,RM_XMM,XMMREG,0}, nasm_bytecodes+8833, IF_SSE5|IF_AMD},
    /* 1671 */ {I_FMSUBSS, 4, {XMMREG,XMMREG,RM_XMM,SAME_AS|0,0}, nasm_bytecodes+8840, IF_SSE5|IF_AMD},
    /* 1672 */ {I_FMSUBSS, 4, {XMMREG,RM_XMM,XMMREG,SAME_AS|0,0}, nasm_bytecodes+8847, IF_SSE5|IF_AMD},
    /* 1673 */ {I_FMSUBSD, 4, {XMMREG,SAME_AS|0,XMMREG,RM_XMM,0}, nasm_bytecodes+8854, IF_SSE5|IF_AMD},
    /* 1674 */ {I_FMSUBSD, 4, {XMMREG,SAME_AS|0,RM_XMM,XMMREG,0}, nasm_bytecodes+8861, IF_SSE5|IF_AMD},
    /* 1675 */ {I_FMSUBSD, 4, {XMMREG,XMMREG,RM_XMM,SAME_AS|0,0}, nasm_bytecodes+8868, IF_SSE5|IF_AMD},
    /* 1676 */ {I_FMSUBSD, 4, {XMMREG,RM_XMM,XMMREG,SAME_AS|0,0}, nasm_bytecodes+8875, IF_SSE5|IF_AMD},
    /* 1677 */ {I_FNMADDPS, 4, {XMMREG,SAME_AS|0,XMMREG,RM_XMM,0}, nasm_bytecodes+8882, IF_SSE5|IF_AMD},
    /* 1678 */ {I_FNMADDPS, 4, {XMMREG,SAME_AS|0,RM_XMM,XMMREG,0}, nasm_bytecodes+8889, IF_SSE5|IF_AMD},
    /* 1679 */ {I_FNMADDPS, 4, {XMMREG,XMMREG,RM_XMM,SAME_AS|0,0}, nasm_bytecodes+8896, IF_SSE5|IF_AMD},
    /* 1680 */ {I_FNMADDPS, 4, {XMMREG,RM_XMM,XMMREG,SAME_AS|0,0}, nasm_bytecodes+8903, IF_SSE5|IF_AMD},
    /* 1681 */ {I_FNMADDPD, 4, {XMMREG,SAME_AS|0,XMMREG,RM_XMM,0}, nasm_bytecodes+8910, IF_SSE5|IF_AMD},
    /* 1682 */ {I_FNMADDPD, 4, {XMMREG,SAME_AS|0,RM_XMM,XMMREG,0}, nasm_bytecodes+8917, IF_SSE5|IF_AMD},
    /* 1683 */ {I_FNMADDPD, 4, {XMMREG,XMMREG,RM_XMM,SAME_AS|0,0}, nasm_bytecodes+8924, IF_SSE5|IF_AMD},
    /* 1684 */ {I_FNMADDPD, 4, {XMMREG,RM_XMM,XMMREG,SAME_AS|0,0}, nasm_bytecodes+8931, IF_SSE5|IF_AMD},
    /* 1685 */ {I_FNMADDSS, 4, {XMMREG,SAME_AS|0,XMMREG,RM_XMM,0}, nasm_bytecodes+8938, IF_SSE5|IF_AMD},
    /* 1686 */ {I_FNMADDSS, 4, {XMMREG,SAME_AS|0,RM_XMM,XMMREG,0}, nasm_bytecodes+8945, IF_SSE5|IF_AMD},
    /* 1687 */ {I_FNMADDSS, 4, {XMMREG,XMMREG,RM_XMM,SAME_AS|0,0}, nasm_bytecodes+8952, IF_SSE5|IF_AMD},
    /* 1688 */ {I_FNMADDSS, 4, {XMMREG,RM_XMM,XMMREG,SAME_AS|0,0}, nasm_bytecodes+8959, IF_SSE5|IF_AMD},
    /* 1689 */ {I_FNMADDSD, 4, {XMMREG,SAME_AS|0,XMMREG,RM_XMM,0}, nasm_bytecodes+8966, IF_SSE5|IF_AMD},
    /* 1690 */ {I_FNMADDSD, 4, {XMMREG,SAME_AS|0,RM_XMM,XMMREG,0}, nasm_bytecodes+8973, IF_SSE5|IF_AMD},
    /* 1691 */ {I_FNMADDSD, 4, {XMMREG,XMMREG,RM_XMM,SAME_AS|0,0}, nasm_bytecodes+8980, IF_SSE5|IF_AMD},
    /* 1692 */ {I_FNMADDSD, 4, {XMMREG,RM_XMM,XMMREG,SAME_AS|0,0}, nasm_bytecodes+8987, IF_SSE5|IF_AMD},
    /* 1693 */ {I_FNMSUBPS, 4, {XMMREG,SAME_AS|0,XMMREG,RM_XMM,0}, nasm_bytecodes+8994, IF_SSE5|IF_AMD},
    /* 1694 */ {I_FNMSUBPS, 4, {XMMREG,SAME_AS|0,RM_XMM,XMMREG,0}, nasm_bytecodes+9001, IF_SSE5|IF_AMD},
    /* 1695 */ {I_FNMSUBPS, 4, {XMMREG,XMMREG,RM_XMM,SAME_AS|0,0}, nasm_bytecodes+9008, IF_SSE5|IF_AMD},
    /* 1696 */ {I_FNMSUBPS, 4, {XMMREG,RM_XMM,XMMREG,SAME_AS|0,0}, nasm_bytecodes+9015, IF_SSE5|IF_AMD},
    /* 1697 */ {I_FNMSUBPD, 4, {XMMREG,SAME_AS|0,XMMREG,RM_XMM,0}, nasm_bytecodes+9022, IF_SSE5|IF_AMD},
    /* 1698 */ {I_FNMSUBPD, 4, {XMMREG,SAME_AS|0,RM_XMM,XMMREG,0}, nasm_bytecodes+9029, IF_SSE5|IF_AMD},
    /* 1699 */ {I_FNMSUBPD, 4, {XMMREG,XMMREG,RM_XMM,SAME_AS|0,0}, nasm_bytecodes+9036, IF_SSE5|IF_AMD},
    /* 1700 */ {I_FNMSUBPD, 4, {XMMREG,RM_XMM,XMMREG,SAME_AS|0,0}, nasm_bytecodes+9043, IF_SSE5|IF_AMD},
    /* 1701 */ {I_FNMSUBSS, 4, {XMMREG,SAME_AS|0,XMMREG,RM_XMM,0}, nasm_bytecodes+9050, IF_SSE5|IF_AMD},
    /* 1702 */ {I_FNMSUBSS, 4, {XMMREG,SAME_AS|0,RM_XMM,XMMREG,0}, nasm_bytecodes+9057, IF_SSE5|IF_AMD},
    /* 1703 */ {I_FNMSUBSS, 4, {XMMREG,XMMREG,RM_XMM,SAME_AS|0,0}, nasm_bytecodes+9064, IF_SSE5|IF_AMD},
    /* 1704 */ {I_FNMSUBSS, 4, {XMMREG,RM_XMM,XMMREG,SAME_AS|0,0}, nasm_bytecodes+9071, IF_SSE5|IF_AMD},
    /* 1705 */ {I_FNMSUBSD, 4, {XMMREG,SAME_AS|0,XMMREG,RM_XMM,0}, nasm_bytecodes+9078, IF_SSE5|IF_AMD},
    /* 1706 */ {I_FNMSUBSD, 4, {XMMREG,SAME_AS|0,RM_XMM,XMMREG,0}, nasm_bytecodes+9085, IF_SSE5|IF_AMD},
    /* 1707 */ {I_FNMSUBSD, 4, {XMMREG,XMMREG,RM_XMM,SAME_AS|0,0}, nasm_bytecodes+9092, IF_SSE5|IF_AMD},
    /* 1708 */ {I_FNMSUBSD, 4, {XMMREG,RM_XMM,XMMREG,SAME_AS|0,0}, nasm_bytecodes+9099, IF_SSE5|IF_AMD},
    /* 1709 */ {I_COMEQPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+36, IF_SSE5|IF_AMD|IF_SO},
    /* 1710 */ {I_COMLTPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+45, IF_SSE5|IF_AMD|IF_SO},
    /* 1711 */ {I_COMLEPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+54, IF_SSE5|IF_AMD|IF_SO},
    /* 1712 */ {I_COMUNORDPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+63, IF_SSE5|IF_AMD|IF_SO},
    /* 1713 */ {I_COMUNEQPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+72, IF_SSE5|IF_AMD|IF_SO},
    /* 1714 */ {I_COMUNLTPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+81, IF_SSE5|IF_AMD|IF_SO},
    /* 1715 */ {I_COMUNLEPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+90, IF_SSE5|IF_AMD|IF_SO},
    /* 1716 */ {I_COMORDPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+99, IF_SSE5|IF_AMD|IF_SO},
    /* 1717 */ {I_COMUEQPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+108, IF_SSE5|IF_AMD|IF_SO},
    /* 1718 */ {I_COMULTPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+117, IF_SSE5|IF_AMD|IF_SO},
    /* 1719 */ {I_COMULEPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+126, IF_SSE5|IF_AMD|IF_SO},
    /* 1720 */ {I_COMFALSEPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+135, IF_SSE5|IF_AMD|IF_SO},
    /* 1721 */ {I_COMNEQPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+144, IF_SSE5|IF_AMD|IF_SO},
    /* 1722 */ {I_COMNLTPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+153, IF_SSE5|IF_AMD|IF_SO},
    /* 1723 */ {I_COMNLEPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+162, IF_SSE5|IF_AMD|IF_SO},
    /* 1724 */ {I_COMTRUEPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+171, IF_SSE5|IF_AMD|IF_SO},
    /* 1725 */ {I_COMPS, 4, {XMMREG,XMMREG,RM_XMM,IMMEDIATE,0}, nasm_bytecodes+6278, IF_SSE5|IF_AMD|IF_SO},
    /* 1726 */ {I_COMEQPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+180, IF_SSE5|IF_AMD|IF_SO},
    /* 1727 */ {I_COMLTPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+189, IF_SSE5|IF_AMD|IF_SO},
    /* 1728 */ {I_COMLEPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+198, IF_SSE5|IF_AMD|IF_SO},
    /* 1729 */ {I_COMUNORDPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+207, IF_SSE5|IF_AMD|IF_SO},
    /* 1730 */ {I_COMUNEQPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+216, IF_SSE5|IF_AMD|IF_SO},
    /* 1731 */ {I_COMUNLTPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+225, IF_SSE5|IF_AMD|IF_SO},
    /* 1732 */ {I_COMUNLEPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+234, IF_SSE5|IF_AMD|IF_SO},
    /* 1733 */ {I_COMORDPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+243, IF_SSE5|IF_AMD|IF_SO},
    /* 1734 */ {I_COMUEQPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+252, IF_SSE5|IF_AMD|IF_SO},
    /* 1735 */ {I_COMULTPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+261, IF_SSE5|IF_AMD|IF_SO},
    /* 1736 */ {I_COMULEPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+270, IF_SSE5|IF_AMD|IF_SO},
    /* 1737 */ {I_COMFALSEPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+279, IF_SSE5|IF_AMD|IF_SO},
    /* 1738 */ {I_COMNEQPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+288, IF_SSE5|IF_AMD|IF_SO},
    /* 1739 */ {I_COMNLTPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+297, IF_SSE5|IF_AMD|IF_SO},
    /* 1740 */ {I_COMNLEPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+306, IF_SSE5|IF_AMD|IF_SO},
    /* 1741 */ {I_COMTRUEPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+315, IF_SSE5|IF_AMD|IF_SO},
    /* 1742 */ {I_COMPD, 4, {XMMREG,XMMREG,RM_XMM,IMMEDIATE,0}, nasm_bytecodes+6286, IF_SSE5|IF_AMD|IF_SO},
    /* 1743 */ {I_COMEQSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+324, IF_SSE5|IF_AMD|IF_SD},
    /* 1744 */ {I_COMLTSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+333, IF_SSE5|IF_AMD|IF_SD},
    /* 1745 */ {I_COMLESS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+342, IF_SSE5|IF_AMD|IF_SD},
    /* 1746 */ {I_COMUNORDSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+351, IF_SSE5|IF_AMD|IF_SD},
    /* 1747 */ {I_COMUNEQSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+360, IF_SSE5|IF_AMD|IF_SD},
    /* 1748 */ {I_COMUNLTSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+369, IF_SSE5|IF_AMD|IF_SD},
    /* 1749 */ {I_COMUNLESS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+378, IF_SSE5|IF_AMD|IF_SD},
    /* 1750 */ {I_COMORDSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+387, IF_SSE5|IF_AMD|IF_SD},
    /* 1751 */ {I_COMUEQSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+396, IF_SSE5|IF_AMD|IF_SD},
    /* 1752 */ {I_COMULTSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+405, IF_SSE5|IF_AMD|IF_SD},
    /* 1753 */ {I_COMULESS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+414, IF_SSE5|IF_AMD|IF_SD},
    /* 1754 */ {I_COMFALSESS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+423, IF_SSE5|IF_AMD|IF_SD},
    /* 1755 */ {I_COMNEQSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+432, IF_SSE5|IF_AMD|IF_SD},
    /* 1756 */ {I_COMNLTSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+441, IF_SSE5|IF_AMD|IF_SD},
    /* 1757 */ {I_COMNLESS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+450, IF_SSE5|IF_AMD|IF_SD},
    /* 1758 */ {I_COMTRUESS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+459, IF_SSE5|IF_AMD|IF_SD},
    /* 1759 */ {I_COMSS, 4, {XMMREG,XMMREG,RM_XMM,IMMEDIATE,0}, nasm_bytecodes+6294, IF_SSE5|IF_AMD|IF_SD},
    /* 1760 */ {I_COMEQSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+468, IF_SSE5|IF_AMD|IF_SQ},
    /* 1761 */ {I_COMLTSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+477, IF_SSE5|IF_AMD|IF_SQ},
    /* 1762 */ {I_COMLESD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+486, IF_SSE5|IF_AMD|IF_SQ},
    /* 1763 */ {I_COMUNORDSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+495, IF_SSE5|IF_AMD|IF_SQ},
    /* 1764 */ {I_COMUNEQSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+504, IF_SSE5|IF_AMD|IF_SQ},
    /* 1765 */ {I_COMUNLTSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+513, IF_SSE5|IF_AMD|IF_SQ},
    /* 1766 */ {I_COMUNLESD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+522, IF_SSE5|IF_AMD|IF_SQ},
    /* 1767 */ {I_COMORDSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+531, IF_SSE5|IF_AMD|IF_SQ},
    /* 1768 */ {I_COMUEQSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+540, IF_SSE5|IF_AMD|IF_SQ},
    /* 1769 */ {I_COMULTSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+549, IF_SSE5|IF_AMD|IF_SQ},
    /* 1770 */ {I_COMULESD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+558, IF_SSE5|IF_AMD|IF_SQ},
    /* 1771 */ {I_COMFALSESD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+567, IF_SSE5|IF_AMD|IF_SQ},
    /* 1772 */ {I_COMNEQSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+576, IF_SSE5|IF_AMD|IF_SQ},
    /* 1773 */ {I_COMNLTSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+585, IF_SSE5|IF_AMD|IF_SQ},
    /* 1774 */ {I_COMNLESD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+594, IF_SSE5|IF_AMD|IF_SQ},
    /* 1775 */ {I_COMTRUESD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+603, IF_SSE5|IF_AMD|IF_SQ},
    /* 1776 */ {I_COMSD, 4, {XMMREG,XMMREG,RM_XMM,IMMEDIATE,0}, nasm_bytecodes+6302, IF_SSE5|IF_AMD|IF_SQ},
    /* 1777 */ {I_PCOMLTB, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+612, IF_SSE5|IF_AMD|IF_SO},
    /* 1778 */ {I_PCOMLEB, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+621, IF_SSE5|IF_AMD|IF_SO},
    /* 1779 */ {I_PCOMGTB, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+630, IF_SSE5|IF_AMD|IF_SO},
    /* 1780 */ {I_PCOMGEB, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+639, IF_SSE5|IF_AMD|IF_SO},
    /* 1781 */ {I_PCOMEQB, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+648, IF_SSE5|IF_AMD|IF_SO},
    /* 1782 */ {I_PCOMNEQB, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+657, IF_SSE5|IF_AMD|IF_SO},
    /* 1783 */ {I_PCOMFALSEB, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+666, IF_SSE5|IF_AMD|IF_SO},
    /* 1784 */ {I_PCOMTRUEB, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+675, IF_SSE5|IF_AMD|IF_SO},
    /* 1785 */ {I_PCOMB, 4, {XMMREG,XMMREG,RM_XMM,IMMEDIATE,0}, nasm_bytecodes+6310, IF_SSE5|IF_AMD|IF_SO},
    /* 1786 */ {I_PCOMLTW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+684, IF_SSE5|IF_AMD|IF_SO},
    /* 1787 */ {I_PCOMLEW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+693, IF_SSE5|IF_AMD|IF_SO},
    /* 1788 */ {I_PCOMGTW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+702, IF_SSE5|IF_AMD|IF_SO},
    /* 1789 */ {I_PCOMGEW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+711, IF_SSE5|IF_AMD|IF_SO},
    /* 1790 */ {I_PCOMEQW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+720, IF_SSE5|IF_AMD|IF_SO},
    /* 1791 */ {I_PCOMNEQW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+729, IF_SSE5|IF_AMD|IF_SO},
    /* 1792 */ {I_PCOMFALSEW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+738, IF_SSE5|IF_AMD|IF_SO},
    /* 1793 */ {I_PCOMTRUEW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+747, IF_SSE5|IF_AMD|IF_SO},
    /* 1794 */ {I_PCOMW, 4, {XMMREG,XMMREG,RM_XMM,IMMEDIATE,0}, nasm_bytecodes+6318, IF_SSE5|IF_AMD|IF_SO},
    /* 1795 */ {I_PCOMLTD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+756, IF_SSE5|IF_AMD|IF_SO},
    /* 1796 */ {I_PCOMLED, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+765, IF_SSE5|IF_AMD|IF_SO},
    /* 1797 */ {I_PCOMGTD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+774, IF_SSE5|IF_AMD|IF_SO},
    /* 1798 */ {I_PCOMGED, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+783, IF_SSE5|IF_AMD|IF_SO},
    /* 1799 */ {I_PCOMEQD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+792, IF_SSE5|IF_AMD|IF_SO},
    /* 1800 */ {I_PCOMNEQD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+801, IF_SSE5|IF_AMD|IF_SO},
    /* 1801 */ {I_PCOMFALSED, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+810, IF_SSE5|IF_AMD|IF_SO},
    /* 1802 */ {I_PCOMTRUED, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+819, IF_SSE5|IF_AMD|IF_SO},
    /* 1803 */ {I_PCOMD, 4, {XMMREG,XMMREG,RM_XMM,IMMEDIATE,0}, nasm_bytecodes+6326, IF_SSE5|IF_AMD|IF_SO},
    /* 1804 */ {I_PCOMLTQ, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+828, IF_SSE5|IF_AMD|IF_SO},
    /* 1805 */ {I_PCOMLEQ, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+837, IF_SSE5|IF_AMD|IF_SO},
    /* 1806 */ {I_PCOMGTQ, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+846, IF_SSE5|IF_AMD|IF_SO},
    /* 1807 */ {I_PCOMGEQ, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+855, IF_SSE5|IF_AMD|IF_SO},
    /* 1808 */ {I_PCOMEQQ, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+864, IF_SSE5|IF_AMD|IF_SO},
    /* 1809 */ {I_PCOMNEQQ, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+873, IF_SSE5|IF_AMD|IF_SO},
    /* 1810 */ {I_PCOMFALSEQ, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+882, IF_SSE5|IF_AMD|IF_SO},
    /* 1811 */ {I_PCOMTRUEQ, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+891, IF_SSE5|IF_AMD|IF_SO},
    /* 1812 */ {I_PCOMQ, 4, {XMMREG,XMMREG,RM_XMM,IMMEDIATE,0}, nasm_bytecodes+6334, IF_SSE5|IF_AMD|IF_SO},
    /* 1813 */ {I_PCOMLTUB, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+900, IF_SSE5|IF_AMD|IF_SO},
    /* 1814 */ {I_PCOMLEUB, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+909, IF_SSE5|IF_AMD|IF_SO},
    /* 1815 */ {I_PCOMGTUB, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+918, IF_SSE5|IF_AMD|IF_SO},
    /* 1816 */ {I_PCOMGEUB, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+927, IF_SSE5|IF_AMD|IF_SO},
    /* 1817 */ {I_PCOMEQUB, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+936, IF_SSE5|IF_AMD|IF_SO},
    /* 1818 */ {I_PCOMNEQUB, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+945, IF_SSE5|IF_AMD|IF_SO},
    /* 1819 */ {I_PCOMFALSEUB, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+954, IF_SSE5|IF_AMD|IF_SO},
    /* 1820 */ {I_PCOMTRUEUB, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+963, IF_SSE5|IF_AMD|IF_SO},
    /* 1821 */ {I_PCOMUB, 4, {XMMREG,XMMREG,RM_XMM,IMMEDIATE,0}, nasm_bytecodes+6342, IF_SSE5|IF_AMD|IF_SO},
    /* 1822 */ {I_PCOMLTUW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+972, IF_SSE5|IF_AMD|IF_SO},
    /* 1823 */ {I_PCOMLEUW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+981, IF_SSE5|IF_AMD|IF_SO},
    /* 1824 */ {I_PCOMGTUW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+990, IF_SSE5|IF_AMD|IF_SO},
    /* 1825 */ {I_PCOMGEUW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+999, IF_SSE5|IF_AMD|IF_SO},
    /* 1826 */ {I_PCOMEQUW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1008, IF_SSE5|IF_AMD|IF_SO},
    /* 1827 */ {I_PCOMNEQUW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1017, IF_SSE5|IF_AMD|IF_SO},
    /* 1828 */ {I_PCOMFALSEUW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1026, IF_SSE5|IF_AMD|IF_SO},
    /* 1829 */ {I_PCOMTRUEUW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1035, IF_SSE5|IF_AMD|IF_SO},
    /* 1830 */ {I_PCOMUW, 4, {XMMREG,XMMREG,RM_XMM,IMMEDIATE,0}, nasm_bytecodes+6350, IF_SSE5|IF_AMD|IF_SO},
    /* 1831 */ {I_PCOMLTUD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1044, IF_SSE5|IF_AMD|IF_SO},
    /* 1832 */ {I_PCOMLEUD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1053, IF_SSE5|IF_AMD|IF_SO},
    /* 1833 */ {I_PCOMGTUD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1062, IF_SSE5|IF_AMD|IF_SO},
    /* 1834 */ {I_PCOMGEUD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1071, IF_SSE5|IF_AMD|IF_SO},
    /* 1835 */ {I_PCOMEQUD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1080, IF_SSE5|IF_AMD|IF_SO},
    /* 1836 */ {I_PCOMNEQUD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1089, IF_SSE5|IF_AMD|IF_SO},
    /* 1837 */ {I_PCOMFALSEUD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1098, IF_SSE5|IF_AMD|IF_SO},
    /* 1838 */ {I_PCOMTRUEUD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1107, IF_SSE5|IF_AMD|IF_SO},
    /* 1839 */ {I_PCOMUD, 4, {XMMREG,XMMREG,RM_XMM,IMMEDIATE,0}, nasm_bytecodes+6358, IF_SSE5|IF_AMD|IF_SO},
    /* 1840 */ {I_PCOMLTUQ, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1116, IF_SSE5|IF_AMD|IF_SO},
    /* 1841 */ {I_PCOMLEUQ, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1125, IF_SSE5|IF_AMD|IF_SO},
    /* 1842 */ {I_PCOMGTUQ, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1134, IF_SSE5|IF_AMD|IF_SO},
    /* 1843 */ {I_PCOMGEUQ, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1143, IF_SSE5|IF_AMD|IF_SO},
    /* 1844 */ {I_PCOMEQUQ, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1152, IF_SSE5|IF_AMD|IF_SO},
    /* 1845 */ {I_PCOMNEQUQ, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1161, IF_SSE5|IF_AMD|IF_SO},
    /* 1846 */ {I_PCOMFALSEUQ, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1170, IF_SSE5|IF_AMD|IF_SO},
    /* 1847 */ {I_PCOMTRUEUQ, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1179, IF_SSE5|IF_AMD|IF_SO},
    /* 1848 */ {I_PCOMUQ, 4, {XMMREG,XMMREG,RM_XMM,IMMEDIATE,0}, nasm_bytecodes+6366, IF_SSE5|IF_AMD|IF_SO},
    /* 1849 */ {I_PERMPS, 4, {XMMREG,SAME_AS|0,XMMREG,RM_XMM,0}, nasm_bytecodes+9106, IF_SSE5|IF_AMD},
    /* 1850 */ {I_PERMPS, 4, {XMMREG,SAME_AS|0,RM_XMM,XMMREG,0}, nasm_bytecodes+9113, IF_SSE5|IF_AMD},
    /* 1851 */ {I_PERMPS, 4, {XMMREG,XMMREG,RM_XMM,SAME_AS|0,0}, nasm_bytecodes+9120, IF_SSE5|IF_AMD},
    /* 1852 */ {I_PERMPS, 4, {XMMREG,RM_XMM,XMMREG,SAME_AS|0,0}, nasm_bytecodes+9127, IF_SSE5|IF_AMD},
    /* 1853 */ {I_PERMPD, 4, {XMMREG,SAME_AS|0,XMMREG,RM_XMM,0}, nasm_bytecodes+9134, IF_SSE5|IF_AMD},
    /* 1854 */ {I_PERMPD, 4, {XMMREG,SAME_AS|0,RM_XMM,XMMREG,0}, nasm_bytecodes+9141, IF_SSE5|IF_AMD},
    /* 1855 */ {I_PERMPD, 4, {XMMREG,XMMREG,RM_XMM,SAME_AS|0,0}, nasm_bytecodes+9148, IF_SSE5|IF_AMD},
    /* 1856 */ {I_PERMPD, 4, {XMMREG,RM_XMM,XMMREG,SAME_AS|0,0}, nasm_bytecodes+9155, IF_SSE5|IF_AMD},
    /* 1857 */ {I_PCMOV, 4, {XMMREG,SAME_AS|0,XMMREG,RM_XMM,0}, nasm_bytecodes+9162, IF_SSE5|IF_AMD},
    /* 1858 */ {I_PCMOV, 4, {XMMREG,SAME_AS|0,RM_XMM,XMMREG,0}, nasm_bytecodes+9169, IF_SSE5|IF_AMD},
    /* 1859 */ {I_PCMOV, 4, {XMMREG,XMMREG,RM_XMM,SAME_AS|0,0}, nasm_bytecodes+9176, IF_SSE5|IF_AMD},
    /* 1860 */ {I_PCMOV, 4, {XMMREG,RM_XMM,XMMREG,SAME_AS|0,0}, nasm_bytecodes+9183, IF_SSE5|IF_AMD},
    /* 1861 */ {I_PPERM, 4, {XMMREG,SAME_AS|0,XMMREG,RM_XMM,0}, nasm_bytecodes+9190, IF_SSE5|IF_AMD},
    /* 1862 */ {I_PPERM, 4, {XMMREG,SAME_AS|0,RM_XMM,XMMREG,0}, nasm_bytecodes+9197, IF_SSE5|IF_AMD},
    /* 1863 */ {I_PPERM, 4, {XMMREG,XMMREG,RM_XMM,SAME_AS|0,0}, nasm_bytecodes+9204, IF_SSE5|IF_AMD},
    /* 1864 */ {I_PPERM, 4, {XMMREG,RM_XMM,XMMREG,SAME_AS|0,0}, nasm_bytecodes+9211, IF_SSE5|IF_AMD},
    /* 1865 */ {I_PMACSSWW, 4, {XMMREG,XMMREG,RM_XMM,SAME_AS|0,0}, nasm_bytecodes+9218, IF_SSE5|IF_AMD},
    /* 1866 */ {I_PMACSWW, 4, {XMMREG,XMMREG,RM_XMM,SAME_AS|0,0}, nasm_bytecodes+9225, IF_SSE5|IF_AMD},
    /* 1867 */ {I_PMACSSWD, 4, {XMMREG,XMMREG,RM_XMM,SAME_AS|0,0}, nasm_bytecodes+9232, IF_SSE5|IF_AMD},
    /* 1868 */ {I_PMACSWD, 4, {XMMREG,XMMREG,RM_XMM,SAME_AS|0,0}, nasm_bytecodes+9239, IF_SSE5|IF_AMD},
    /* 1869 */ {I_PMACSSDD, 4, {XMMREG,XMMREG,RM_XMM,SAME_AS|0,0}, nasm_bytecodes+9246, IF_SSE5|IF_AMD},
    /* 1870 */ {I_PMACSDD, 4, {XMMREG,XMMREG,RM_XMM,SAME_AS|0,0}, nasm_bytecodes+9253, IF_SSE5|IF_AMD},
    /* 1871 */ {I_PMACSSDQL, 4, {XMMREG,XMMREG,RM_XMM,SAME_AS|0,0}, nasm_bytecodes+9260, IF_SSE5|IF_AMD},
    /* 1872 */ {I_PMACSDQL, 4, {XMMREG,XMMREG,RM_XMM,SAME_AS|0,0}, nasm_bytecodes+9267, IF_SSE5|IF_AMD},
    /* 1873 */ {I_PMACSSDQH, 4, {XMMREG,XMMREG,RM_XMM,SAME_AS|0,0}, nasm_bytecodes+9274, IF_SSE5|IF_AMD},
    /* 1874 */ {I_PMACSDQH, 4, {XMMREG,XMMREG,RM_XMM,SAME_AS|0,0}, nasm_bytecodes+9281, IF_SSE5|IF_AMD},
    /* 1875 */ {I_PMADCSSWD, 4, {XMMREG,XMMREG,RM_XMM,SAME_AS|0,0}, nasm_bytecodes+9288, IF_SSE5|IF_AMD},
    /* 1876 */ {I_PMADCSWD, 4, {XMMREG,XMMREG,RM_XMM,SAME_AS|0,0}, nasm_bytecodes+9295, IF_SSE5|IF_AMD},
    /* 1877 */ {I_PROTB, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+9302, IF_SSE5|IF_AMD},
    /* 1878 */ {I_PROTB, 3, {XMMREG,RM_XMM,XMMREG,0,0}, nasm_bytecodes+9309, IF_SSE5|IF_AMD},
    /* 1879 */ {I_PROTW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+9316, IF_SSE5|IF_AMD},
    /* 1880 */ {I_PROTW, 3, {XMMREG,RM_XMM,XMMREG,0,0}, nasm_bytecodes+9323, IF_SSE5|IF_AMD},
    /* 1881 */ {I_PROTD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+9330, IF_SSE5|IF_AMD},
    /* 1882 */ {I_PROTD, 3, {XMMREG,RM_XMM,XMMREG,0,0}, nasm_bytecodes+9337, IF_SSE5|IF_AMD},
    /* 1883 */ {I_PROTQ, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+9344, IF_SSE5|IF_AMD},
    /* 1884 */ {I_PROTQ, 3, {XMMREG,RM_XMM,XMMREG,0,0}, nasm_bytecodes+9351, IF_SSE5|IF_AMD},
    /* 1885 */ {I_PSHLB, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+9358, IF_SSE5|IF_AMD},
    /* 1886 */ {I_PSHLB, 3, {XMMREG,RM_XMM,XMMREG,0,0}, nasm_bytecodes+9365, IF_SSE5|IF_AMD},
    /* 1887 */ {I_PSHLW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+9372, IF_SSE5|IF_AMD},
    /* 1888 */ {I_PSHLW, 3, {XMMREG,RM_XMM,XMMREG,0,0}, nasm_bytecodes+9379, IF_SSE5|IF_AMD},
    /* 1889 */ {I_PSHLD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+9386, IF_SSE5|IF_AMD},
    /* 1890 */ {I_PSHLD, 3, {XMMREG,RM_XMM,XMMREG,0,0}, nasm_bytecodes+9393, IF_SSE5|IF_AMD},
    /* 1891 */ {I_PSHLQ, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+9400, IF_SSE5|IF_AMD},
    /* 1892 */ {I_PSHLQ, 3, {XMMREG,RM_XMM,XMMREG,0,0}, nasm_bytecodes+9407, IF_SSE5|IF_AMD},
    /* 1893 */ {I_PSHAB, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+9414, IF_SSE5|IF_AMD},
    /* 1894 */ {I_PSHAB, 3, {XMMREG,RM_XMM,XMMREG,0,0}, nasm_bytecodes+9421, IF_SSE5|IF_AMD},
    /* 1895 */ {I_PSHAW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+9428, IF_SSE5|IF_AMD},
    /* 1896 */ {I_PSHAW, 3, {XMMREG,RM_XMM,XMMREG,0,0}, nasm_bytecodes+9435, IF_SSE5|IF_AMD},
    /* 1897 */ {I_PSHAD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+9442, IF_SSE5|IF_AMD},
    /* 1898 */ {I_PSHAD, 3, {XMMREG,RM_XMM,XMMREG,0,0}, nasm_bytecodes+9449, IF_SSE5|IF_AMD},
    /* 1899 */ {I_PSHAQ, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+9456, IF_SSE5|IF_AMD},
    /* 1900 */ {I_PSHAQ, 3, {XMMREG,RM_XMM,XMMREG,0,0}, nasm_bytecodes+9463, IF_SSE5|IF_AMD},
    /* 1901 */ {I_FRCZPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9470, IF_SSE5|IF_AMD},
    /* 1902 */ {I_FRCZPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9477, IF_SSE5|IF_AMD},
    /* 1903 */ {I_FRCZSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9484, IF_SSE5|IF_AMD},
    /* 1904 */ {I_FRCZSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9491, IF_SSE5|IF_AMD},
    /* 1905 */ {I_CVTPH2PS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9498, IF_SSE5|IF_AMD|IF_SQ},
    /* 1906 */ {I_CVTPS2PH, 2, {RM_XMM,XMMREG,0,0,0}, nasm_bytecodes+9505, IF_SSE5|IF_AMD|IF_SQ},
    /* 1907 */ {I_PHADDBW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9512, IF_SSE5|IF_AMD},
    /* 1908 */ {I_PHADDBD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9519, IF_SSE5|IF_AMD},
    /* 1909 */ {I_PHADDBQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9526, IF_SSE5|IF_AMD},
    /* 1910 */ {I_PHADDWD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9533, IF_SSE5|IF_AMD},
    /* 1911 */ {I_PHADDWQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9540, IF_SSE5|IF_AMD},
    /* 1912 */ {I_PHADDDQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9547, IF_SSE5|IF_AMD},
    /* 1913 */ {I_PHADDUBW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9554, IF_SSE5|IF_AMD},
    /* 1914 */ {I_PHADDUBD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9561, IF_SSE5|IF_AMD},
    /* 1915 */ {I_PHADDUBQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9568, IF_SSE5|IF_AMD},
    /* 1916 */ {I_PHADDUWD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9575, IF_SSE5|IF_AMD},
    /* 1917 */ {I_PHADDUWQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9582, IF_SSE5|IF_AMD},
    /* 1918 */ {I_PHADDUDQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9589, IF_SSE5|IF_AMD},
    /* 1919 */ {I_PHSUBBW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9596, IF_SSE5|IF_AMD},
    /* 1920 */ {I_PHSUBWD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9603, IF_SSE5|IF_AMD},
    /* 1921 */ {I_PHSUBDQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9610, IF_SSE5|IF_AMD},
    /* 1922 */ {I_PROTB, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6374, IF_SSE5|IF_AMD},
    /* 1923 */ {I_PROTW, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6382, IF_SSE5|IF_AMD},
    /* 1924 */ {I_PROTD, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6390, IF_SSE5|IF_AMD},
    /* 1925 */ {I_PROTQ, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6398, IF_SSE5|IF_AMD},
    /* 1926 */ {I_ROUNDPS, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6190, IF_SSE5|IF_AMD},
    /* 1927 */ {I_ROUNDPD, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6190, IF_SSE5|IF_AMD},
    /* 1928 */ {I_ROUNDSS, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6190, IF_SSE5|IF_AMD},
    /* 1929 */ {I_ROUNDSD, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6190, IF_SSE5|IF_AMD},
    /* 1930 */ {I_GETSEC, 0, {0,0,0,0,0}, nasm_bytecodes+19627, IF_KATMAI},
    /* 1931 */ {I_PFRCPV, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+6406, IF_PENT|IF_3DNOW|IF_SQ|IF_CYRIX},
    /* 1932 */ {I_PFRSQRTV, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+6414, IF_PENT|IF_3DNOW|IF_SQ|IF_CYRIX},
    /* 1933 */ {I_MOVBE, 2, {REG16,MEMORY|BITS16,0,0,0}, nasm_bytecodes+9617, IF_NEHALEM|IF_SM},
    /* 1934 */ {I_MOVBE, 2, {REG32,MEMORY|BITS32,0,0,0}, nasm_bytecodes+9624, IF_NEHALEM|IF_SM},
    /* 1935 */ {I_MOVBE, 2, {REG64,MEMORY|BITS64,0,0,0}, nasm_bytecodes+9631, IF_NEHALEM|IF_SM},
    /* 1936 */ {I_MOVBE, 2, {MEMORY|BITS16,REG16,0,0,0}, nasm_bytecodes+9638, IF_NEHALEM|IF_SM},
    /* 1937 */ {I_MOVBE, 2, {MEMORY|BITS32,REG32,0,0,0}, nasm_bytecodes+9645, IF_NEHALEM|IF_SM},
    /* 1938 */ {I_MOVBE, 2, {MEMORY|BITS64,REG64,0,0,0}, nasm_bytecodes+9652, IF_NEHALEM|IF_SM},
    /* 1939 */ {I_AESENC, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9659, IF_WESTMERE|IF_SO},
    /* 1940 */ {I_AESENCLAST, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9666, IF_WESTMERE|IF_SO},
    /* 1941 */ {I_AESDEC, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9673, IF_WESTMERE|IF_SO},
    /* 1942 */ {I_AESDECLAST, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9680, IF_WESTMERE|IF_SO},
    /* 1943 */ {I_AESIMC, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9687, IF_WESTMERE|IF_SO},
    /* 1944 */ {I_AESKEYGENASSIST, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6422, IF_WESTMERE|IF_SO},
    /* 1945 */ {I_VAESENC, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+9694, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 1946 */ {I_VAESENC, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9701, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 1947 */ {I_VAESENCLAST, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+9708, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 1948 */ {I_VAESENCLAST, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9715, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 1949 */ {I_VAESDEC, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+9722, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 1950 */ {I_VAESDEC, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9729, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 1951 */ {I_VAESDECLAST, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+9736, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 1952 */ {I_VAESDECLAST, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9743, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 1953 */ {I_VAESIMC, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9750, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 1954 */ {I_VAESKEYGENASSIST, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6430, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 1955 */ {I_VADDPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+9757, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 1956 */ {I_VADDPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9764, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 1957 */ {I_VADDPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+9771, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 1958 */ {I_VADDPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+9778, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 1959 */ {I_VADDPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+9785, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 1960 */ {I_VADDPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9792, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 1961 */ {I_VADDPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+9799, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 1962 */ {I_VADDPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+9806, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 1963 */ {I_VADDSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+9813, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 1964 */ {I_VADDSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9820, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 1965 */ {I_VADDSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+9827, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 1966 */ {I_VADDSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9834, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 1967 */ {I_VADDSUBPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+9841, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 1968 */ {I_VADDSUBPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9848, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 1969 */ {I_VADDSUBPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+9855, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 1970 */ {I_VADDSUBPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+9862, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 1971 */ {I_VADDSUBPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+9869, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 1972 */ {I_VADDSUBPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9876, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 1973 */ {I_VADDSUBPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+9883, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 1974 */ {I_VADDSUBPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+9890, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 1975 */ {I_VANDPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+9897, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 1976 */ {I_VANDPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9904, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 1977 */ {I_VANDPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+9911, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 1978 */ {I_VANDPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+9918, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 1979 */ {I_VANDPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+9925, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 1980 */ {I_VANDPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9932, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 1981 */ {I_VANDPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+9939, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 1982 */ {I_VANDPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+9946, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 1983 */ {I_VANDNPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+9953, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 1984 */ {I_VANDNPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9960, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 1985 */ {I_VANDNPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+9967, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 1986 */ {I_VANDNPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+9974, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 1987 */ {I_VANDNPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+9981, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 1988 */ {I_VANDNPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9988, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 1989 */ {I_VANDNPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+9995, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 1990 */ {I_VANDNPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+10002, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 1991 */ {I_VBLENDPD, 4, {XMMREG,XMMREG,RM_XMM,IMMEDIATE,0}, nasm_bytecodes+6438, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 1992 */ {I_VBLENDPD, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6446, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 1993 */ {I_VBLENDPD, 4, {YMMREG,YMMREG,RM_YMM,IMMEDIATE,0}, nasm_bytecodes+6454, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 1994 */ {I_VBLENDPD, 3, {YMMREG,RM_YMM,IMMEDIATE,0,0}, nasm_bytecodes+6462, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 1995 */ {I_VBLENDPS, 4, {XMMREG,XMMREG,RM_XMM,IMMEDIATE,0}, nasm_bytecodes+6470, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 1996 */ {I_VBLENDPS, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6478, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 1997 */ {I_VBLENDPS, 4, {YMMREG,YMMREG,RM_YMM,IMMEDIATE,0}, nasm_bytecodes+6486, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 1998 */ {I_VBLENDPS, 3, {YMMREG,RM_YMM,IMMEDIATE,0,0}, nasm_bytecodes+6494, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 1999 */ {I_VBLENDVPD, 4, {XMMREG,XMMREG,RM_XMM,RM_XMM,0}, nasm_bytecodes+1188, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2000 */ {I_VBLENDVPD, 3, {XMMREG,RM_XMM,XMM0,0,0}, nasm_bytecodes+10009, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2001 */ {I_VBLENDVPD, 4, {YMMREG,YMMREG,RM_YMM,RM_YMM,0}, nasm_bytecodes+1197, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2002 */ {I_VBLENDVPD, 3, {YMMREG,RM_YMM,YMM0,0,0}, nasm_bytecodes+10016, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2003 */ {I_VBLENDVPS, 4, {XMMREG,XMMREG,RM_XMM,RM_XMM,0}, nasm_bytecodes+1206, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2004 */ {I_VBLENDVPS, 3, {XMMREG,RM_XMM,XMM0,0,0}, nasm_bytecodes+10023, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2005 */ {I_VBLENDVPS, 4, {YMMREG,YMMREG,RM_YMM,RM_YMM,0}, nasm_bytecodes+1215, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2006 */ {I_VBLENDVPD, 3, {YMMREG,RM_YMM,YMM0,0,0}, nasm_bytecodes+10030, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2007 */ {I_VBROADCASTSS, 2, {XMMREG,MEMORY,0,0,0}, nasm_bytecodes+10037, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2008 */ {I_VBROADCASTSS, 2, {YMMREG,MEMORY,0,0,0}, nasm_bytecodes+10044, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2009 */ {I_VBROADCASTSD, 2, {YMMREG,MEMORY,0,0,0}, nasm_bytecodes+10051, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2010 */ {I_VBROADCASTF128, 2, {YMMREG,MEMORY,0,0,0}, nasm_bytecodes+10058, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2011 */ {I_VCMPEQPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1224, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2012 */ {I_VCMPEQPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+1233, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2013 */ {I_VCMPEQPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+1242, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2014 */ {I_VCMPEQPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+1251, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2015 */ {I_VCMPLTPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1260, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2016 */ {I_VCMPLTPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+1269, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2017 */ {I_VCMPLTPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+1278, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2018 */ {I_VCMPLTPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+1287, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2019 */ {I_VCMPLEPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1296, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2020 */ {I_VCMPLEPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+1305, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2021 */ {I_VCMPLEPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+1314, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2022 */ {I_VCMPLEPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+1323, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2023 */ {I_VCMPUNORDPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1332, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2024 */ {I_VCMPUNORDPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+1341, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2025 */ {I_VCMPUNORDPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+1350, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2026 */ {I_VCMPUNORDPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+1359, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2027 */ {I_VCMPNEQPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1368, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2028 */ {I_VCMPNEQPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+1377, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2029 */ {I_VCMPNEQPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+1386, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2030 */ {I_VCMPNEQPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+1395, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2031 */ {I_VCMPNLTPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1404, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2032 */ {I_VCMPNLTPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+1413, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2033 */ {I_VCMPNLTPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+1422, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2034 */ {I_VCMPNLTPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+1431, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2035 */ {I_VCMPNLEPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1440, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2036 */ {I_VCMPNLEPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+1449, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2037 */ {I_VCMPNLEPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+1458, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2038 */ {I_VCMPNLEPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+1467, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2039 */ {I_VCMPORDPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1476, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2040 */ {I_VCMPORDPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+1485, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2041 */ {I_VCMPORDPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+1494, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2042 */ {I_VCMPORDPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+1503, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2043 */ {I_VCMPEQ_UQPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1512, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2044 */ {I_VCMPEQ_UQPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+1521, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2045 */ {I_VCMPEQ_UQPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+1530, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2046 */ {I_VCMPEQ_UQPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+1539, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2047 */ {I_VCMPNGEPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1548, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2048 */ {I_VCMPNGEPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+1557, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2049 */ {I_VCMPNGEPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+1566, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2050 */ {I_VCMPNGEPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+1575, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2051 */ {I_VCMPNGTPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1584, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2052 */ {I_VCMPNGTPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+1593, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2053 */ {I_VCMPNGTPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+1602, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2054 */ {I_VCMPNGTPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+1611, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2055 */ {I_VCMPFALSEPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1620, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2056 */ {I_VCMPFALSEPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+1629, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2057 */ {I_VCMPFALSEPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+1638, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2058 */ {I_VCMPFALSEPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+1647, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2059 */ {I_VCMPNEQ_OQPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1656, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2060 */ {I_VCMPNEQ_OQPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+1665, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2061 */ {I_VCMPNEQ_OQPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+1674, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2062 */ {I_VCMPNEQ_OQPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+1683, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2063 */ {I_VCMPGEPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1692, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2064 */ {I_VCMPGEPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+1701, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2065 */ {I_VCMPGEPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+1710, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2066 */ {I_VCMPGEPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+1719, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2067 */ {I_VCMPGTPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1728, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2068 */ {I_VCMPGTPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+1737, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2069 */ {I_VCMPGTPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+1746, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2070 */ {I_VCMPGTPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+1755, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2071 */ {I_VCMPTRUEPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1764, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2072 */ {I_VCMPTRUEPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+1773, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2073 */ {I_VCMPTRUEPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+1782, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2074 */ {I_VCMPTRUEPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+1791, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2075 */ {I_VCMPEQ_OSPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1800, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2076 */ {I_VCMPEQ_OSPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+1809, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2077 */ {I_VCMPEQ_OSPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+1818, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2078 */ {I_VCMPEQ_OSPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+1827, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2079 */ {I_VCMPLT_OQPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1836, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2080 */ {I_VCMPLT_OQPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+1845, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2081 */ {I_VCMPLT_OQPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+1854, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2082 */ {I_VCMPLT_OQPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+1863, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2083 */ {I_VCMPLE_OQPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1872, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2084 */ {I_VCMPLE_OQPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+1881, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2085 */ {I_VCMPLE_OQPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+1890, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2086 */ {I_VCMPLE_OQPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+1899, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2087 */ {I_VCMPUNORD_SPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1908, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2088 */ {I_VCMPUNORD_SPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+1917, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2089 */ {I_VCMPUNORD_SPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+1926, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2090 */ {I_VCMPUNORD_SPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+1935, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2091 */ {I_VCMPNEQ_USPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1944, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2092 */ {I_VCMPNEQ_USPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+1953, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2093 */ {I_VCMPNEQ_USPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+1962, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2094 */ {I_VCMPNEQ_USPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+1971, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2095 */ {I_VCMPNLT_UQPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1980, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2096 */ {I_VCMPNLT_UQPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+1989, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2097 */ {I_VCMPNLT_UQPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+1998, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2098 */ {I_VCMPNLT_UQPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+2007, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2099 */ {I_VCMPNLE_UQPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+2016, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2100 */ {I_VCMPNLE_UQPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+2025, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2101 */ {I_VCMPNLE_UQPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+2034, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2102 */ {I_VCMPNLE_UQPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+2043, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2103 */ {I_VCMPORD_SPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+2052, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2104 */ {I_VCMPORD_SPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+2061, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2105 */ {I_VCMPORD_SPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+2070, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2106 */ {I_VCMPORS_SPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+2079, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2107 */ {I_VCMPEQ_USPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+2088, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2108 */ {I_VCMPEQ_USPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+2097, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2109 */ {I_VCMPEQ_USPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+2106, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2110 */ {I_VCMPEQ_USPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+2115, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2111 */ {I_VCMPNGE_UQPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+2124, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2112 */ {I_VCMPNGE_UQPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+2133, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2113 */ {I_VCMPNGE_UQPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+2142, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2114 */ {I_VCMPNGE_UQPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+2151, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2115 */ {I_VCMPNGT_UQPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+2160, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2116 */ {I_VCMPNGT_UQPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+2169, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2117 */ {I_VCMPNGT_UQPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+2178, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2118 */ {I_VCMPNGT_UQPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+2187, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2119 */ {I_VCMPFALSE_OSPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+2196, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2120 */ {I_VCMPFALSE_OSPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+2205, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2121 */ {I_VCMPFALSE_OSPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+2214, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2122 */ {I_VCMPFALSE_OSPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+2223, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2123 */ {I_VCMPNEQ_OSPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+2232, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2124 */ {I_VCMPNEQ_OSPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+2241, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2125 */ {I_VCMPNEQ_OSPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+2250, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2126 */ {I_VCMPNEQ_OSPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+2259, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2127 */ {I_VCMPGE_OQPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+2268, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2128 */ {I_VCMPGE_OQPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+2277, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2129 */ {I_VCMPGE_OQPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+2286, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2130 */ {I_VCMPGE_OQPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+2295, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2131 */ {I_VCMPGT_OQPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+2304, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2132 */ {I_VCMPGT_OQPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+2313, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2133 */ {I_VCMPGT_OQPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+2322, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2134 */ {I_VCMPGT_OQPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+2331, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2135 */ {I_VCMPTRUE_USPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+2340, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2136 */ {I_VCMPTRUE_USPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+2349, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2137 */ {I_VCMPTRUE_USPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+2358, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2138 */ {I_VCMPTRUE_USPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+2367, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2139 */ {I_VCMPPD, 4, {XMMREG,XMMREG,RM_XMM,IMMEDIATE,0}, nasm_bytecodes+6502, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2140 */ {I_VCMPPD, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6510, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2141 */ {I_VCMPPD, 4, {YMMREG,YMMREG,RM_YMM,IMMEDIATE,0}, nasm_bytecodes+6518, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2142 */ {I_VCMPPD, 3, {YMMREG,RM_YMM,IMMEDIATE,0,0}, nasm_bytecodes+6526, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2143 */ {I_VCMPEQPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+2376, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2144 */ {I_VCMPEQPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+2385, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2145 */ {I_VCMPEQPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+2394, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2146 */ {I_VCMPEQPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+2403, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2147 */ {I_VCMPLTPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+2412, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2148 */ {I_VCMPLTPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+2421, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2149 */ {I_VCMPLTPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+2430, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2150 */ {I_VCMPLTPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+2439, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2151 */ {I_VCMPLEPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+2448, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2152 */ {I_VCMPLEPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+2457, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2153 */ {I_VCMPLEPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+2466, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2154 */ {I_VCMPLEPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+2475, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2155 */ {I_VCMPUNORDPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+2484, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2156 */ {I_VCMPUNORDPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+2493, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2157 */ {I_VCMPUNORDPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+2502, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2158 */ {I_VCMPUNORDPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+2511, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2159 */ {I_VCMPNEQPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+2520, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2160 */ {I_VCMPNEQPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+2529, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2161 */ {I_VCMPNEQPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+2538, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2162 */ {I_VCMPNEQPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+2547, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2163 */ {I_VCMPNLTPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+2556, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2164 */ {I_VCMPNLTPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+2565, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2165 */ {I_VCMPNLTPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+2574, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2166 */ {I_VCMPNLTPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+2583, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2167 */ {I_VCMPNLEPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+2592, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2168 */ {I_VCMPNLEPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+2601, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2169 */ {I_VCMPNLEPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+2610, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2170 */ {I_VCMPNLEPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+2619, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2171 */ {I_VCMPORDPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+2628, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2172 */ {I_VCMPORDPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+2637, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2173 */ {I_VCMPORDPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+2646, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2174 */ {I_VCMPORDPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+2655, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2175 */ {I_VCMPEQ_UQPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+2664, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2176 */ {I_VCMPEQ_UQPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+2673, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2177 */ {I_VCMPEQ_UQPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+2682, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2178 */ {I_VCMPEQ_UQPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+2691, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2179 */ {I_VCMPNGEPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+2700, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2180 */ {I_VCMPNGEPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+2709, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2181 */ {I_VCMPNGEPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+2718, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2182 */ {I_VCMPNGEPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+2727, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2183 */ {I_VCMPNGTPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+2736, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2184 */ {I_VCMPNGTPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+2745, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2185 */ {I_VCMPNGTPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+2754, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2186 */ {I_VCMPNGTPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+2763, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2187 */ {I_VCMPFALSEPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+2772, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2188 */ {I_VCMPFALSEPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+2781, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2189 */ {I_VCMPFALSEPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+2790, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2190 */ {I_VCMPFALSEPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+2799, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2191 */ {I_VCMPNEQ_OQPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+2808, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2192 */ {I_VCMPNEQ_OQPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+2817, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2193 */ {I_VCMPNEQ_OQPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+2826, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2194 */ {I_VCMPNEQ_OQPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+2835, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2195 */ {I_VCMPGEPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+2844, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2196 */ {I_VCMPGEPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+2853, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2197 */ {I_VCMPGEPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+2862, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2198 */ {I_VCMPGEPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+2871, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2199 */ {I_VCMPGTPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+2880, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2200 */ {I_VCMPGTPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+2889, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2201 */ {I_VCMPGTPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+2898, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2202 */ {I_VCMPGTPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+2907, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2203 */ {I_VCMPTRUEPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+2916, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2204 */ {I_VCMPTRUEPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+2925, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2205 */ {I_VCMPTRUEPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+2934, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2206 */ {I_VCMPTRUEPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+2943, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2207 */ {I_VCMPEQ_OSPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+2952, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2208 */ {I_VCMPEQ_OSPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+2961, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2209 */ {I_VCMPEQ_OSPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+2970, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2210 */ {I_VCMPEQ_OSPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+2979, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2211 */ {I_VCMPLT_OQPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+2988, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2212 */ {I_VCMPLT_OQPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+2997, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2213 */ {I_VCMPLT_OQPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+3006, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2214 */ {I_VCMPLT_OQPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+3015, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2215 */ {I_VCMPLE_OQPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3024, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2216 */ {I_VCMPLE_OQPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3033, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2217 */ {I_VCMPLE_OQPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+3042, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2218 */ {I_VCMPLE_OQPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+3051, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2219 */ {I_VCMPUNORD_SPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3060, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2220 */ {I_VCMPUNORD_SPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3069, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2221 */ {I_VCMPUNORD_SPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+3078, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2222 */ {I_VCMPUNORD_SPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+3087, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2223 */ {I_VCMPNEQ_USPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3096, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2224 */ {I_VCMPNEQ_USPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3105, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2225 */ {I_VCMPNEQ_USPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+3114, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2226 */ {I_VCMPNEQ_USPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+3123, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2227 */ {I_VCMPNLT_UQPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3132, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2228 */ {I_VCMPNLT_UQPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3141, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2229 */ {I_VCMPNLT_UQPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+3150, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2230 */ {I_VCMPNLT_UQPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+3159, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2231 */ {I_VCMPNLE_UQPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3168, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2232 */ {I_VCMPNLE_UQPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3177, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2233 */ {I_VCMPNLE_UQPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+3186, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2234 */ {I_VCMPNLE_UQPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+3195, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2235 */ {I_VCMPORD_SPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3204, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2236 */ {I_VCMPORD_SPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3213, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2237 */ {I_VCMPORD_SPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+3222, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2238 */ {I_VCMPORS_SPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+3231, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2239 */ {I_VCMPEQ_USPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3240, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2240 */ {I_VCMPEQ_USPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3249, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2241 */ {I_VCMPEQ_USPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+3258, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2242 */ {I_VCMPEQ_USPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+3267, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2243 */ {I_VCMPNGE_UQPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3276, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2244 */ {I_VCMPNGE_UQPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3285, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2245 */ {I_VCMPNGE_UQPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+3294, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2246 */ {I_VCMPNGE_UQPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+3303, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2247 */ {I_VCMPNGT_UQPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3312, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2248 */ {I_VCMPNGT_UQPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3321, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2249 */ {I_VCMPNGT_UQPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+3330, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2250 */ {I_VCMPNGT_UQPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+3339, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2251 */ {I_VCMPFALSE_OSPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3348, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2252 */ {I_VCMPFALSE_OSPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3357, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2253 */ {I_VCMPFALSE_OSPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+3366, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2254 */ {I_VCMPFALSE_OSPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+3375, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2255 */ {I_VCMPNEQ_OSPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3384, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2256 */ {I_VCMPNEQ_OSPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3393, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2257 */ {I_VCMPNEQ_OSPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+3402, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2258 */ {I_VCMPNEQ_OSPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+3411, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2259 */ {I_VCMPGE_OQPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3420, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2260 */ {I_VCMPGE_OQPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3429, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2261 */ {I_VCMPGE_OQPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+3438, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2262 */ {I_VCMPGE_OQPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+3447, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2263 */ {I_VCMPGT_OQPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3456, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2264 */ {I_VCMPGT_OQPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3465, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2265 */ {I_VCMPGT_OQPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+3474, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2266 */ {I_VCMPGT_OQPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+3483, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2267 */ {I_VCMPTRUE_USPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3492, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2268 */ {I_VCMPTRUE_USPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3501, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2269 */ {I_VCMPTRUE_USPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+3510, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2270 */ {I_VCMPTRUE_USPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+3519, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2271 */ {I_VCMPPS, 4, {XMMREG,XMMREG,RM_XMM,IMMEDIATE,0}, nasm_bytecodes+6534, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2272 */ {I_VCMPPS, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6542, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2273 */ {I_VCMPPS, 4, {YMMREG,YMMREG,RM_YMM,IMMEDIATE,0}, nasm_bytecodes+6550, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2274 */ {I_VCMPPS, 3, {YMMREG,RM_YMM,IMMEDIATE,0,0}, nasm_bytecodes+6558, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2275 */ {I_VCMPEQSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3528, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2276 */ {I_VCMPEQSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3537, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2277 */ {I_VCMPLTSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3546, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2278 */ {I_VCMPLTSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3555, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2279 */ {I_VCMPLESD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3564, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2280 */ {I_VCMPLESD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3573, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2281 */ {I_VCMPUNORDSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3582, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2282 */ {I_VCMPUNORDSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3591, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2283 */ {I_VCMPNEQSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3600, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2284 */ {I_VCMPNEQSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3609, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2285 */ {I_VCMPNLTSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3618, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2286 */ {I_VCMPNLTSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3627, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2287 */ {I_VCMPNLESD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3636, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2288 */ {I_VCMPNLESD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3645, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2289 */ {I_VCMPORDSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3654, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2290 */ {I_VCMPORDSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3663, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2291 */ {I_VCMPEQ_UQSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3672, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2292 */ {I_VCMPEQ_UQSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3681, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2293 */ {I_VCMPNGESD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3690, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2294 */ {I_VCMPNGESD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3699, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2295 */ {I_VCMPNGTSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3708, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2296 */ {I_VCMPNGTSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3717, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2297 */ {I_VCMPFALSESD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3726, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2298 */ {I_VCMPFALSESD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3735, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2299 */ {I_VCMPNEQ_OQSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3744, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2300 */ {I_VCMPNEQ_OQSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3753, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2301 */ {I_VCMPGESD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3762, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2302 */ {I_VCMPGESD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3771, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2303 */ {I_VCMPGTSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3780, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2304 */ {I_VCMPGTSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3789, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2305 */ {I_VCMPTRUESD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3798, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2306 */ {I_VCMPTRUESD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3807, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2307 */ {I_VCMPEQ_OSSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3816, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2308 */ {I_VCMPEQ_OSSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3825, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2309 */ {I_VCMPLT_OQSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3834, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2310 */ {I_VCMPLT_OQSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3843, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2311 */ {I_VCMPLE_OQSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3852, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2312 */ {I_VCMPLE_OQSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3861, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2313 */ {I_VCMPUNORD_SSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3870, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2314 */ {I_VCMPUNORD_SSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3879, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2315 */ {I_VCMPNEQ_USSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3888, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2316 */ {I_VCMPNEQ_USSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3897, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2317 */ {I_VCMPNLT_UQSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3906, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2318 */ {I_VCMPNLT_UQSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3915, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2319 */ {I_VCMPNLE_UQSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3924, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2320 */ {I_VCMPNLE_UQSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3933, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2321 */ {I_VCMPORD_SSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3942, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2322 */ {I_VCMPORD_SSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3951, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2323 */ {I_VCMPEQ_USSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3960, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2324 */ {I_VCMPEQ_USSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3969, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2325 */ {I_VCMPNGE_UQSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3978, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2326 */ {I_VCMPNGE_UQSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3987, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2327 */ {I_VCMPNGT_UQSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3996, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2328 */ {I_VCMPNGT_UQSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4005, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2329 */ {I_VCMPFALSE_OSSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+4014, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2330 */ {I_VCMPFALSE_OSSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4023, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2331 */ {I_VCMPNEQ_OSSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+4032, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2332 */ {I_VCMPNEQ_OSSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4041, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2333 */ {I_VCMPGE_OQSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+4050, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2334 */ {I_VCMPGE_OQSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4059, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2335 */ {I_VCMPGT_OQSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+4068, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2336 */ {I_VCMPGT_OQSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4077, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2337 */ {I_VCMPTRUE_USSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+4086, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2338 */ {I_VCMPTRUE_USSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4095, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2339 */ {I_VCMPSD, 4, {XMMREG,XMMREG,RM_XMM,IMMEDIATE,0}, nasm_bytecodes+6566, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2340 */ {I_VCMPSD, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6574, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2341 */ {I_VCMPEQSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+4104, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2342 */ {I_VCMPEQSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4113, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2343 */ {I_VCMPLTSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+4122, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2344 */ {I_VCMPLTSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4131, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2345 */ {I_VCMPLESS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+4140, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2346 */ {I_VCMPLESS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4149, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2347 */ {I_VCMPUNORDSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+4158, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2348 */ {I_VCMPUNORDSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4167, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2349 */ {I_VCMPNEQSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+4176, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2350 */ {I_VCMPNEQSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4185, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2351 */ {I_VCMPNLTSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+4194, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2352 */ {I_VCMPNLTSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4203, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2353 */ {I_VCMPNLESS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+4212, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2354 */ {I_VCMPNLESS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4221, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2355 */ {I_VCMPORDSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+4230, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2356 */ {I_VCMPORDSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4239, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2357 */ {I_VCMPEQ_UQSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+4248, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2358 */ {I_VCMPEQ_UQSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4257, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2359 */ {I_VCMPNGESS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+4266, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2360 */ {I_VCMPNGESS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4275, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2361 */ {I_VCMPNGTSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+4284, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2362 */ {I_VCMPNGTSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4293, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2363 */ {I_VCMPFALSESS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+4302, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2364 */ {I_VCMPFALSESS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4311, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2365 */ {I_VCMPNEQ_OQSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+4320, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2366 */ {I_VCMPNEQ_OQSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4329, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2367 */ {I_VCMPGESS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+4338, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2368 */ {I_VCMPGESS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4347, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2369 */ {I_VCMPGTSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+4356, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2370 */ {I_VCMPGTSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4365, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2371 */ {I_VCMPTRUESS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+4374, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2372 */ {I_VCMPTRUESS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4383, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2373 */ {I_VCMPEQ_OSSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+4392, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2374 */ {I_VCMPEQ_OSSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4401, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2375 */ {I_VCMPLT_OQSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+4410, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2376 */ {I_VCMPLT_OQSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4419, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2377 */ {I_VCMPLE_OQSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+4428, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2378 */ {I_VCMPLE_OQSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4437, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2379 */ {I_VCMPUNORD_SSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+4446, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2380 */ {I_VCMPUNORD_SSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4455, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2381 */ {I_VCMPNEQ_USSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+4464, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2382 */ {I_VCMPNEQ_USSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4473, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2383 */ {I_VCMPNLT_UQSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+4482, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2384 */ {I_VCMPNLT_UQSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4491, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2385 */ {I_VCMPNLE_UQSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+4500, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2386 */ {I_VCMPNLE_UQSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4509, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2387 */ {I_VCMPORD_SSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+4518, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2388 */ {I_VCMPORD_SSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4527, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2389 */ {I_VCMPEQ_USSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+4536, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2390 */ {I_VCMPEQ_USSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4545, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2391 */ {I_VCMPNGE_UQSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+4554, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2392 */ {I_VCMPNGE_UQSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4563, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2393 */ {I_VCMPNGT_UQSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+4572, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2394 */ {I_VCMPNGT_UQSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4581, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2395 */ {I_VCMPFALSE_OSSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+4590, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2396 */ {I_VCMPFALSE_OSSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4599, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2397 */ {I_VCMPNEQ_OSSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+4608, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2398 */ {I_VCMPNEQ_OSSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4617, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2399 */ {I_VCMPGE_OQSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+4626, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2400 */ {I_VCMPGE_OQSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4635, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2401 */ {I_VCMPGT_OQSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+4644, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2402 */ {I_VCMPGT_OQSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4653, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2403 */ {I_VCMPTRUE_USSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+4662, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2404 */ {I_VCMPTRUE_USSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4671, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2405 */ {I_VCMPSS, 4, {XMMREG,XMMREG,RM_XMM,IMMEDIATE,0}, nasm_bytecodes+6582, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2406 */ {I_VCMPSS, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6590, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2407 */ {I_VCOMISD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+10065, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2408 */ {I_VCOMISS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+10072, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2409 */ {I_VCVTDQ2PD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+10079, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2410 */ {I_VCVTDQ2PD, 2, {YMMREG,RM_XMM,0,0,0}, nasm_bytecodes+10086, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2411 */ {I_VCVTDQ2PS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+10093, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2412 */ {I_VCVTDQ2PS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+10100, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2413 */ {I_VCVTPD2DQ, 2, {XMMREG,XMMREG,0,0,0}, nasm_bytecodes+10107, IF_AVX|IF_SANDYBRIDGE},
    /* 2414 */ {I_VCVTPD2DQ, 2, {XMMREG,MEMORY|BITS128,0,0,0}, nasm_bytecodes+10107, IF_AVX|IF_SANDYBRIDGE},
    /* 2415 */ {I_VCVTPD2DQ, 2, {XMMREG,YMMREG,0,0,0}, nasm_bytecodes+10114, IF_AVX|IF_SANDYBRIDGE},
    /* 2416 */ {I_VCVTPD2DQ, 2, {XMMREG,MEMORY|BITS256,0,0,0}, nasm_bytecodes+10114, IF_AVX|IF_SANDYBRIDGE},
    /* 2417 */ {I_VCVTPD2PS, 2, {XMMREG,XMMREG,0,0,0}, nasm_bytecodes+10121, IF_AVX|IF_SANDYBRIDGE},
    /* 2418 */ {I_VCVTPD2PS, 2, {XMMREG,MEMORY|BITS128,0,0,0}, nasm_bytecodes+10121, IF_AVX|IF_SANDYBRIDGE},
    /* 2419 */ {I_VCVTPD2PS, 2, {XMMREG,YMMREG,0,0,0}, nasm_bytecodes+10128, IF_AVX|IF_SANDYBRIDGE},
    /* 2420 */ {I_VCVTPD2PS, 2, {XMMREG,MEMORY|BITS256,0,0,0}, nasm_bytecodes+10128, IF_AVX|IF_SANDYBRIDGE},
    /* 2421 */ {I_VCVTPS2DQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+10135, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2422 */ {I_VCVTPS2DQ, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+10142, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2423 */ {I_VCVTPS2PD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+10149, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2424 */ {I_VCVTPS2PD, 2, {YMMREG,RM_XMM,0,0,0}, nasm_bytecodes+10156, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2425 */ {I_VCVTSD2SI, 2, {REG32,RM_XMM,0,0,0}, nasm_bytecodes+10163, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2426 */ {I_VCVTSD2SI, 2, {REG64,RM_XMM,0,0,0}, nasm_bytecodes+10170, IF_AVX|IF_SANDYBRIDGE|IF_SQ|IF_LONG},
    /* 2427 */ {I_VCVTSD2SS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+10177, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2428 */ {I_VCVTSD2SS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+10184, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2429 */ {I_VCVTSI2SD, 3, {XMMREG,XMMREG,RM_GPR|BITS32,0,0}, nasm_bytecodes+10191, IF_AVX|IF_SANDYBRIDGE},
    /* 2430 */ {I_VCVTSI2SD, 2, {XMMREG,RM_GPR|BITS32,0,0,0}, nasm_bytecodes+10198, IF_AVX|IF_SANDYBRIDGE},
    /* 2431 */ {I_VCVTSI2SD, 3, {XMMREG,XMMREG,RM_GPR|BITS64,0,0}, nasm_bytecodes+10205, IF_AVX|IF_SANDYBRIDGE|IF_LONG},
    /* 2432 */ {I_VCVTSI2SD, 2, {XMMREG,RM_GPR|BITS64,0,0,0}, nasm_bytecodes+10212, IF_AVX|IF_SANDYBRIDGE|IF_LONG},
    /* 2433 */ {I_VCVTSI2SS, 3, {XMMREG,XMMREG,RM_GPR|BITS32,0,0}, nasm_bytecodes+10219, IF_AVX|IF_SANDYBRIDGE},
    /* 2434 */ {I_VCVTSI2SS, 2, {XMMREG,RM_GPR|BITS32,0,0,0}, nasm_bytecodes+10226, IF_AVX|IF_SANDYBRIDGE},
    /* 2435 */ {I_VCVTSI2SS, 3, {XMMREG,XMMREG,RM_GPR|BITS64,0,0}, nasm_bytecodes+10233, IF_AVX|IF_SANDYBRIDGE|IF_LONG},
    /* 2436 */ {I_VCVTSI2SS, 2, {XMMREG,RM_GPR|BITS64,0,0,0}, nasm_bytecodes+10240, IF_AVX|IF_SANDYBRIDGE|IF_LONG},
    /* 2437 */ {I_VCVTSS2SD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+10247, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2438 */ {I_VCVTSS2SD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+10254, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2439 */ {I_VCVTSS2SI, 2, {REG32,RM_XMM,0,0,0}, nasm_bytecodes+10261, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2440 */ {I_VCVTSS2SI, 2, {REG64,RM_XMM,0,0,0}, nasm_bytecodes+10268, IF_AVX|IF_SANDYBRIDGE|IF_SD|IF_LONG},
    /* 2441 */ {I_VCVTTPD2DQ, 2, {XMMREG,XMMREG,0,0,0}, nasm_bytecodes+10275, IF_AVX|IF_SANDYBRIDGE},
    /* 2442 */ {I_VCVTTPD2DQ, 2, {XMMREG,MEMORY|BITS128,0,0,0}, nasm_bytecodes+10275, IF_AVX|IF_SANDYBRIDGE},
    /* 2443 */ {I_VCVTTPD2DQ, 2, {XMMREG,YMMREG,0,0,0}, nasm_bytecodes+10282, IF_AVX|IF_SANDYBRIDGE},
    /* 2444 */ {I_VCVTTPD2DQ, 2, {XMMREG,MEMORY|BITS256,0,0,0}, nasm_bytecodes+10282, IF_AVX|IF_SANDYBRIDGE},
    /* 2445 */ {I_VCVTTPS2DQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+10289, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2446 */ {I_VCVTTPS2DQ, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+10296, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2447 */ {I_VCVTTSD2SI, 2, {REG32,RM_XMM,0,0,0}, nasm_bytecodes+10303, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2448 */ {I_VCVTTSD2SI, 2, {REG64,RM_XMM,0,0,0}, nasm_bytecodes+10310, IF_AVX|IF_SANDYBRIDGE|IF_SQ|IF_LONG},
    /* 2449 */ {I_VCVTTSS2SI, 2, {REG32,RM_XMM,0,0,0}, nasm_bytecodes+10317, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2450 */ {I_VCVTTSS2SI, 2, {REG64,RM_XMM,0,0,0}, nasm_bytecodes+10324, IF_AVX|IF_SANDYBRIDGE|IF_SD|IF_LONG},
    /* 2451 */ {I_VDIVPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+10331, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2452 */ {I_VDIVPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+10338, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2453 */ {I_VDIVPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+10345, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2454 */ {I_VDIVPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+10352, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2455 */ {I_VDIVPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+10359, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2456 */ {I_VDIVPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+10366, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2457 */ {I_VDIVPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+10373, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2458 */ {I_VDIVPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+10380, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2459 */ {I_VDIVSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+10387, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2460 */ {I_VDIVSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+10394, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2461 */ {I_VDIVSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+10401, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2462 */ {I_VDIVSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+10408, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2463 */ {I_VDPPD, 4, {XMMREG,XMMREG,RM_XMM,IMMEDIATE,0}, nasm_bytecodes+6598, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2464 */ {I_VDPPD, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6606, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2465 */ {I_VDPPS, 4, {XMMREG,XMMREG,RM_XMM,IMMEDIATE,0}, nasm_bytecodes+6614, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2466 */ {I_VDPPS, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6622, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2467 */ {I_VDPPS, 4, {YMMREG,YMMREG,RM_YMM,IMMEDIATE,0}, nasm_bytecodes+6630, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2468 */ {I_VDPPS, 3, {YMMREG,RM_YMM,IMMEDIATE,0,0}, nasm_bytecodes+6638, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2469 */ {I_VEXTRACTF128, 3, {RM_XMM,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+6646, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2470 */ {I_VEXTRACTPS, 3, {RM_GPR|BITS32,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+6654, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2471 */ {I_VHADDPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+10415, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2472 */ {I_VHADDPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+10422, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2473 */ {I_VHADDPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+10429, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2474 */ {I_VHADDPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+10436, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2475 */ {I_VHADDPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+10443, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2476 */ {I_VHADDPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+10450, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2477 */ {I_VHADDPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+10457, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2478 */ {I_VHADDPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+10464, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2479 */ {I_VHSUBPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+10471, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2480 */ {I_VHSUBPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+10478, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2481 */ {I_VHSUBPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+10485, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2482 */ {I_VHSUBPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+10492, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2483 */ {I_VHSUBPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+10499, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2484 */ {I_VHSUBPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+10506, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2485 */ {I_VHSUBPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+10513, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2486 */ {I_VHSUBPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+10520, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2487 */ {I_VINSERTF128, 4, {YMMREG,YMMREG,RM_XMM,IMMEDIATE,0}, nasm_bytecodes+6662, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2488 */ {I_VINSERTPS, 4, {XMMREG,XMMREG,RM_XMM,IMMEDIATE,0}, nasm_bytecodes+6670, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2489 */ {I_VINSERTPS, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6678, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2490 */ {I_VLDDQU, 2, {XMMREG,MEMORY,0,0,0}, nasm_bytecodes+10527, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2491 */ {I_VLDQQU, 2, {YMMREG,MEMORY,0,0,0}, nasm_bytecodes+10534, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2492 */ {I_VLDDQU, 2, {YMMREG,MEMORY,0,0,0}, nasm_bytecodes+10534, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2493 */ {I_VLDMXCSR, 1, {MEMORY|BITS32,0,0,0,0}, nasm_bytecodes+10541, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2494 */ {I_VMASKMOVDQU, 2, {XMMREG,XMMREG,0,0,0}, nasm_bytecodes+10548, IF_AVX|IF_SANDYBRIDGE},
    /* 2495 */ {I_VMASKMOVPS, 3, {XMMREG,XMMREG,MEMORY,0,0}, nasm_bytecodes+10555, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2496 */ {I_VMASKMOVPS, 3, {YMMREG,YMMREG,MEMORY,0,0}, nasm_bytecodes+10562, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2497 */ {I_VMASKMOVPS, 3, {MEMORY,XMMREG,XMMREG,0,0}, nasm_bytecodes+10569, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2498 */ {I_VMASKMOVPS, 3, {MEMORY,XMMREG,XMMREG,0,0}, nasm_bytecodes+10576, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2499 */ {I_VMASKMOVPD, 3, {XMMREG,XMMREG,MEMORY,0,0}, nasm_bytecodes+10583, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2500 */ {I_VMASKMOVPD, 3, {YMMREG,YMMREG,MEMORY,0,0}, nasm_bytecodes+10590, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2501 */ {I_VMASKMOVPD, 3, {MEMORY,XMMREG,XMMREG,0,0}, nasm_bytecodes+10597, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2502 */ {I_VMASKMOVPD, 3, {MEMORY,YMMREG,YMMREG,0,0}, nasm_bytecodes+10604, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2503 */ {I_VMAXPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+10611, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2504 */ {I_VMAXPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+10618, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2505 */ {I_VMAXPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+10625, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2506 */ {I_VMAXPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+10632, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2507 */ {I_VMAXPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+10639, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2508 */ {I_VMAXPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+10646, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2509 */ {I_VMAXPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+10653, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2510 */ {I_VMAXPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+10660, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2511 */ {I_VMAXSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+10667, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2512 */ {I_VMAXSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+10674, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2513 */ {I_VMAXSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+10681, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2514 */ {I_VMAXSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+10688, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2515 */ {I_VMINPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+10695, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2516 */ {I_VMINPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+10702, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2517 */ {I_VMINPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+10709, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2518 */ {I_VMINPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+10716, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2519 */ {I_VMINPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+10723, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2520 */ {I_VMINPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+10730, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2521 */ {I_VMINPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+10737, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2522 */ {I_VMINPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+10744, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2523 */ {I_VMINSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+10751, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2524 */ {I_VMINSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+10758, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2525 */ {I_VMINSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+10765, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2526 */ {I_VMINSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+10772, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2527 */ {I_VMOVAPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+10779, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2528 */ {I_VMOVAPD, 2, {RM_XMM,XMMREG,0,0,0}, nasm_bytecodes+10786, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2529 */ {I_VMOVAPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+10793, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2530 */ {I_VMOVAPD, 2, {RM_YMM,YMMREG,0,0,0}, nasm_bytecodes+10800, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2531 */ {I_VMOVAPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+10807, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2532 */ {I_VMOVAPS, 2, {RM_XMM,XMMREG,0,0,0}, nasm_bytecodes+10814, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2533 */ {I_VMOVAPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+10821, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2534 */ {I_VMOVAPS, 2, {RM_YMM,YMMREG,0,0,0}, nasm_bytecodes+10828, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2535 */ {I_VMOVQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+10835, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2536 */ {I_VMOVQ, 2, {RM_XMM,XMMREG,0,0,0}, nasm_bytecodes+10842, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2537 */ {I_VMOVD, 2, {XMMREG,RM_GPR|BITS32,0,0,0}, nasm_bytecodes+10849, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2538 */ {I_VMOVQ, 2, {XMMREG,RM_GPR|BITS64,0,0,0}, nasm_bytecodes+10856, IF_AVX|IF_SANDYBRIDGE|IF_SQ|IF_LONG},
    /* 2539 */ {I_VMOVD, 2, {RM_GPR|BITS32,XMMREG,0,0,0}, nasm_bytecodes+10863, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2540 */ {I_VMOVQ, 2, {RM_GPR|BITS64,XMMREG,0,0,0}, nasm_bytecodes+10870, IF_AVX|IF_SANDYBRIDGE|IF_SQ|IF_LONG},
    /* 2541 */ {I_VMOVDDUP, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+10877, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2542 */ {I_VMOVDDUP, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+10884, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2543 */ {I_VMOVDQA, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+10891, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2544 */ {I_VMOVDQA, 2, {RM_XMM,XMMREG,0,0,0}, nasm_bytecodes+10898, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2545 */ {I_VMOVQQA, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+10905, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2546 */ {I_VMOVQQA, 2, {RM_YMM,YMMREG,0,0,0}, nasm_bytecodes+10912, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2547 */ {I_VMOVDQA, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+10905, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2548 */ {I_VMOVDQA, 2, {RM_YMM,YMMREG,0,0,0}, nasm_bytecodes+10912, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2549 */ {I_VMOVDQU, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+10919, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2550 */ {I_VMOVDQU, 2, {RM_XMM,XMMREG,0,0,0}, nasm_bytecodes+10926, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2551 */ {I_VMOVQQU, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+10933, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2552 */ {I_VMOVQQU, 2, {RM_YMM,YMMREG,0,0,0}, nasm_bytecodes+10940, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2553 */ {I_VMOVDQU, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+10933, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2554 */ {I_VMOVDQU, 2, {RM_YMM,YMMREG,0,0,0}, nasm_bytecodes+10940, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2555 */ {I_VMOVHLPS, 3, {XMMREG,XMMREG,XMMREG,0,0}, nasm_bytecodes+10947, IF_AVX|IF_SANDYBRIDGE},
    /* 2556 */ {I_VMOVHLPS, 2, {XMMREG,XMMREG,0,0,0}, nasm_bytecodes+10954, IF_AVX|IF_SANDYBRIDGE},
    /* 2557 */ {I_VMOVHPD, 3, {XMMREG,XMMREG,MEMORY,0,0}, nasm_bytecodes+10961, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2558 */ {I_VMOVHPD, 2, {XMMREG,MEMORY,0,0,0}, nasm_bytecodes+10968, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2559 */ {I_VMOVHPD, 2, {MEMORY,XMMREG,0,0,0}, nasm_bytecodes+10975, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2560 */ {I_VMOVHPS, 3, {XMMREG,XMMREG,MEMORY,0,0}, nasm_bytecodes+10982, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2561 */ {I_VMOVHPS, 2, {XMMREG,MEMORY,0,0,0}, nasm_bytecodes+10989, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2562 */ {I_VMOVHPS, 2, {MEMORY,XMMREG,0,0,0}, nasm_bytecodes+10996, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2563 */ {I_VMOVLHPS, 3, {XMMREG,XMMREG,XMMREG,0,0}, nasm_bytecodes+10982, IF_AVX|IF_SANDYBRIDGE},
    /* 2564 */ {I_VMOVLHPS, 2, {XMMREG,XMMREG,0,0,0}, nasm_bytecodes+10989, IF_AVX|IF_SANDYBRIDGE},
    /* 2565 */ {I_VMOVLPD, 3, {XMMREG,XMMREG,MEMORY,0,0}, nasm_bytecodes+11003, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2566 */ {I_VMOVLPD, 2, {XMMREG,MEMORY,0,0,0}, nasm_bytecodes+11010, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2567 */ {I_VMOVLPD, 2, {MEMORY,XMMREG,0,0,0}, nasm_bytecodes+11017, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2568 */ {I_VMOVLPS, 3, {XMMREG,XMMREG,MEMORY,0,0}, nasm_bytecodes+10947, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2569 */ {I_VMOVLPS, 2, {XMMREG,MEMORY,0,0,0}, nasm_bytecodes+10954, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2570 */ {I_VMOVLPS, 2, {MEMORY,XMMREG,0,0,0}, nasm_bytecodes+11024, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2571 */ {I_VMOVMSKPD, 2, {REG64,XMMREG,0,0,0}, nasm_bytecodes+11031, IF_AVX|IF_SANDYBRIDGE|IF_LONG},
    /* 2572 */ {I_VMOVMSKPD, 2, {REG32,XMMREG,0,0,0}, nasm_bytecodes+11031, IF_AVX|IF_SANDYBRIDGE},
    /* 2573 */ {I_VMOVMSKPD, 2, {REG64,YMMREG,0,0,0}, nasm_bytecodes+11038, IF_AVX|IF_SANDYBRIDGE|IF_LONG},
    /* 2574 */ {I_VMOVMSKPD, 2, {REG32,YMMREG,0,0,0}, nasm_bytecodes+11038, IF_AVX|IF_SANDYBRIDGE},
    /* 2575 */ {I_VMOVMSKPS, 2, {REG64,XMMREG,0,0,0}, nasm_bytecodes+11045, IF_AVX|IF_SANDYBRIDGE|IF_LONG},
    /* 2576 */ {I_VMOVMSKPS, 2, {REG32,XMMREG,0,0,0}, nasm_bytecodes+11045, IF_AVX|IF_SANDYBRIDGE},
    /* 2577 */ {I_VMOVMSKPS, 2, {REG64,YMMREG,0,0,0}, nasm_bytecodes+11052, IF_AVX|IF_SANDYBRIDGE|IF_LONG},
    /* 2578 */ {I_VMOVMSKPS, 2, {REG32,YMMREG,0,0,0}, nasm_bytecodes+11052, IF_AVX|IF_SANDYBRIDGE},
    /* 2579 */ {I_VMOVNTDQ, 2, {MEMORY,XMMREG,0,0,0}, nasm_bytecodes+11059, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2580 */ {I_VMOVNTQQ, 2, {MEMORY,YMMREG,0,0,0}, nasm_bytecodes+11066, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2581 */ {I_VMOVNTDQ, 2, {MEMORY,YMMREG,0,0,0}, nasm_bytecodes+11066, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2582 */ {I_VMOVNTDQA, 2, {XMMREG,MEMORY,0,0,0}, nasm_bytecodes+11073, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2583 */ {I_VMOVNTPD, 2, {MEMORY,XMMREG,0,0,0}, nasm_bytecodes+11080, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2584 */ {I_VMOVNTPD, 2, {MEMORY,YMMREG,0,0,0}, nasm_bytecodes+11087, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2585 */ {I_VMOVNTPS, 2, {MEMORY,XMMREG,0,0,0}, nasm_bytecodes+11094, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2586 */ {I_VMOVNTPS, 2, {MEMORY,YMMREG,0,0,0}, nasm_bytecodes+11101, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2587 */ {I_VMOVSD, 3, {XMMREG,XMMREG,XMMREG,0,0}, nasm_bytecodes+11108, IF_AVX|IF_SANDYBRIDGE},
    /* 2588 */ {I_VMOVSD, 2, {XMMREG,XMMREG,0,0,0}, nasm_bytecodes+11115, IF_AVX|IF_SANDYBRIDGE},
    /* 2589 */ {I_VMOVSD, 2, {XMMREG,MEMORY,0,0,0}, nasm_bytecodes+11122, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2590 */ {I_VMOVSD, 3, {XMMREG,XMMREG,XMMREG,0,0}, nasm_bytecodes+11129, IF_AVX|IF_SANDYBRIDGE},
    /* 2591 */ {I_VMOVSD, 2, {XMMREG,XMMREG,0,0,0}, nasm_bytecodes+11136, IF_AVX|IF_SANDYBRIDGE},
    /* 2592 */ {I_VMOVSD, 2, {MEMORY,XMMREG,0,0,0}, nasm_bytecodes+11143, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2593 */ {I_VMOVSHDUP, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11150, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2594 */ {I_VMOVSHDUP, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+11157, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2595 */ {I_VMOVSLDUP, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11164, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2596 */ {I_VMOVSLDUP, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+11171, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2597 */ {I_VMOVSS, 3, {XMMREG,XMMREG,XMMREG,0,0}, nasm_bytecodes+11178, IF_AVX|IF_SANDYBRIDGE},
    /* 2598 */ {I_VMOVSS, 2, {XMMREG,XMMREG,0,0,0}, nasm_bytecodes+11185, IF_AVX|IF_SANDYBRIDGE},
    /* 2599 */ {I_VMOVSS, 2, {XMMREG,MEMORY,0,0,0}, nasm_bytecodes+11192, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2600 */ {I_VMOVSS, 3, {XMMREG,XMMREG,XMMREG,0,0}, nasm_bytecodes+11199, IF_AVX|IF_SANDYBRIDGE},
    /* 2601 */ {I_VMOVSS, 2, {XMMREG,XMMREG,0,0,0}, nasm_bytecodes+11206, IF_AVX|IF_SANDYBRIDGE},
    /* 2602 */ {I_VMOVSS, 2, {MEMORY,XMMREG,0,0,0}, nasm_bytecodes+11213, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2603 */ {I_VMOVUPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11220, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2604 */ {I_VMOVUPD, 2, {RM_XMM,XMMREG,0,0,0}, nasm_bytecodes+11227, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2605 */ {I_VMOVUPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+11234, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2606 */ {I_VMOVUPD, 2, {RM_YMM,YMMREG,0,0,0}, nasm_bytecodes+11241, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2607 */ {I_VMOVUPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11248, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2608 */ {I_VMOVUPS, 2, {RM_XMM,XMMREG,0,0,0}, nasm_bytecodes+11255, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2609 */ {I_VMOVUPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+11262, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2610 */ {I_VMOVUPS, 2, {RM_YMM,YMMREG,0,0,0}, nasm_bytecodes+11269, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2611 */ {I_VMPSADBW, 4, {XMMREG,XMMREG,RM_XMM,IMMEDIATE,0}, nasm_bytecodes+6686, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2612 */ {I_VMPSADBW, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6694, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2613 */ {I_VMULPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11276, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2614 */ {I_VMULPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11283, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2615 */ {I_VMULPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+11290, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2616 */ {I_VMULPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+11297, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2617 */ {I_VMULPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11304, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2618 */ {I_VMULPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11311, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2619 */ {I_VMULPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+11318, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2620 */ {I_VMULPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+11325, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2621 */ {I_VMULSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11332, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2622 */ {I_VMULSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11339, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2623 */ {I_VMULSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11346, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2624 */ {I_VMULSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11353, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2625 */ {I_VORPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11360, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2626 */ {I_VORPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11367, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2627 */ {I_VORPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+11374, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2628 */ {I_VORPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+11381, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2629 */ {I_VORPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11388, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2630 */ {I_VORPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11395, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2631 */ {I_VORPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+11402, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2632 */ {I_VORPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+11409, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2633 */ {I_VPABSB, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11416, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2634 */ {I_VPABSW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11423, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2635 */ {I_VPABSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11430, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2636 */ {I_VPACKSSWB, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11437, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2637 */ {I_VPACKSSWB, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11444, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2638 */ {I_VPACKSSDW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11451, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2639 */ {I_VPACKSSDW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11458, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2640 */ {I_VPACKUSWB, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11465, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2641 */ {I_VPACKUSWB, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11472, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2642 */ {I_VPACKUSDW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11479, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2643 */ {I_VPACKUSDW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11486, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2644 */ {I_VPADDB, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11493, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2645 */ {I_VPADDB, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11500, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2646 */ {I_VPADDW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11507, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2647 */ {I_VPADDW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11514, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2648 */ {I_VPADDD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11521, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2649 */ {I_VPADDD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11528, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2650 */ {I_VPADDQ, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11535, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2651 */ {I_VPADDQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11542, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2652 */ {I_VPADDSB, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11549, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2653 */ {I_VPADDSB, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11556, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2654 */ {I_VPADDSW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11563, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2655 */ {I_VPADDSW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11570, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2656 */ {I_VPADDUSB, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11577, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2657 */ {I_VPADDUSB, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11584, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2658 */ {I_VPADDUSW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11591, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2659 */ {I_VPADDUSW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11598, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2660 */ {I_VPALIGNR, 4, {XMMREG,XMMREG,RM_XMM,IMMEDIATE,0}, nasm_bytecodes+6702, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2661 */ {I_VPALIGNR, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6710, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2662 */ {I_VPAND, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11605, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2663 */ {I_VPAND, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11612, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2664 */ {I_VPANDN, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11619, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2665 */ {I_VPANDN, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11626, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2666 */ {I_VPAVGB, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11633, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2667 */ {I_VPAVGB, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11640, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2668 */ {I_VPAVGW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11647, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2669 */ {I_VPAVGW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11654, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2670 */ {I_VPBLENDVB, 4, {XMMREG,XMMREG,RM_XMM,XMMREG,0}, nasm_bytecodes+4680, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2671 */ {I_VPBLENDVB, 3, {XMMREG,RM_XMM,XMMREG,0,0}, nasm_bytecodes+4689, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2672 */ {I_VPBLENDW, 4, {XMMREG,XMMREG,RM_XMM,IMMEDIATE,0}, nasm_bytecodes+6718, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2673 */ {I_VPBLENDW, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6726, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2674 */ {I_VPCMPESTRI, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6734, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2675 */ {I_VPCMPESTRM, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6742, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2676 */ {I_VPCMPISTRI, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6750, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2677 */ {I_VPCMPISTRM, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6758, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2678 */ {I_VPCMPEQB, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11661, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2679 */ {I_VPCMPEQB, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11668, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2680 */ {I_VPCMPEQW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11675, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2681 */ {I_VPCMPEQW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11682, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2682 */ {I_VPCMPEQD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11689, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2683 */ {I_VPCMPEQD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11696, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2684 */ {I_VPCMPEQQ, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11703, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2685 */ {I_VPCMPEQQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11710, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2686 */ {I_VPCMPGTB, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11717, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2687 */ {I_VPCMPGTB, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11724, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2688 */ {I_VPCMPGTW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11731, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2689 */ {I_VPCMPGTW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11738, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2690 */ {I_VPCMPGTD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11745, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2691 */ {I_VPCMPGTD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11752, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2692 */ {I_VPCMPGTQ, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11759, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2693 */ {I_VPCMPGTQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11766, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2694 */ {I_VPERMILPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11773, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2695 */ {I_VPERMILPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+11780, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2696 */ {I_VPERMILPD, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6766, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2697 */ {I_VPERMILPD, 3, {YMMREG,RM_YMM,IMMEDIATE,0,0}, nasm_bytecodes+6774, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2698 */ {I_VPERMILTD2PD, 4, {XMMREG,XMMREG,RM_XMM,XMMREG,0}, nasm_bytecodes+4698, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2699 */ {I_VPERMILTD2PD, 4, {XMMREG,XMMREG,XMMREG,RM_XMM,0}, nasm_bytecodes+4707, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2700 */ {I_VPERMILTD2PD, 4, {YMMREG,YMMREG,RM_YMM,YMMREG,0}, nasm_bytecodes+4716, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2701 */ {I_VPERMILTD2PD, 4, {YMMREG,YMMREG,YMMREG,RM_YMM,0}, nasm_bytecodes+4725, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2702 */ {I_VPERMILMO2PD, 4, {XMMREG,XMMREG,RM_XMM,XMMREG,0}, nasm_bytecodes+4734, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2703 */ {I_VPERMILMO2PD, 4, {XMMREG,XMMREG,XMMREG,RM_XMM,0}, nasm_bytecodes+4743, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2704 */ {I_VPERMILMO2PD, 4, {YMMREG,YMMREG,RM_YMM,YMMREG,0}, nasm_bytecodes+4752, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2705 */ {I_VPERMILMO2PD, 4, {YMMREG,YMMREG,YMMREG,RM_YMM,0}, nasm_bytecodes+4761, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2706 */ {I_VPERMILMZ2PD, 4, {XMMREG,XMMREG,RM_XMM,XMMREG,0}, nasm_bytecodes+4770, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2707 */ {I_VPERMILMZ2PD, 4, {XMMREG,XMMREG,XMMREG,RM_XMM,0}, nasm_bytecodes+4779, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2708 */ {I_VPERMILMZ2PD, 4, {YMMREG,YMMREG,RM_YMM,YMMREG,0}, nasm_bytecodes+4788, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2709 */ {I_VPERMILMZ2PD, 4, {YMMREG,YMMREG,YMMREG,RM_YMM,0}, nasm_bytecodes+4797, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2710 */ {I_VPERMIL2PD, 5, {XMMREG,XMMREG,RM_XMM,XMMREG,IMMEDIATE}, nasm_bytecodes+4806, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2711 */ {I_VPERMIL2PD, 5, {XMMREG,XMMREG,XMMREG,RM_XMM,IMMEDIATE}, nasm_bytecodes+4815, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2712 */ {I_VPERMIL2PD, 5, {YMMREG,YMMREG,RM_YMM,YMMREG,IMMEDIATE}, nasm_bytecodes+4824, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2713 */ {I_VPERMIL2PD, 5, {YMMREG,YMMREG,YMMREG,RM_YMM,IMMEDIATE}, nasm_bytecodes+4833, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2714 */ {I_VPERMILPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11787, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2715 */ {I_VPERMILPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+11794, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2716 */ {I_VPERMILPS, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6782, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2717 */ {I_VPERMILPS, 3, {YMMREG,RM_YMM,IMMEDIATE,0,0}, nasm_bytecodes+6790, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2718 */ {I_VPERMILTD2PS, 4, {XMMREG,XMMREG,RM_XMM,XMMREG,0}, nasm_bytecodes+4842, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2719 */ {I_VPERMILTD2PS, 4, {XMMREG,XMMREG,XMMREG,RM_XMM,0}, nasm_bytecodes+4851, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2720 */ {I_VPERMILTD2PS, 4, {YMMREG,YMMREG,RM_YMM,YMMREG,0}, nasm_bytecodes+4860, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2721 */ {I_VPERMILTD2PS, 4, {YMMREG,YMMREG,YMMREG,RM_YMM,0}, nasm_bytecodes+4869, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2722 */ {I_VPERMILMO2PS, 4, {XMMREG,XMMREG,RM_XMM,XMMREG,0}, nasm_bytecodes+4878, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2723 */ {I_VPERMILMO2PS, 4, {XMMREG,XMMREG,XMMREG,RM_XMM,0}, nasm_bytecodes+4887, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2724 */ {I_VPERMILMO2PS, 4, {YMMREG,YMMREG,RM_YMM,YMMREG,0}, nasm_bytecodes+4896, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2725 */ {I_VPERMILMO2PS, 4, {YMMREG,YMMREG,YMMREG,RM_YMM,0}, nasm_bytecodes+4905, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2726 */ {I_VPERMILMZ2PS, 4, {XMMREG,XMMREG,RM_XMM,XMMREG,0}, nasm_bytecodes+4914, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2727 */ {I_VPERMILMZ2PS, 4, {XMMREG,XMMREG,XMMREG,RM_XMM,0}, nasm_bytecodes+4923, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2728 */ {I_VPERMILMZ2PS, 4, {YMMREG,YMMREG,RM_YMM,YMMREG,0}, nasm_bytecodes+4932, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2729 */ {I_VPERMILMZ2PS, 4, {YMMREG,YMMREG,YMMREG,RM_YMM,0}, nasm_bytecodes+4941, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2730 */ {I_VPERMIL2PS, 5, {XMMREG,XMMREG,RM_XMM,XMMREG,IMMEDIATE}, nasm_bytecodes+4950, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2731 */ {I_VPERMIL2PS, 5, {XMMREG,XMMREG,XMMREG,RM_XMM,IMMEDIATE}, nasm_bytecodes+4959, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2732 */ {I_VPERMIL2PS, 5, {YMMREG,YMMREG,RM_YMM,YMMREG,IMMEDIATE}, nasm_bytecodes+4968, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2733 */ {I_VPERMIL2PS, 5, {YMMREG,YMMREG,YMMREG,RM_YMM,IMMEDIATE}, nasm_bytecodes+4977, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2734 */ {I_VPERM2F128, 4, {YMMREG,YMMREG,RM_YMM,IMMEDIATE,0}, nasm_bytecodes+6798, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2735 */ {I_VPEXTRB, 3, {REG64,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+6806, IF_AVX|IF_SANDYBRIDGE|IF_LONG},
    /* 2736 */ {I_VPEXTRB, 3, {REG32,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+6806, IF_AVX|IF_SANDYBRIDGE},
    /* 2737 */ {I_VPEXTRB, 3, {MEMORY,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+6806, IF_AVX|IF_SANDYBRIDGE|IF_SB},
    /* 2738 */ {I_VPEXTRW, 3, {REG64,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+6814, IF_AVX|IF_SANDYBRIDGE|IF_LONG},
    /* 2739 */ {I_VPEXTRW, 3, {REG32,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+6814, IF_AVX|IF_SANDYBRIDGE},
    /* 2740 */ {I_VPEXTRW, 3, {MEMORY,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+6814, IF_AVX|IF_SANDYBRIDGE|IF_SW},
    /* 2741 */ {I_VPEXTRW, 3, {REG64,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+6822, IF_AVX|IF_SANDYBRIDGE|IF_LONG},
    /* 2742 */ {I_VPEXTRW, 3, {REG32,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+6822, IF_AVX|IF_SANDYBRIDGE},
    /* 2743 */ {I_VPEXTRW, 3, {MEMORY,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+6822, IF_AVX|IF_SANDYBRIDGE|IF_SW},
    /* 2744 */ {I_VPEXTRD, 3, {REG64,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+6830, IF_AVX|IF_SANDYBRIDGE|IF_LONG},
    /* 2745 */ {I_VPEXTRD, 3, {RM_GPR|BITS32,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+6830, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2746 */ {I_VPEXTRQ, 3, {RM_GPR|BITS64,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+6838, IF_AVX|IF_SANDYBRIDGE|IF_SQ|IF_LONG},
    /* 2747 */ {I_VPHADDW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11801, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2748 */ {I_VPHADDW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11808, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2749 */ {I_VPHADDD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11815, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2750 */ {I_VPHADDD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11822, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2751 */ {I_VPHADDSW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11829, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2752 */ {I_VPHADDSW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11836, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2753 */ {I_VPHMINPOSUW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11843, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2754 */ {I_VPHSUBW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11850, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2755 */ {I_VPHSUBW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11857, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2756 */ {I_VPHSUBD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11864, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2757 */ {I_VPHSUBD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11871, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2758 */ {I_VPHSUBSW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11878, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2759 */ {I_VPHSUBSW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11885, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2760 */ {I_VPINSRB, 4, {XMMREG,XMMREG,REG32,IMMEDIATE,0}, nasm_bytecodes+6846, IF_AVX|IF_SANDYBRIDGE},
    /* 2761 */ {I_VPINSRB, 3, {XMMREG,REG32,IMMEDIATE,0,0}, nasm_bytecodes+6854, IF_AVX|IF_SANDYBRIDGE},
    /* 2762 */ {I_VPINSRB, 4, {XMMREG,XMMREG,MEMORY,IMMEDIATE,0}, nasm_bytecodes+6846, IF_AVX|IF_SANDYBRIDGE|IF_SB},
    /* 2763 */ {I_VPINSRB, 4, {XMMREG,REG32,MEMORY,IMMEDIATE,0}, nasm_bytecodes+6854, IF_AVX|IF_SANDYBRIDGE|IF_SB},
    /* 2764 */ {I_VPINSRW, 4, {XMMREG,XMMREG,REG32,IMMEDIATE,0}, nasm_bytecodes+6862, IF_AVX|IF_SANDYBRIDGE},
    /* 2765 */ {I_VPINSRW, 3, {XMMREG,REG32,IMMEDIATE,0,0}, nasm_bytecodes+6870, IF_AVX|IF_SANDYBRIDGE},
    /* 2766 */ {I_VPINSRW, 4, {XMMREG,XMMREG,MEMORY,IMMEDIATE,0}, nasm_bytecodes+6862, IF_AVX|IF_SANDYBRIDGE|IF_SW},
    /* 2767 */ {I_VPINSRW, 4, {XMMREG,REG32,MEMORY,IMMEDIATE,0}, nasm_bytecodes+6870, IF_AVX|IF_SANDYBRIDGE|IF_SW},
    /* 2768 */ {I_VPINSRD, 4, {XMMREG,XMMREG,RM_GPR|BITS32,IMMEDIATE,0}, nasm_bytecodes+6878, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2769 */ {I_VPINSRD, 3, {XMMREG,RM_GPR|BITS32,IMMEDIATE,0,0}, nasm_bytecodes+6886, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2770 */ {I_VPINSRQ, 4, {XMMREG,XMMREG,RM_GPR|BITS64,IMMEDIATE,0}, nasm_bytecodes+6894, IF_AVX|IF_SANDYBRIDGE|IF_SQ|IF_LONG},
    /* 2771 */ {I_VPINSRQ, 3, {XMMREG,RM_GPR|BITS64,IMMEDIATE,0,0}, nasm_bytecodes+6902, IF_AVX|IF_SANDYBRIDGE|IF_SD|IF_LONG},
    /* 2772 */ {I_VPMADDWD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11892, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2773 */ {I_VPMADDWD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11899, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2774 */ {I_VPMADDUBSW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11906, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2775 */ {I_VPMADDUBSW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11913, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2776 */ {I_VPMAXSB, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11920, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2777 */ {I_VPMAXSB, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11927, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2778 */ {I_VPMAXSW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11934, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2779 */ {I_VPMAXSW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11941, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2780 */ {I_VPMAXSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11948, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2781 */ {I_VPMAXSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11955, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2782 */ {I_VPMAXUB, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11962, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2783 */ {I_VPMAXUB, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11969, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2784 */ {I_VPMAXUW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11976, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2785 */ {I_VPMAXUW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11983, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2786 */ {I_VPMAXUD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11990, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2787 */ {I_VPMAXUD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11997, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2788 */ {I_VPMINSB, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12004, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2789 */ {I_VPMINSB, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12011, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2790 */ {I_VPMINSW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12018, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2791 */ {I_VPMINSW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12025, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2792 */ {I_VPMINSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12032, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2793 */ {I_VPMINSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12039, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2794 */ {I_VPMINUB, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12046, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2795 */ {I_VPMINUB, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12053, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2796 */ {I_VPMINUW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12060, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2797 */ {I_VPMINUW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12067, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2798 */ {I_VPMINUD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12074, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2799 */ {I_VPMINUD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12081, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2800 */ {I_VPMOVMSKB, 2, {REG64,XMMREG,0,0,0}, nasm_bytecodes+12088, IF_AVX|IF_SANDYBRIDGE|IF_LONG},
    /* 2801 */ {I_VPMOVMSKB, 2, {REG32,XMMREG,0,0,0}, nasm_bytecodes+12088, IF_AVX|IF_SANDYBRIDGE},
    /* 2802 */ {I_VPMOVSXBW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12095, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2803 */ {I_VPMOVSXBD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12102, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2804 */ {I_VPMOVSXBQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12109, IF_AVX|IF_SANDYBRIDGE|IF_SW},
    /* 2805 */ {I_VPMOVSXWD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12116, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2806 */ {I_VPMOVSXWQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12123, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2807 */ {I_VPMOVSXDQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12130, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2808 */ {I_VPMOVZXBW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12137, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2809 */ {I_VPMOVZXBD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12144, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2810 */ {I_VPMOVZXBQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12151, IF_AVX|IF_SANDYBRIDGE|IF_SW},
    /* 2811 */ {I_VPMOVZXWD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12158, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2812 */ {I_VPMOVZXWQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12165, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2813 */ {I_VPMOVZXDQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12172, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2814 */ {I_VPMULHUW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12179, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2815 */ {I_VPMULHUW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12186, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2816 */ {I_VPMULHRSW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12193, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2817 */ {I_VPMULHRSW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12200, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2818 */ {I_VPMULHW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12207, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2819 */ {I_VPMULHW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12214, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2820 */ {I_VPMULLW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12221, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2821 */ {I_VPMULLW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12228, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2822 */ {I_VPMULLD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12235, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2823 */ {I_VPMULLD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12242, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2824 */ {I_VPMULUDQ, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12249, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2825 */ {I_VPMULUDQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12256, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2826 */ {I_VPMULDQ, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12263, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2827 */ {I_VPMULDQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12270, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2828 */ {I_VPOR, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12277, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2829 */ {I_VPOR, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12284, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2830 */ {I_VPSADBW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12291, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2831 */ {I_VPSADBW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12298, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2832 */ {I_VPSHUFB, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12305, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2833 */ {I_VPSHUFB, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12312, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2834 */ {I_VPSHUFD, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6910, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2835 */ {I_VPSHUFHW, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6918, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2836 */ {I_VPSHUFLW, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6926, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2837 */ {I_VPSIGNB, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12319, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2838 */ {I_VPSIGNB, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12326, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2839 */ {I_VPSIGNW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12333, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2840 */ {I_VPSIGNW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12340, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2841 */ {I_VPSIGND, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12347, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2842 */ {I_VPSIGND, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12354, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2843 */ {I_VPSLLDQ, 3, {XMMREG,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+6934, IF_AVX|IF_SANDYBRIDGE},
    /* 2844 */ {I_VPSLLDQ, 2, {XMMREG,IMMEDIATE,0,0,0}, nasm_bytecodes+6942, IF_AVX|IF_SANDYBRIDGE},
    /* 2845 */ {I_VPSRLDQ, 3, {XMMREG,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+6950, IF_AVX|IF_SANDYBRIDGE},
    /* 2846 */ {I_VPSRLDQ, 2, {XMMREG,IMMEDIATE,0,0,0}, nasm_bytecodes+6958, IF_AVX|IF_SANDYBRIDGE},
    /* 2847 */ {I_VPSLLW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12361, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2848 */ {I_VPSLLW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12368, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2849 */ {I_VPSLLW, 3, {XMMREG,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+6966, IF_AVX|IF_SANDYBRIDGE},
    /* 2850 */ {I_VPSLLW, 2, {XMMREG,IMMEDIATE,0,0,0}, nasm_bytecodes+6974, IF_AVX|IF_SANDYBRIDGE},
    /* 2851 */ {I_VPSLLD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12375, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2852 */ {I_VPSLLD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12382, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2853 */ {I_VPSLLD, 3, {XMMREG,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+6982, IF_AVX|IF_SANDYBRIDGE},
    /* 2854 */ {I_VPSLLD, 2, {XMMREG,IMMEDIATE,0,0,0}, nasm_bytecodes+6990, IF_AVX|IF_SANDYBRIDGE},
    /* 2855 */ {I_VPSLLQ, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12389, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2856 */ {I_VPSLLQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12396, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2857 */ {I_VPSLLQ, 3, {XMMREG,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+6998, IF_AVX|IF_SANDYBRIDGE},
    /* 2858 */ {I_VPSLLQ, 2, {XMMREG,IMMEDIATE,0,0,0}, nasm_bytecodes+7006, IF_AVX|IF_SANDYBRIDGE},
    /* 2859 */ {I_VPSRAW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12403, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2860 */ {I_VPSRAW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12410, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2861 */ {I_VPSRAW, 3, {XMMREG,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+7014, IF_AVX|IF_SANDYBRIDGE},
    /* 2862 */ {I_VPSRAW, 2, {XMMREG,IMMEDIATE,0,0,0}, nasm_bytecodes+7022, IF_AVX|IF_SANDYBRIDGE},
    /* 2863 */ {I_VPSRAD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12417, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2864 */ {I_VPSRAD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12424, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2865 */ {I_VPSRAD, 3, {XMMREG,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+7030, IF_AVX|IF_SANDYBRIDGE},
    /* 2866 */ {I_VPSRAD, 2, {XMMREG,IMMEDIATE,0,0,0}, nasm_bytecodes+7038, IF_AVX|IF_SANDYBRIDGE},
    /* 2867 */ {I_VPSRLW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12431, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2868 */ {I_VPSRLW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12438, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2869 */ {I_VPSRLW, 3, {XMMREG,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+7046, IF_AVX|IF_SANDYBRIDGE},
    /* 2870 */ {I_VPSRLW, 2, {XMMREG,IMMEDIATE,0,0,0}, nasm_bytecodes+7054, IF_AVX|IF_SANDYBRIDGE},
    /* 2871 */ {I_VPSRLD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12445, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2872 */ {I_VPSRLD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12452, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2873 */ {I_VPSRLD, 3, {XMMREG,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+7062, IF_AVX|IF_SANDYBRIDGE},
    /* 2874 */ {I_VPSRLD, 2, {XMMREG,IMMEDIATE,0,0,0}, nasm_bytecodes+7070, IF_AVX|IF_SANDYBRIDGE},
    /* 2875 */ {I_VPSRLQ, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12459, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2876 */ {I_VPSRLQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12466, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2877 */ {I_VPSRLQ, 3, {XMMREG,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+7078, IF_AVX|IF_SANDYBRIDGE},
    /* 2878 */ {I_VPSRLQ, 2, {XMMREG,IMMEDIATE,0,0,0}, nasm_bytecodes+7086, IF_AVX|IF_SANDYBRIDGE},
    /* 2879 */ {I_VPTEST, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12473, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2880 */ {I_VPTEST, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+12480, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2881 */ {I_VPSUBB, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12487, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2882 */ {I_VPSUBB, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12494, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2883 */ {I_VPSUBW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12501, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2884 */ {I_VPSUBW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12508, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2885 */ {I_VPSUBD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12515, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2886 */ {I_VPSUBD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12522, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2887 */ {I_VPSUBQ, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12529, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2888 */ {I_VPSUBQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12536, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2889 */ {I_VPSUBSB, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12543, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2890 */ {I_VPSUBSB, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12550, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2891 */ {I_VPSUBSW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12557, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2892 */ {I_VPSUBSW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12564, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2893 */ {I_VPSUBUSB, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12571, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2894 */ {I_VPSUBUSB, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12578, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2895 */ {I_VPSUBUSW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12585, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2896 */ {I_VPSUBUSW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12592, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2897 */ {I_VPUNPCKHBW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12599, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2898 */ {I_VPUNPCKHBW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12606, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2899 */ {I_VPUNPCKHWD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12613, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2900 */ {I_VPUNPCKHWD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12620, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2901 */ {I_VPUNPCKHDQ, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12627, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2902 */ {I_VPUNPCKHDQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12634, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2903 */ {I_VPUNPCKHQDQ, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12641, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2904 */ {I_VPUNPCKHQDQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12648, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2905 */ {I_VPUNPCKLBW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12655, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2906 */ {I_VPUNPCKLBW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12662, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2907 */ {I_VPUNPCKLWD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12669, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2908 */ {I_VPUNPCKLWD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12676, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2909 */ {I_VPUNPCKLDQ, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12683, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2910 */ {I_VPUNPCKLDQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12690, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2911 */ {I_VPUNPCKLQDQ, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12697, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2912 */ {I_VPUNPCKLQDQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12704, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2913 */ {I_VPXOR, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12711, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2914 */ {I_VPXOR, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12718, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2915 */ {I_VRCPPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12725, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2916 */ {I_VRCPPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+12732, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2917 */ {I_VRCPSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12739, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2918 */ {I_VRCPSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12746, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2919 */ {I_VRSQRTPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12753, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2920 */ {I_VRSQRTPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+12760, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2921 */ {I_VRSQRTSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12767, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2922 */ {I_VRSQRTSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12774, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2923 */ {I_VROUNDPD, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+7094, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2924 */ {I_VROUNDPD, 3, {YMMREG,RM_YMM,IMMEDIATE,0,0}, nasm_bytecodes+7102, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2925 */ {I_VROUNDPS, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+7110, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2926 */ {I_VROUNDPS, 3, {YMMREG,RM_YMM,IMMEDIATE,0,0}, nasm_bytecodes+7118, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2927 */ {I_VROUNDSD, 4, {XMMREG,XMMREG,RM_XMM,IMMEDIATE,0}, nasm_bytecodes+7126, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2928 */ {I_VROUNDSD, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+7134, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2929 */ {I_VROUNDSS, 4, {XMMREG,XMMREG,RM_XMM,IMMEDIATE,0}, nasm_bytecodes+7142, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2930 */ {I_VROUNDSS, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+7150, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2931 */ {I_VSHUFPD, 4, {XMMREG,XMMREG,RM_XMM,IMMEDIATE,0}, nasm_bytecodes+7158, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2932 */ {I_VSHUFPD, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+7166, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2933 */ {I_VSHUFPD, 4, {YMMREG,YMMREG,RM_YMM,IMMEDIATE,0}, nasm_bytecodes+7174, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2934 */ {I_VSHUFPD, 3, {YMMREG,RM_YMM,IMMEDIATE,0,0}, nasm_bytecodes+7182, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2935 */ {I_VSHUFPS, 4, {XMMREG,XMMREG,RM_XMM,IMMEDIATE,0}, nasm_bytecodes+7190, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2936 */ {I_VSHUFPS, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+7198, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2937 */ {I_VSHUFPS, 4, {YMMREG,YMMREG,RM_YMM,IMMEDIATE,0}, nasm_bytecodes+7206, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2938 */ {I_VSHUFPS, 3, {YMMREG,RM_YMM,IMMEDIATE,0,0}, nasm_bytecodes+7214, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2939 */ {I_VSQRTPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12781, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2940 */ {I_VSQRTPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+12788, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2941 */ {I_VSQRTPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12795, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2942 */ {I_VSQRTPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+12802, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2943 */ {I_VSQRTSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12809, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2944 */ {I_VSQRTSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12816, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2945 */ {I_VSQRTSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12823, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2946 */ {I_VSQRTSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12830, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2947 */ {I_VSTMXCSR, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+12837, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2948 */ {I_VSUBPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12844, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2949 */ {I_VSUBPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12851, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2950 */ {I_VSUBPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+12858, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2951 */ {I_VSUBPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+12865, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2952 */ {I_VSUBPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12872, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2953 */ {I_VSUBPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12879, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2954 */ {I_VSUBPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+12886, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2955 */ {I_VSUBPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+12893, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2956 */ {I_VSUBSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12900, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2957 */ {I_VSUBSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12907, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2958 */ {I_VSUBSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12914, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2959 */ {I_VSUBSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12921, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2960 */ {I_VTESTPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12928, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2961 */ {I_VTESTPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+12935, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2962 */ {I_VTESTPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12942, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2963 */ {I_VTESTPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+12949, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2964 */ {I_VUCOMISD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12956, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    /* 2965 */ {I_VUCOMISS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12963, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    /* 2966 */ {I_VUNPCKHPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12970, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2967 */ {I_VUNPCKHPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12977, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2968 */ {I_VUNPCKHPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+12984, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2969 */ {I_VUNPCKHPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+12991, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2970 */ {I_VUNPCKHPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12998, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2971 */ {I_VUNPCKHPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+13005, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2972 */ {I_VUNPCKHPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+13012, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2973 */ {I_VUNPCKHPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+13019, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2974 */ {I_VUNPCKLPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+13026, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2975 */ {I_VUNPCKLPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+13033, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2976 */ {I_VUNPCKLPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+13040, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2977 */ {I_VUNPCKLPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+13047, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2978 */ {I_VUNPCKLPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+13054, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2979 */ {I_VUNPCKLPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+13061, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2980 */ {I_VUNPCKLPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+13068, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2981 */ {I_VUNPCKLPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+13075, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2982 */ {I_VXORPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+13082, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2983 */ {I_VXORPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+13089, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2984 */ {I_VXORPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+13096, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2985 */ {I_VXORPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+13103, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2986 */ {I_VXORPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+13110, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2987 */ {I_VXORPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+13117, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    /* 2988 */ {I_VXORPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+13124, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2989 */ {I_VXORPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+13131, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    /* 2990 */ {I_VZEROALL, 0, {0,0,0,0,0}, nasm_bytecodes+15478, IF_AVX|IF_SANDYBRIDGE},
    /* 2991 */ {I_VZEROUPPER, 0, {0,0,0,0,0}, nasm_bytecodes+15484, IF_AVX|IF_SANDYBRIDGE},
    /* 2992 */ {I_PCLMULLQLQDQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4986, IF_SSE|IF_SANDYBRIDGE|IF_SO},
    /* 2993 */ {I_PCLMULHQLQDQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4995, IF_SSE|IF_SANDYBRIDGE|IF_SO},
    /* 2994 */ {I_PCLMULLQHQDQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+5004, IF_SSE|IF_SANDYBRIDGE|IF_SO},
    /* 2995 */ {I_PCLMULHQHQDQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+5013, IF_SSE|IF_SANDYBRIDGE|IF_SO},
    /* 2996 */ {I_PCLMULQDQ, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+7222, IF_SSE|IF_SANDYBRIDGE|IF_SO},
    /* 2997 */ {I_VFMADDPD, 4, {XMMREG,XMMREG,RM_XMM,XMMREG,0}, nasm_bytecodes+5022, IF_FMA|IF_SANDYBRIDGE|IF_SO},
    /* 2998 */ {I_VFMADDPD, 4, {XMMREG,XMMREG,XMMREG,RM_XMM,0}, nasm_bytecodes+5031, IF_FMA|IF_SANDYBRIDGE|IF_SO},
    /* 2999 */ {I_VFMADDPD, 4, {YMMREG,YMMREG,RM_YMM,YMMREG,0}, nasm_bytecodes+5040, IF_FMA|IF_SANDYBRIDGE|IF_SY},
    /* 3000 */ {I_VFMADDPD, 4, {YMMREG,YMMREG,YMMREG,RM_YMM,0}, nasm_bytecodes+5049, IF_FMA|IF_SANDYBRIDGE|IF_SY},
    /* 3001 */ {I_VFMADDPS, 4, {XMMREG,XMMREG,RM_XMM,XMMREG,0}, nasm_bytecodes+5058, IF_FMA|IF_SANDYBRIDGE|IF_SO},
    /* 3002 */ {I_VFMADDPS, 4, {XMMREG,XMMREG,XMMREG,RM_XMM,0}, nasm_bytecodes+5067, IF_FMA|IF_SANDYBRIDGE|IF_SO},
    /* 3003 */ {I_VFMADDPS, 4, {YMMREG,YMMREG,RM_YMM,YMMREG,0}, nasm_bytecodes+5076, IF_FMA|IF_SANDYBRIDGE|IF_SY},
    /* 3004 */ {I_VFMADDPS, 4, {YMMREG,YMMREG,YMMREG,RM_YMM,0}, nasm_bytecodes+5085, IF_FMA|IF_SANDYBRIDGE|IF_SY},
    /* 3005 */ {I_VFMADDSD, 4, {XMMREG,XMMREG,RM_XMM,XMMREG,0}, nasm_bytecodes+5094, IF_FMA|IF_SANDYBRIDGE|IF_SQ},
    /* 3006 */ {I_VFMADDSD, 4, {XMMREG,XMMREG,XMMREG,RM_XMM,0}, nasm_bytecodes+5103, IF_FMA|IF_SANDYBRIDGE|IF_SQ},
    /* 3007 */ {I_VFMADDSS, 4, {XMMREG,XMMREG,RM_XMM,XMMREG,0}, nasm_bytecodes+5112, IF_FMA|IF_SANDYBRIDGE|IF_SD},
    /* 3008 */ {I_VFMADDSS, 4, {XMMREG,XMMREG,XMMREG,RM_XMM,0}, nasm_bytecodes+5121, IF_FMA|IF_SANDYBRIDGE|IF_SD},
    /* 3009 */ {I_VFMADDSUBPD, 4, {XMMREG,XMMREG,RM_XMM,XMMREG,0}, nasm_bytecodes+5130, IF_FMA|IF_SANDYBRIDGE|IF_SO},
    /* 3010 */ {I_VFMADDSUBPD, 4, {XMMREG,XMMREG,XMMREG,RM_XMM,0}, nasm_bytecodes+5139, IF_FMA|IF_SANDYBRIDGE|IF_SO},
    /* 3011 */ {I_VFMADDSUBPD, 4, {YMMREG,YMMREG,RM_YMM,YMMREG,0}, nasm_bytecodes+5148, IF_FMA|IF_SANDYBRIDGE|IF_SY},
    /* 3012 */ {I_VFMADDSUBPD, 4, {YMMREG,YMMREG,YMMREG,RM_YMM,0}, nasm_bytecodes+5157, IF_FMA|IF_SANDYBRIDGE|IF_SY},
    /* 3013 */ {I_VFMADDSUBPS, 4, {XMMREG,XMMREG,RM_XMM,XMMREG,0}, nasm_bytecodes+5166, IF_FMA|IF_SANDYBRIDGE|IF_SO},
    /* 3014 */ {I_VFMADDSUBPS, 4, {XMMREG,XMMREG,XMMREG,RM_XMM,0}, nasm_bytecodes+5175, IF_FMA|IF_SANDYBRIDGE|IF_SO},
    /* 3015 */ {I_VFMADDSUBPS, 4, {YMMREG,YMMREG,RM_YMM,YMMREG,0}, nasm_bytecodes+5184, IF_FMA|IF_SANDYBRIDGE|IF_SY},
    /* 3016 */ {I_VFMADDSUBPS, 4, {YMMREG,YMMREG,YMMREG,RM_YMM,0}, nasm_bytecodes+5193, IF_FMA|IF_SANDYBRIDGE|IF_SY},
    /* 3017 */ {I_VFMSUBADDPD, 4, {XMMREG,XMMREG,RM_XMM,XMMREG,0}, nasm_bytecodes+5202, IF_FMA|IF_SANDYBRIDGE|IF_SO},
    /* 3018 */ {I_VFMSUBADDPD, 4, {XMMREG,XMMREG,XMMREG,RM_XMM,0}, nasm_bytecodes+5211, IF_FMA|IF_SANDYBRIDGE|IF_SO},
    /* 3019 */ {I_VFMSUBADDPD, 4, {YMMREG,YMMREG,RM_YMM,YMMREG,0}, nasm_bytecodes+5220, IF_FMA|IF_SANDYBRIDGE|IF_SY},
    /* 3020 */ {I_VFMSUBADDPD, 4, {YMMREG,YMMREG,YMMREG,RM_YMM,0}, nasm_bytecodes+5229, IF_FMA|IF_SANDYBRIDGE|IF_SY},
    /* 3021 */ {I_VFMSUBADDPS, 4, {XMMREG,XMMREG,RM_XMM,XMMREG,0}, nasm_bytecodes+5238, IF_FMA|IF_SANDYBRIDGE|IF_SO},
    /* 3022 */ {I_VFMSUBADDPS, 4, {XMMREG,XMMREG,XMMREG,RM_XMM,0}, nasm_bytecodes+5247, IF_FMA|IF_SANDYBRIDGE|IF_SO},
    /* 3023 */ {I_VFMSUBADDPS, 4, {YMMREG,YMMREG,RM_YMM,YMMREG,0}, nasm_bytecodes+5256, IF_FMA|IF_SANDYBRIDGE|IF_SY},
    /* 3024 */ {I_VFMSUBADDPS, 4, {YMMREG,YMMREG,YMMREG,RM_YMM,0}, nasm_bytecodes+5265, IF_FMA|IF_SANDYBRIDGE|IF_SY},
    /* 3025 */ {I_VFMSUBPD, 4, {XMMREG,XMMREG,RM_XMM,XMMREG,0}, nasm_bytecodes+5274, IF_FMA|IF_SANDYBRIDGE|IF_SO},
    /* 3026 */ {I_VFMSUBPD, 4, {XMMREG,XMMREG,XMMREG,RM_XMM,0}, nasm_bytecodes+5283, IF_FMA|IF_SANDYBRIDGE|IF_SO},
    /* 3027 */ {I_VFMSUBPD, 4, {YMMREG,YMMREG,RM_YMM,YMMREG,0}, nasm_bytecodes+5292, IF_FMA|IF_SANDYBRIDGE|IF_SY},
    /* 3028 */ {I_VFMSUBPD, 4, {YMMREG,YMMREG,YMMREG,RM_YMM,0}, nasm_bytecodes+5301, IF_FMA|IF_SANDYBRIDGE|IF_SY},
    /* 3029 */ {I_VFMSUBPS, 4, {XMMREG,XMMREG,RM_XMM,XMMREG,0}, nasm_bytecodes+5310, IF_FMA|IF_SANDYBRIDGE|IF_SO},
    /* 3030 */ {I_VFMSUBPS, 4, {XMMREG,XMMREG,XMMREG,RM_XMM,0}, nasm_bytecodes+5319, IF_FMA|IF_SANDYBRIDGE|IF_SO},
    /* 3031 */ {I_VFMSUBPS, 4, {YMMREG,YMMREG,RM_YMM,YMMREG,0}, nasm_bytecodes+5328, IF_FMA|IF_SANDYBRIDGE|IF_SY},
    /* 3032 */ {I_VFMSUBPS, 4, {YMMREG,YMMREG,YMMREG,RM_YMM,0}, nasm_bytecodes+5337, IF_FMA|IF_SANDYBRIDGE|IF_SY},
    /* 3033 */ {I_VFMSUBSD, 4, {XMMREG,XMMREG,RM_XMM,XMMREG,0}, nasm_bytecodes+5346, IF_FMA|IF_SANDYBRIDGE|IF_SQ},
    /* 3034 */ {I_VFMSUBSD, 4, {XMMREG,XMMREG,XMMREG,RM_XMM,0}, nasm_bytecodes+5355, IF_FMA|IF_SANDYBRIDGE|IF_SQ},
    /* 3035 */ {I_VFMSUBSS, 4, {XMMREG,XMMREG,RM_XMM,XMMREG,0}, nasm_bytecodes+5364, IF_FMA|IF_SANDYBRIDGE|IF_SD},
    /* 3036 */ {I_VFMSUBSS, 4, {XMMREG,XMMREG,XMMREG,RM_XMM,0}, nasm_bytecodes+5373, IF_FMA|IF_SANDYBRIDGE|IF_SD},
    /* 3037 */ {I_VFNMADDPD, 4, {XMMREG,XMMREG,RM_XMM,XMMREG,0}, nasm_bytecodes+5382, IF_FMA|IF_SANDYBRIDGE|IF_SO},
    /* 3038 */ {I_VFNMADDPD, 4, {XMMREG,XMMREG,XMMREG,RM_XMM,0}, nasm_bytecodes+5391, IF_FMA|IF_SANDYBRIDGE|IF_SO},
    /* 3039 */ {I_VFNMADDPD, 4, {XMMREG,XMMREG,RM_XMM,XMMREG,0}, nasm_bytecodes+5400, IF_FMA|IF_SANDYBRIDGE|IF_SY},
    /* 3040 */ {I_VFNMADDPD, 4, {XMMREG,XMMREG,XMMREG,RM_XMM,0}, nasm_bytecodes+5409, IF_FMA|IF_SANDYBRIDGE|IF_SY},
    /* 3041 */ {I_VFNMADDPS, 4, {XMMREG,XMMREG,RM_XMM,XMMREG,0}, nasm_bytecodes+5418, IF_FMA|IF_SANDYBRIDGE|IF_SO},
    /* 3042 */ {I_VFNMADDPS, 4, {XMMREG,XMMREG,XMMREG,RM_XMM,0}, nasm_bytecodes+5427, IF_FMA|IF_SANDYBRIDGE|IF_SO},
    /* 3043 */ {I_VFNMADDPS, 4, {XMMREG,XMMREG,RM_XMM,XMMREG,0}, nasm_bytecodes+5436, IF_FMA|IF_SANDYBRIDGE|IF_SY},
    /* 3044 */ {I_VFNMADDPS, 4, {XMMREG,XMMREG,XMMREG,RM_XMM,0}, nasm_bytecodes+5445, IF_FMA|IF_SANDYBRIDGE|IF_SY},
    /* 3045 */ {I_VFNMADDSD, 4, {XMMREG,XMMREG,RM_XMM,XMMREG,0}, nasm_bytecodes+5454, IF_FMA|IF_SANDYBRIDGE|IF_SQ},
    /* 3046 */ {I_VFNMADDSD, 4, {XMMREG,XMMREG,XMMREG,RM_XMM,0}, nasm_bytecodes+5463, IF_FMA|IF_SANDYBRIDGE|IF_SQ},
    /* 3047 */ {I_VFNMADDSS, 4, {XMMREG,XMMREG,RM_XMM,XMMREG,0}, nasm_bytecodes+5472, IF_FMA|IF_SANDYBRIDGE|IF_SD},
    /* 3048 */ {I_VFNMADDSS, 4, {XMMREG,XMMREG,XMMREG,RM_XMM,0}, nasm_bytecodes+5481, IF_FMA|IF_SANDYBRIDGE|IF_SD},
    /* 3049 */ {I_VFNMSUBPD, 4, {XMMREG,XMMREG,RM_XMM,XMMREG,0}, nasm_bytecodes+5490, IF_FMA|IF_SANDYBRIDGE|IF_SO},
    /* 3050 */ {I_VFNMSUBPD, 4, {XMMREG,XMMREG,XMMREG,RM_XMM,0}, nasm_bytecodes+5499, IF_FMA|IF_SANDYBRIDGE|IF_SO},
    /* 3051 */ {I_VFNMSUBPD, 4, {XMMREG,XMMREG,RM_XMM,XMMREG,0}, nasm_bytecodes+5508, IF_FMA|IF_SANDYBRIDGE|IF_SY},
    /* 3052 */ {I_VFNMSUBPD, 4, {XMMREG,XMMREG,XMMREG,RM_XMM,0}, nasm_bytecodes+5517, IF_FMA|IF_SANDYBRIDGE|IF_SY},
    /* 3053 */ {I_VFNMSUBPS, 4, {XMMREG,XMMREG,RM_XMM,XMMREG,0}, nasm_bytecodes+5526, IF_FMA|IF_SANDYBRIDGE|IF_SO},
    /* 3054 */ {I_VFNMSUBPS, 4, {XMMREG,XMMREG,XMMREG,RM_XMM,0}, nasm_bytecodes+5535, IF_FMA|IF_SANDYBRIDGE|IF_SO},
    /* 3055 */ {I_VFNMSUBPS, 4, {XMMREG,XMMREG,RM_XMM,XMMREG,0}, nasm_bytecodes+5544, IF_FMA|IF_SANDYBRIDGE|IF_SY},
    /* 3056 */ {I_VFNMSUBPS, 4, {XMMREG,XMMREG,XMMREG,RM_XMM,0}, nasm_bytecodes+5553, IF_FMA|IF_SANDYBRIDGE|IF_SY},
    /* 3057 */ {I_VFNMSUBSD, 4, {XMMREG,XMMREG,RM_XMM,XMMREG,0}, nasm_bytecodes+5562, IF_FMA|IF_SANDYBRIDGE|IF_SQ},
    /* 3058 */ {I_VFNMSUBSD, 4, {XMMREG,XMMREG,XMMREG,RM_XMM,0}, nasm_bytecodes+5571, IF_FMA|IF_SANDYBRIDGE|IF_SQ},
    /* 3059 */ {I_VFNMSUBSS, 4, {XMMREG,XMMREG,RM_XMM,XMMREG,0}, nasm_bytecodes+5580, IF_FMA|IF_SANDYBRIDGE|IF_SD},
    /* 3060 */ {I_VFNMSUBSS, 4, {XMMREG,XMMREG,XMMREG,RM_XMM,0}, nasm_bytecodes+5589, IF_FMA|IF_SANDYBRIDGE|IF_SD},
    /* 3061 */ {I_XSTORE, 0, {0,0,0,0,0}, nasm_bytecodes+18542, IF_PENT|IF_CYRIX},
    /* 3062 */ {I_XCRYPTECB, 0, {0,0,0,0,0}, nasm_bytecodes+15490, IF_PENT|IF_CYRIX},
    /* 3063 */ {I_XCRYPTCBC, 0, {0,0,0,0,0}, nasm_bytecodes+15496, IF_PENT|IF_CYRIX},
    /* 3064 */ {I_XCRYPTCTR, 0, {0,0,0,0,0}, nasm_bytecodes+15502, IF_PENT|IF_CYRIX},
    /* 3065 */ {I_XCRYPTCFB, 0, {0,0,0,0,0}, nasm_bytecodes+15508, IF_PENT|IF_CYRIX},
    /* 3066 */ {I_XCRYPTOFB, 0, {0,0,0,0,0}, nasm_bytecodes+15514, IF_PENT|IF_CYRIX},
    /* 3067 */ {I_MONTMUL, 0, {0,0,0,0,0}, nasm_bytecodes+15520, IF_PENT|IF_CYRIX},
    /* 3068 */ {I_XSHA1, 0, {0,0,0,0,0}, nasm_bytecodes+15526, IF_PENT|IF_CYRIX},
    /* 3069 */ {I_XSHA256, 0, {0,0,0,0,0}, nasm_bytecodes+15532, IF_PENT|IF_CYRIX},
    /* 3070 */ {I_HINT_NOP0, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+15538, IF_P6|IF_UNDOC},
    /* 3071 */ {I_HINT_NOP0, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+15544, IF_P6|IF_UNDOC},
    /* 3072 */ {I_HINT_NOP0, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+15550, IF_X64|IF_UNDOC},
    /* 3073 */ {I_HINT_NOP1, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+15556, IF_P6|IF_UNDOC},
    /* 3074 */ {I_HINT_NOP1, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+15562, IF_P6|IF_UNDOC},
    /* 3075 */ {I_HINT_NOP1, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+15568, IF_X64|IF_UNDOC},
    /* 3076 */ {I_HINT_NOP2, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+15574, IF_P6|IF_UNDOC},
    /* 3077 */ {I_HINT_NOP2, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+15580, IF_P6|IF_UNDOC},
    /* 3078 */ {I_HINT_NOP2, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+15586, IF_X64|IF_UNDOC},
    /* 3079 */ {I_HINT_NOP3, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+15592, IF_P6|IF_UNDOC},
    /* 3080 */ {I_HINT_NOP3, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+15598, IF_P6|IF_UNDOC},
    /* 3081 */ {I_HINT_NOP3, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+15604, IF_X64|IF_UNDOC},
    /* 3082 */ {I_HINT_NOP4, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+15610, IF_P6|IF_UNDOC},
    /* 3083 */ {I_HINT_NOP4, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+15616, IF_P6|IF_UNDOC},
    /* 3084 */ {I_HINT_NOP4, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+15622, IF_X64|IF_UNDOC},
    /* 3085 */ {I_HINT_NOP5, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+15628, IF_P6|IF_UNDOC},
    /* 3086 */ {I_HINT_NOP5, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+15634, IF_P6|IF_UNDOC},
    /* 3087 */ {I_HINT_NOP5, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+15640, IF_X64|IF_UNDOC},
    /* 3088 */ {I_HINT_NOP6, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+15646, IF_P6|IF_UNDOC},
    /* 3089 */ {I_HINT_NOP6, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+15652, IF_P6|IF_UNDOC},
    /* 3090 */ {I_HINT_NOP6, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+15658, IF_X64|IF_UNDOC},
    /* 3091 */ {I_HINT_NOP7, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+15664, IF_P6|IF_UNDOC},
    /* 3092 */ {I_HINT_NOP7, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+15670, IF_P6|IF_UNDOC},
    /* 3093 */ {I_HINT_NOP7, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+15676, IF_X64|IF_UNDOC},
    /* 3094 */ {I_HINT_NOP8, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+15682, IF_P6|IF_UNDOC},
    /* 3095 */ {I_HINT_NOP8, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+15688, IF_P6|IF_UNDOC},
    /* 3096 */ {I_HINT_NOP8, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+15694, IF_X64|IF_UNDOC},
    /* 3097 */ {I_HINT_NOP9, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+15700, IF_P6|IF_UNDOC},
    /* 3098 */ {I_HINT_NOP9, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+15706, IF_P6|IF_UNDOC},
    /* 3099 */ {I_HINT_NOP9, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+15712, IF_X64|IF_UNDOC},
    /* 3100 */ {I_HINT_NOP10, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+15718, IF_P6|IF_UNDOC},
    /* 3101 */ {I_HINT_NOP10, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+15724, IF_P6|IF_UNDOC},
    /* 3102 */ {I_HINT_NOP10, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+15730, IF_X64|IF_UNDOC},
    /* 3103 */ {I_HINT_NOP11, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+15736, IF_P6|IF_UNDOC},
    /* 3104 */ {I_HINT_NOP11, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+15742, IF_P6|IF_UNDOC},
    /* 3105 */ {I_HINT_NOP11, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+15748, IF_X64|IF_UNDOC},
    /* 3106 */ {I_HINT_NOP12, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+15754, IF_P6|IF_UNDOC},
    /* 3107 */ {I_HINT_NOP12, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+15760, IF_P6|IF_UNDOC},
    /* 3108 */ {I_HINT_NOP12, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+15766, IF_X64|IF_UNDOC},
    /* 3109 */ {I_HINT_NOP13, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+15772, IF_P6|IF_UNDOC},
    /* 3110 */ {I_HINT_NOP13, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+15778, IF_P6|IF_UNDOC},
    /* 3111 */ {I_HINT_NOP13, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+15784, IF_X64|IF_UNDOC},
    /* 3112 */ {I_HINT_NOP14, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+15790, IF_P6|IF_UNDOC},
    /* 3113 */ {I_HINT_NOP14, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+15796, IF_P6|IF_UNDOC},
    /* 3114 */ {I_HINT_NOP14, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+15802, IF_X64|IF_UNDOC},
    /* 3115 */ {I_HINT_NOP15, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+15808, IF_P6|IF_UNDOC},
    /* 3116 */ {I_HINT_NOP15, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+15814, IF_P6|IF_UNDOC},
    /* 3117 */ {I_HINT_NOP15, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+15820, IF_X64|IF_UNDOC},
    /* 3118 */ {I_HINT_NOP16, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+15826, IF_P6|IF_UNDOC},
    /* 3119 */ {I_HINT_NOP16, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+15832, IF_P6|IF_UNDOC},
    /* 3120 */ {I_HINT_NOP16, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+15838, IF_X64|IF_UNDOC},
    /* 3121 */ {I_HINT_NOP17, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+15844, IF_P6|IF_UNDOC},
    /* 3122 */ {I_HINT_NOP17, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+15850, IF_P6|IF_UNDOC},
    /* 3123 */ {I_HINT_NOP17, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+15856, IF_X64|IF_UNDOC},
    /* 3124 */ {I_HINT_NOP18, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+15862, IF_P6|IF_UNDOC},
    /* 3125 */ {I_HINT_NOP18, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+15868, IF_P6|IF_UNDOC},
    /* 3126 */ {I_HINT_NOP18, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+15874, IF_X64|IF_UNDOC},
    /* 3127 */ {I_HINT_NOP19, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+15880, IF_P6|IF_UNDOC},
    /* 3128 */ {I_HINT_NOP19, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+15886, IF_P6|IF_UNDOC},
    /* 3129 */ {I_HINT_NOP19, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+15892, IF_X64|IF_UNDOC},
    /* 3130 */ {I_HINT_NOP20, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+15898, IF_P6|IF_UNDOC},
    /* 3131 */ {I_HINT_NOP20, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+15904, IF_P6|IF_UNDOC},
    /* 3132 */ {I_HINT_NOP20, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+15910, IF_X64|IF_UNDOC},
    /* 3133 */ {I_HINT_NOP21, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+15916, IF_P6|IF_UNDOC},
    /* 3134 */ {I_HINT_NOP21, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+15922, IF_P6|IF_UNDOC},
    /* 3135 */ {I_HINT_NOP21, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+15928, IF_X64|IF_UNDOC},
    /* 3136 */ {I_HINT_NOP22, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+15934, IF_P6|IF_UNDOC},
    /* 3137 */ {I_HINT_NOP22, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+15940, IF_P6|IF_UNDOC},
    /* 3138 */ {I_HINT_NOP22, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+15946, IF_X64|IF_UNDOC},
    /* 3139 */ {I_HINT_NOP23, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+15952, IF_P6|IF_UNDOC},
    /* 3140 */ {I_HINT_NOP23, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+15958, IF_P6|IF_UNDOC},
    /* 3141 */ {I_HINT_NOP23, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+15964, IF_X64|IF_UNDOC},
    /* 3142 */ {I_HINT_NOP24, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+15970, IF_P6|IF_UNDOC},
    /* 3143 */ {I_HINT_NOP24, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+15976, IF_P6|IF_UNDOC},
    /* 3144 */ {I_HINT_NOP24, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+15982, IF_X64|IF_UNDOC},
    /* 3145 */ {I_HINT_NOP25, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+15988, IF_P6|IF_UNDOC},
    /* 3146 */ {I_HINT_NOP25, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+15994, IF_P6|IF_UNDOC},
    /* 3147 */ {I_HINT_NOP25, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16000, IF_X64|IF_UNDOC},
    /* 3148 */ {I_HINT_NOP26, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16006, IF_P6|IF_UNDOC},
    /* 3149 */ {I_HINT_NOP26, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16012, IF_P6|IF_UNDOC},
    /* 3150 */ {I_HINT_NOP26, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16018, IF_X64|IF_UNDOC},
    /* 3151 */ {I_HINT_NOP27, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16024, IF_P6|IF_UNDOC},
    /* 3152 */ {I_HINT_NOP27, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16030, IF_P6|IF_UNDOC},
    /* 3153 */ {I_HINT_NOP27, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16036, IF_X64|IF_UNDOC},
    /* 3154 */ {I_HINT_NOP28, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16042, IF_P6|IF_UNDOC},
    /* 3155 */ {I_HINT_NOP28, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16048, IF_P6|IF_UNDOC},
    /* 3156 */ {I_HINT_NOP28, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16054, IF_X64|IF_UNDOC},
    /* 3157 */ {I_HINT_NOP29, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16060, IF_P6|IF_UNDOC},
    /* 3158 */ {I_HINT_NOP29, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16066, IF_P6|IF_UNDOC},
    /* 3159 */ {I_HINT_NOP29, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16072, IF_X64|IF_UNDOC},
    /* 3160 */ {I_HINT_NOP30, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16078, IF_P6|IF_UNDOC},
    /* 3161 */ {I_HINT_NOP30, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16084, IF_P6|IF_UNDOC},
    /* 3162 */ {I_HINT_NOP30, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16090, IF_X64|IF_UNDOC},
    /* 3163 */ {I_HINT_NOP31, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16096, IF_P6|IF_UNDOC},
    /* 3164 */ {I_HINT_NOP31, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16102, IF_P6|IF_UNDOC},
    /* 3165 */ {I_HINT_NOP31, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16108, IF_X64|IF_UNDOC},
    /* 3166 */ {I_HINT_NOP32, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16114, IF_P6|IF_UNDOC},
    /* 3167 */ {I_HINT_NOP32, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16120, IF_P6|IF_UNDOC},
    /* 3168 */ {I_HINT_NOP32, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16126, IF_X64|IF_UNDOC},
    /* 3169 */ {I_HINT_NOP33, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16132, IF_P6|IF_UNDOC},
    /* 3170 */ {I_HINT_NOP33, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16138, IF_P6|IF_UNDOC},
    /* 3171 */ {I_HINT_NOP33, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16144, IF_X64|IF_UNDOC},
    /* 3172 */ {I_HINT_NOP34, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16150, IF_P6|IF_UNDOC},
    /* 3173 */ {I_HINT_NOP34, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16156, IF_P6|IF_UNDOC},
    /* 3174 */ {I_HINT_NOP34, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16162, IF_X64|IF_UNDOC},
    /* 3175 */ {I_HINT_NOP35, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16168, IF_P6|IF_UNDOC},
    /* 3176 */ {I_HINT_NOP35, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16174, IF_P6|IF_UNDOC},
    /* 3177 */ {I_HINT_NOP35, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16180, IF_X64|IF_UNDOC},
    /* 3178 */ {I_HINT_NOP36, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16186, IF_P6|IF_UNDOC},
    /* 3179 */ {I_HINT_NOP36, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16192, IF_P6|IF_UNDOC},
    /* 3180 */ {I_HINT_NOP36, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16198, IF_X64|IF_UNDOC},
    /* 3181 */ {I_HINT_NOP37, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16204, IF_P6|IF_UNDOC},
    /* 3182 */ {I_HINT_NOP37, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16210, IF_P6|IF_UNDOC},
    /* 3183 */ {I_HINT_NOP37, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16216, IF_X64|IF_UNDOC},
    /* 3184 */ {I_HINT_NOP38, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16222, IF_P6|IF_UNDOC},
    /* 3185 */ {I_HINT_NOP38, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16228, IF_P6|IF_UNDOC},
    /* 3186 */ {I_HINT_NOP38, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16234, IF_X64|IF_UNDOC},
    /* 3187 */ {I_HINT_NOP39, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16240, IF_P6|IF_UNDOC},
    /* 3188 */ {I_HINT_NOP39, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16246, IF_P6|IF_UNDOC},
    /* 3189 */ {I_HINT_NOP39, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16252, IF_X64|IF_UNDOC},
    /* 3190 */ {I_HINT_NOP40, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16258, IF_P6|IF_UNDOC},
    /* 3191 */ {I_HINT_NOP40, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16264, IF_P6|IF_UNDOC},
    /* 3192 */ {I_HINT_NOP40, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16270, IF_X64|IF_UNDOC},
    /* 3193 */ {I_HINT_NOP41, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16276, IF_P6|IF_UNDOC},
    /* 3194 */ {I_HINT_NOP41, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16282, IF_P6|IF_UNDOC},
    /* 3195 */ {I_HINT_NOP41, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16288, IF_X64|IF_UNDOC},
    /* 3196 */ {I_HINT_NOP42, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16294, IF_P6|IF_UNDOC},
    /* 3197 */ {I_HINT_NOP42, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16300, IF_P6|IF_UNDOC},
    /* 3198 */ {I_HINT_NOP42, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16306, IF_X64|IF_UNDOC},
    /* 3199 */ {I_HINT_NOP43, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16312, IF_P6|IF_UNDOC},
    /* 3200 */ {I_HINT_NOP43, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16318, IF_P6|IF_UNDOC},
    /* 3201 */ {I_HINT_NOP43, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16324, IF_X64|IF_UNDOC},
    /* 3202 */ {I_HINT_NOP44, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16330, IF_P6|IF_UNDOC},
    /* 3203 */ {I_HINT_NOP44, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16336, IF_P6|IF_UNDOC},
    /* 3204 */ {I_HINT_NOP44, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16342, IF_X64|IF_UNDOC},
    /* 3205 */ {I_HINT_NOP45, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16348, IF_P6|IF_UNDOC},
    /* 3206 */ {I_HINT_NOP45, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16354, IF_P6|IF_UNDOC},
    /* 3207 */ {I_HINT_NOP45, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16360, IF_X64|IF_UNDOC},
    /* 3208 */ {I_HINT_NOP46, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16366, IF_P6|IF_UNDOC},
    /* 3209 */ {I_HINT_NOP46, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16372, IF_P6|IF_UNDOC},
    /* 3210 */ {I_HINT_NOP46, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16378, IF_X64|IF_UNDOC},
    /* 3211 */ {I_HINT_NOP47, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16384, IF_P6|IF_UNDOC},
    /* 3212 */ {I_HINT_NOP47, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16390, IF_P6|IF_UNDOC},
    /* 3213 */ {I_HINT_NOP47, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16396, IF_X64|IF_UNDOC},
    /* 3214 */ {I_HINT_NOP48, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16402, IF_P6|IF_UNDOC},
    /* 3215 */ {I_HINT_NOP48, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16408, IF_P6|IF_UNDOC},
    /* 3216 */ {I_HINT_NOP48, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16414, IF_X64|IF_UNDOC},
    /* 3217 */ {I_HINT_NOP49, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16420, IF_P6|IF_UNDOC},
    /* 3218 */ {I_HINT_NOP49, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16426, IF_P6|IF_UNDOC},
    /* 3219 */ {I_HINT_NOP49, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16432, IF_X64|IF_UNDOC},
    /* 3220 */ {I_HINT_NOP50, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16438, IF_P6|IF_UNDOC},
    /* 3221 */ {I_HINT_NOP50, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16444, IF_P6|IF_UNDOC},
    /* 3222 */ {I_HINT_NOP50, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16450, IF_X64|IF_UNDOC},
    /* 3223 */ {I_HINT_NOP51, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16456, IF_P6|IF_UNDOC},
    /* 3224 */ {I_HINT_NOP51, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16462, IF_P6|IF_UNDOC},
    /* 3225 */ {I_HINT_NOP51, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16468, IF_X64|IF_UNDOC},
    /* 3226 */ {I_HINT_NOP52, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16474, IF_P6|IF_UNDOC},
    /* 3227 */ {I_HINT_NOP52, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16480, IF_P6|IF_UNDOC},
    /* 3228 */ {I_HINT_NOP52, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16486, IF_X64|IF_UNDOC},
    /* 3229 */ {I_HINT_NOP53, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16492, IF_P6|IF_UNDOC},
    /* 3230 */ {I_HINT_NOP53, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16498, IF_P6|IF_UNDOC},
    /* 3231 */ {I_HINT_NOP53, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16504, IF_X64|IF_UNDOC},
    /* 3232 */ {I_HINT_NOP54, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16510, IF_P6|IF_UNDOC},
    /* 3233 */ {I_HINT_NOP54, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16516, IF_P6|IF_UNDOC},
    /* 3234 */ {I_HINT_NOP54, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16522, IF_X64|IF_UNDOC},
    /* 3235 */ {I_HINT_NOP55, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16528, IF_P6|IF_UNDOC},
    /* 3236 */ {I_HINT_NOP55, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16534, IF_P6|IF_UNDOC},
    /* 3237 */ {I_HINT_NOP55, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16540, IF_X64|IF_UNDOC},
    /* 3238 */ {I_HINT_NOP56, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+13876, IF_P6|IF_UNDOC},
    /* 3239 */ {I_HINT_NOP56, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+13882, IF_P6|IF_UNDOC},
    /* 3240 */ {I_HINT_NOP56, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+13888, IF_X64|IF_UNDOC},
    /* 3241 */ {I_HINT_NOP57, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16546, IF_P6|IF_UNDOC},
    /* 3242 */ {I_HINT_NOP57, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16552, IF_P6|IF_UNDOC},
    /* 3243 */ {I_HINT_NOP57, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16558, IF_X64|IF_UNDOC},
    /* 3244 */ {I_HINT_NOP58, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16564, IF_P6|IF_UNDOC},
    /* 3245 */ {I_HINT_NOP58, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16570, IF_P6|IF_UNDOC},
    /* 3246 */ {I_HINT_NOP58, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16576, IF_X64|IF_UNDOC},
    /* 3247 */ {I_HINT_NOP59, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16582, IF_P6|IF_UNDOC},
    /* 3248 */ {I_HINT_NOP59, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16588, IF_P6|IF_UNDOC},
    /* 3249 */ {I_HINT_NOP59, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16594, IF_X64|IF_UNDOC},
    /* 3250 */ {I_HINT_NOP60, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16600, IF_P6|IF_UNDOC},
    /* 3251 */ {I_HINT_NOP60, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16606, IF_P6|IF_UNDOC},
    /* 3252 */ {I_HINT_NOP60, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16612, IF_X64|IF_UNDOC},
    /* 3253 */ {I_HINT_NOP61, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16618, IF_P6|IF_UNDOC},
    /* 3254 */ {I_HINT_NOP61, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16624, IF_P6|IF_UNDOC},
    /* 3255 */ {I_HINT_NOP61, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16630, IF_X64|IF_UNDOC},
    /* 3256 */ {I_HINT_NOP62, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16636, IF_P6|IF_UNDOC},
    /* 3257 */ {I_HINT_NOP62, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16642, IF_P6|IF_UNDOC},
    /* 3258 */ {I_HINT_NOP62, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16648, IF_X64|IF_UNDOC},
    /* 3259 */ {I_HINT_NOP63, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16654, IF_P6|IF_UNDOC},
    /* 3260 */ {I_HINT_NOP63, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16660, IF_P6|IF_UNDOC},
    /* 3261 */ {I_HINT_NOP63, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16666, IF_X64|IF_UNDOC},
};

static const struct itemplate * const itable_00[] = {
    instrux + 37,
    instrux + 38,
};

static const struct itemplate * const itable_01[] = {
    instrux + 39,
    instrux + 40,
    instrux + 41,
    instrux + 42,
    instrux + 43,
    instrux + 44,
};

static const struct itemplate * const itable_02[] = {
    instrux + 45,
    instrux + 46,
};

static const struct itemplate * const itable_03[] = {
    instrux + 47,
    instrux + 48,
    instrux + 49,
    instrux + 50,
    instrux + 51,
    instrux + 52,
};

static const struct itemplate * const itable_04[] = {
    instrux + 56,
};

static const struct itemplate * const itable_05[] = {
    instrux + 57,
    instrux + 58,
    instrux + 59,
};

static const struct itemplate * const itable_06[] = {
    instrux + 851,
    instrux + 852,
};

static const struct itemplate * const itable_07[] = {
    instrux + 803,
};

static const struct itemplate * const itable_08[] = {
    instrux + 706,
    instrux + 707,
};

static const struct itemplate * const itable_09[] = {
    instrux + 708,
    instrux + 709,
    instrux + 710,
    instrux + 711,
    instrux + 712,
    instrux + 713,
};

static const struct itemplate * const itable_0A[] = {
    instrux + 714,
    instrux + 715,
};

static const struct itemplate * const itable_0B[] = {
    instrux + 716,
    instrux + 717,
    instrux + 718,
    instrux + 719,
    instrux + 720,
    instrux + 721,
};

static const struct itemplate * const itable_0C[] = {
    instrux + 725,
};

static const struct itemplate * const itable_0D[] = {
    instrux + 726,
    instrux + 727,
    instrux + 728,
};

static const struct itemplate * const itable_0E[] = {
    instrux + 851,
    instrux + 852,
};

static const struct itemplate * const itable_0F00[] = {
    instrux + 532,
    instrux + 533,
    instrux + 561,
    instrux + 562,
    instrux + 563,
    instrux + 605,
    instrux + 606,
    instrux + 607,
    instrux + 1029,
    instrux + 1030,
    instrux + 1031,
    instrux + 1032,
    instrux + 1033,
    instrux + 1048,
    instrux + 1049,
    instrux + 1050,
    instrux + 1051,
    instrux + 1052,
    instrux + 1116,
    instrux + 1117,
    instrux + 1118,
    instrux + 1119,
    instrux + 1120,
    instrux + 1121,
};

static const struct itemplate * const itable_0F01[] = {
    instrux + 183,
    instrux + 493,
    instrux + 494,
    instrux + 495,
    instrux + 496,
    instrux + 497,
    instrux + 557,
    instrux + 560,
    instrux + 564,
    instrux + 565,
    instrux + 566,
    instrux + 609,
    instrux + 693,
    instrux + 895,
    instrux + 979,
    instrux + 1028,
    instrux + 1034,
    instrux + 1036,
    instrux + 1037,
    instrux + 1038,
    instrux + 1039,
    instrux + 1042,
    instrux + 1085,
    instrux + 1286,
    instrux + 1287,
    instrux + 1516,
    instrux + 1518,
    instrux + 1519,
    instrux + 1520,
    instrux + 1525,
    instrux + 1526,
    instrux + 1527,
    instrux + 1530,
};

static const struct itemplate * const itable_0F02[] = {
    instrux + 536,
    instrux + 537,
    instrux + 538,
    instrux + 539,
    instrux + 540,
    instrux + 541,
    instrux + 542,
    instrux + 543,
    instrux + 544,
    instrux + 545,
};

static const struct itemplate * const itable_0F03[] = {
    instrux + 593,
    instrux + 594,
    instrux + 595,
    instrux + 596,
    instrux + 597,
    instrux + 598,
    instrux + 599,
    instrux + 600,
    instrux + 601,
    instrux + 602,
};

static const struct itemplate * const itable_0F05[] = {
    instrux + 568,
    instrux + 1086,
};

static const struct itemplate * const itable_0F06[] = {
    instrux + 185,
};

static const struct itemplate * const itable_0F07[] = {
    instrux + 567,
    instrux + 1089,
};

static const struct itemplate * const itable_0F08[] = {
    instrux + 492,
};

static const struct itemplate * const itable_0F09[] = {
    instrux + 1124,
};

static const struct itemplate * const itable_0F0B[] = {
    instrux + 1115,
};

static const struct itemplate * const itable_0F0D[] = {
    instrux + 813,
    instrux + 814,
};

static const struct itemplate * const itable_0F0E[] = {
    instrux + 318,
};

static const struct itemplate * const itable_0F0F[] = {
    instrux + 760,
    instrux + 768,
    instrux + 769,
    instrux + 770,
    instrux + 771,
    instrux + 772,
    instrux + 773,
    instrux + 774,
    instrux + 775,
    instrux + 776,
    instrux + 777,
    instrux + 778,
    instrux + 779,
    instrux + 780,
    instrux + 781,
    instrux + 782,
    instrux + 783,
    instrux + 784,
    instrux + 789,
    instrux + 1310,
    instrux + 1311,
    instrux + 1312,
    instrux + 1313,
    instrux + 1314,
    instrux + 1931,
    instrux + 1932,
};

static const struct itemplate * const itable_0F10[] = {
    instrux + 1258,
    instrux + 1260,
    instrux + 1262,
    instrux + 1264,
    instrux + 1485,
    instrux + 1488,
    instrux + 1489,
    instrux + 1492,
};

static const struct itemplate * const itable_0F11[] = {
    instrux + 1259,
    instrux + 1261,
    instrux + 1263,
    instrux + 1265,
    instrux + 1486,
    instrux + 1487,
    instrux + 1490,
    instrux + 1491,
};

static const struct itemplate * const itable_0F12[] = {
    instrux + 1252,
    instrux + 1254,
    instrux + 1482,
    instrux + 1513,
    instrux + 1515,
};

static const struct itemplate * const itable_0F13[] = {
    instrux + 1253,
    instrux + 1481,
};

static const struct itemplate * const itable_0F14[] = {
    instrux + 1282,
    instrux + 1504,
};

static const struct itemplate * const itable_0F15[] = {
    instrux + 1281,
    instrux + 1503,
};

static const struct itemplate * const itable_0F16[] = {
    instrux + 1249,
    instrux + 1251,
    instrux + 1480,
    instrux + 1514,
};

static const struct itemplate * const itable_0F17[] = {
    instrux + 1250,
    instrux + 1479,
};

static const struct itemplate * const itable_0F18[] = {
    instrux + 1290,
    instrux + 1291,
    instrux + 1292,
    instrux + 1293,
    instrux + 3070,
    instrux + 3071,
    instrux + 3072,
    instrux + 3073,
    instrux + 3074,
    instrux + 3075,
    instrux + 3076,
    instrux + 3077,
    instrux + 3078,
    instrux + 3079,
    instrux + 3080,
    instrux + 3081,
    instrux + 3082,
    instrux + 3083,
    instrux + 3084,
    instrux + 3085,
    instrux + 3086,
    instrux + 3087,
    instrux + 3088,
    instrux + 3089,
    instrux + 3090,
    instrux + 3091,
    instrux + 3092,
    instrux + 3093,
};

static const struct itemplate * const itable_0F19[] = {
    instrux + 3094,
    instrux + 3095,
    instrux + 3096,
    instrux + 3097,
    instrux + 3098,
    instrux + 3099,
    instrux + 3100,
    instrux + 3101,
    instrux + 3102,
    instrux + 3103,
    instrux + 3104,
    instrux + 3105,
    instrux + 3106,
    instrux + 3107,
    instrux + 3108,
    instrux + 3109,
    instrux + 3110,
    instrux + 3111,
    instrux + 3112,
    instrux + 3113,
    instrux + 3114,
    instrux + 3115,
    instrux + 3116,
    instrux + 3117,
};

static const struct itemplate * const itable_0F1A[] = {
    instrux + 3118,
    instrux + 3119,
    instrux + 3120,
    instrux + 3121,
    instrux + 3122,
    instrux + 3123,
    instrux + 3124,
    instrux + 3125,
    instrux + 3126,
    instrux + 3127,
    instrux + 3128,
    instrux + 3129,
    instrux + 3130,
    instrux + 3131,
    instrux + 3132,
    instrux + 3133,
    instrux + 3134,
    instrux + 3135,
    instrux + 3136,
    instrux + 3137,
    instrux + 3138,
    instrux + 3139,
    instrux + 3140,
    instrux + 3141,
};

static const struct itemplate * const itable_0F1B[] = {
    instrux + 3142,
    instrux + 3143,
    instrux + 3144,
    instrux + 3145,
    instrux + 3146,
    instrux + 3147,
    instrux + 3148,
    instrux + 3149,
    instrux + 3150,
    instrux + 3151,
    instrux + 3152,
    instrux + 3153,
    instrux + 3154,
    instrux + 3155,
    instrux + 3156,
    instrux + 3157,
    instrux + 3158,
    instrux + 3159,
    instrux + 3160,
    instrux + 3161,
    instrux + 3162,
    instrux + 3163,
    instrux + 3164,
    instrux + 3165,
};

static const struct itemplate * const itable_0F1C[] = {
    instrux + 3166,
    instrux + 3167,
    instrux + 3168,
    instrux + 3169,
    instrux + 3170,
    instrux + 3171,
    instrux + 3172,
    instrux + 3173,
    instrux + 3174,
    instrux + 3175,
    instrux + 3176,
    instrux + 3177,
    instrux + 3178,
    instrux + 3179,
    instrux + 3180,
    instrux + 3181,
    instrux + 3182,
    instrux + 3183,
    instrux + 3184,
    instrux + 3185,
    instrux + 3186,
    instrux + 3187,
    instrux + 3188,
    instrux + 3189,
};

static const struct itemplate * const itable_0F1D[] = {
    instrux + 3190,
    instrux + 3191,
    instrux + 3192,
    instrux + 3193,
    instrux + 3194,
    instrux + 3195,
    instrux + 3196,
    instrux + 3197,
    instrux + 3198,
    instrux + 3199,
    instrux + 3200,
    instrux + 3201,
    instrux + 3202,
    instrux + 3203,
    instrux + 3204,
    instrux + 3205,
    instrux + 3206,
    instrux + 3207,
    instrux + 3208,
    instrux + 3209,
    instrux + 3210,
    instrux + 3211,
    instrux + 3212,
    instrux + 3213,
};

static const struct itemplate * const itable_0F1E[] = {
    instrux + 3214,
    instrux + 3215,
    instrux + 3216,
    instrux + 3217,
    instrux + 3218,
    instrux + 3219,
    instrux + 3220,
    instrux + 3221,
    instrux + 3222,
    instrux + 3223,
    instrux + 3224,
    instrux + 3225,
    instrux + 3226,
    instrux + 3227,
    instrux + 3228,
    instrux + 3229,
    instrux + 3230,
    instrux + 3231,
    instrux + 3232,
    instrux + 3233,
    instrux + 3234,
    instrux + 3235,
    instrux + 3236,
    instrux + 3237,
};

static const struct itemplate * const itable_0F1F[] = {
    instrux + 699,
    instrux + 700,
    instrux + 701,
    instrux + 3238,
    instrux + 3239,
    instrux + 3240,
    instrux + 3241,
    instrux + 3242,
    instrux + 3243,
    instrux + 3244,
    instrux + 3245,
    instrux + 3246,
    instrux + 3247,
    instrux + 3248,
    instrux + 3249,
    instrux + 3250,
    instrux + 3251,
    instrux + 3252,
    instrux + 3253,
    instrux + 3254,
    instrux + 3255,
    instrux + 3256,
    instrux + 3257,
    instrux + 3258,
    instrux + 3259,
    instrux + 3260,
    instrux + 3261,
};

static const struct itemplate * const itable_0F20[] = {
    instrux + 624,
    instrux + 625,
};

static const struct itemplate * const itable_0F21[] = {
    instrux + 628,
    instrux + 629,
};

static const struct itemplate * const itable_0F22[] = {
    instrux + 626,
    instrux + 627,
};

static const struct itemplate * const itable_0F23[] = {
    instrux + 630,
    instrux + 631,
};

static const struct itemplate * const itable_0F2400[] = {
    instrux + 1645,
    instrux + 1646,
};

static const struct itemplate * const itable_0F2401[] = {
    instrux + 1649,
    instrux + 1650,
};

static const struct itemplate * const itable_0F2402[] = {
    instrux + 1653,
    instrux + 1654,
};

static const struct itemplate * const itable_0F2403[] = {
    instrux + 1657,
    instrux + 1658,
};

static const struct itemplate * const itable_0F2404[] = {
    instrux + 1647,
    instrux + 1648,
};

static const struct itemplate * const itable_0F2405[] = {
    instrux + 1651,
    instrux + 1652,
};

static const struct itemplate * const itable_0F2406[] = {
    instrux + 1655,
    instrux + 1656,
};

static const struct itemplate * const itable_0F2407[] = {
    instrux + 1659,
    instrux + 1660,
};

static const struct itemplate * const itable_0F2408[] = {
    instrux + 1661,
    instrux + 1662,
};

static const struct itemplate * const itable_0F2409[] = {
    instrux + 1665,
    instrux + 1666,
};

static const struct itemplate * const itable_0F240A[] = {
    instrux + 1669,
    instrux + 1670,
};

static const struct itemplate * const itable_0F240B[] = {
    instrux + 1673,
    instrux + 1674,
};

static const struct itemplate * const itable_0F240C[] = {
    instrux + 1663,
    instrux + 1664,
};

static const struct itemplate * const itable_0F240D[] = {
    instrux + 1667,
    instrux + 1668,
};

static const struct itemplate * const itable_0F240E[] = {
    instrux + 1671,
    instrux + 1672,
};

static const struct itemplate * const itable_0F240F[] = {
    instrux + 1675,
    instrux + 1676,
};

static const struct itemplate * const itable_0F2410[] = {
    instrux + 1677,
    instrux + 1678,
};

static const struct itemplate * const itable_0F2411[] = {
    instrux + 1681,
    instrux + 1682,
};

static const struct itemplate * const itable_0F2412[] = {
    instrux + 1685,
    instrux + 1686,
};

static const struct itemplate * const itable_0F2413[] = {
    instrux + 1689,
    instrux + 1690,
};

static const struct itemplate * const itable_0F2414[] = {
    instrux + 1679,
    instrux + 1680,
};

static const struct itemplate * const itable_0F2415[] = {
    instrux + 1683,
    instrux + 1684,
};

static const struct itemplate * const itable_0F2416[] = {
    instrux + 1687,
    instrux + 1688,
};

static const struct itemplate * const itable_0F2417[] = {
    instrux + 1691,
    instrux + 1692,
};

static const struct itemplate * const itable_0F2418[] = {
    instrux + 1693,
    instrux + 1694,
};

static const struct itemplate * const itable_0F2419[] = {
    instrux + 1697,
    instrux + 1698,
};

static const struct itemplate * const itable_0F241A[] = {
    instrux + 1701,
    instrux + 1702,
};

static const struct itemplate * const itable_0F241B[] = {
    instrux + 1705,
    instrux + 1706,
};

static const struct itemplate * const itable_0F241C[] = {
    instrux + 1695,
    instrux + 1696,
};

static const struct itemplate * const itable_0F241D[] = {
    instrux + 1699,
    instrux + 1700,
};

static const struct itemplate * const itable_0F241E[] = {
    instrux + 1703,
    instrux + 1704,
};

static const struct itemplate * const itable_0F241F[] = {
    instrux + 1707,
    instrux + 1708,
};

static const struct itemplate * const itable_0F2420[] = {
    instrux + 1849,
    instrux + 1850,
};

static const struct itemplate * const itable_0F2421[] = {
    instrux + 1853,
    instrux + 1854,
};

static const struct itemplate * const itable_0F2422[] = {
    instrux + 1857,
    instrux + 1858,
};

static const struct itemplate * const itable_0F2423[] = {
    instrux + 1861,
    instrux + 1862,
};

static const struct itemplate * const itable_0F2424[] = {
    instrux + 1851,
    instrux + 1852,
};

static const struct itemplate * const itable_0F2425[] = {
    instrux + 1855,
    instrux + 1856,
};

static const struct itemplate * const itable_0F2426[] = {
    instrux + 1859,
    instrux + 1860,
};

static const struct itemplate * const itable_0F2427[] = {
    instrux + 1863,
    instrux + 1864,
};

static const struct itemplate * const itable_0F2440[] = {
    instrux + 1877,
    instrux + 1878,
};

static const struct itemplate * const itable_0F2441[] = {
    instrux + 1879,
    instrux + 1880,
};

static const struct itemplate * const itable_0F2442[] = {
    instrux + 1881,
    instrux + 1882,
};

static const struct itemplate * const itable_0F2443[] = {
    instrux + 1883,
    instrux + 1884,
};

static const struct itemplate * const itable_0F2444[] = {
    instrux + 1885,
    instrux + 1886,
};

static const struct itemplate * const itable_0F2445[] = {
    instrux + 1887,
    instrux + 1888,
};

static const struct itemplate * const itable_0F2446[] = {
    instrux + 1889,
    instrux + 1890,
};

static const struct itemplate * const itable_0F2447[] = {
    instrux + 1891,
    instrux + 1892,
};

static const struct itemplate * const itable_0F2448[] = {
    instrux + 1893,
    instrux + 1894,
};

static const struct itemplate * const itable_0F2449[] = {
    instrux + 1895,
    instrux + 1896,
};

static const struct itemplate * const itable_0F244A[] = {
    instrux + 1897,
    instrux + 1898,
};

static const struct itemplate * const itable_0F244B[] = {
    instrux + 1899,
    instrux + 1900,
};

static const struct itemplate * const itable_0F2485[] = {
    instrux + 1865,
};

static const struct itemplate * const itable_0F2486[] = {
    instrux + 1867,
};

static const struct itemplate * const itable_0F2487[] = {
    instrux + 1871,
};

static const struct itemplate * const itable_0F248E[] = {
    instrux + 1869,
};

static const struct itemplate * const itable_0F248F[] = {
    instrux + 1873,
};

static const struct itemplate * const itable_0F2495[] = {
    instrux + 1866,
};

static const struct itemplate * const itable_0F2496[] = {
    instrux + 1868,
};

static const struct itemplate * const itable_0F2497[] = {
    instrux + 1872,
};

static const struct itemplate * const itable_0F249E[] = {
    instrux + 1870,
};

static const struct itemplate * const itable_0F249F[] = {
    instrux + 1874,
};

static const struct itemplate * const itable_0F24A6[] = {
    instrux + 1875,
};

static const struct itemplate * const itable_0F24B6[] = {
    instrux + 1876,
};

static const struct itemplate * const itable_0F252C[] = {
    instrux + 1709,
    instrux + 1710,
    instrux + 1711,
    instrux + 1712,
    instrux + 1713,
    instrux + 1714,
    instrux + 1715,
    instrux + 1716,
    instrux + 1717,
    instrux + 1718,
    instrux + 1719,
    instrux + 1720,
    instrux + 1721,
    instrux + 1722,
    instrux + 1723,
    instrux + 1724,
    instrux + 1725,
};

static const struct itemplate * const itable_0F252D[] = {
    instrux + 1726,
    instrux + 1727,
    instrux + 1728,
    instrux + 1729,
    instrux + 1730,
    instrux + 1731,
    instrux + 1732,
    instrux + 1733,
    instrux + 1734,
    instrux + 1735,
    instrux + 1736,
    instrux + 1737,
    instrux + 1738,
    instrux + 1739,
    instrux + 1740,
    instrux + 1741,
    instrux + 1742,
};

static const struct itemplate * const itable_0F252E[] = {
    instrux + 1743,
    instrux + 1744,
    instrux + 1745,
    instrux + 1746,
    instrux + 1747,
    instrux + 1748,
    instrux + 1749,
    instrux + 1750,
    instrux + 1751,
    instrux + 1752,
    instrux + 1753,
    instrux + 1754,
    instrux + 1755,
    instrux + 1756,
    instrux + 1757,
    instrux + 1758,
    instrux + 1759,
};

static const struct itemplate * const itable_0F252F[] = {
    instrux + 1760,
    instrux + 1761,
    instrux + 1762,
    instrux + 1763,
    instrux + 1764,
    instrux + 1765,
    instrux + 1766,
    instrux + 1767,
    instrux + 1768,
    instrux + 1769,
    instrux + 1770,
    instrux + 1771,
    instrux + 1772,
    instrux + 1773,
    instrux + 1774,
    instrux + 1775,
    instrux + 1776,
};

static const struct itemplate * const itable_0F254C[] = {
    instrux + 1777,
    instrux + 1778,
    instrux + 1779,
    instrux + 1780,
    instrux + 1781,
    instrux + 1782,
    instrux + 1783,
    instrux + 1784,
    instrux + 1785,
};

static const struct itemplate * const itable_0F254D[] = {
    instrux + 1786,
    instrux + 1787,
    instrux + 1788,
    instrux + 1789,
    instrux + 1790,
    instrux + 1791,
    instrux + 1792,
    instrux + 1793,
    instrux + 1794,
};

static const struct itemplate * const itable_0F254E[] = {
    instrux + 1795,
    instrux + 1796,
    instrux + 1797,
    instrux + 1798,
    instrux + 1799,
    instrux + 1800,
    instrux + 1801,
    instrux + 1802,
    instrux + 1803,
};

static const struct itemplate * const itable_0F254F[] = {
    instrux + 1804,
    instrux + 1805,
    instrux + 1806,
    instrux + 1807,
    instrux + 1808,
    instrux + 1809,
    instrux + 1810,
    instrux + 1811,
    instrux + 1812,
};

static const struct itemplate * const itable_0F256C[] = {
    instrux + 1813,
    instrux + 1814,
    instrux + 1815,
    instrux + 1816,
    instrux + 1817,
    instrux + 1818,
    instrux + 1819,
    instrux + 1820,
    instrux + 1821,
};

static const struct itemplate * const itable_0F256D[] = {
    instrux + 1822,
    instrux + 1823,
    instrux + 1824,
    instrux + 1825,
    instrux + 1826,
    instrux + 1827,
    instrux + 1828,
    instrux + 1829,
    instrux + 1830,
};

static const struct itemplate * const itable_0F256E[] = {
    instrux + 1831,
    instrux + 1832,
    instrux + 1833,
    instrux + 1834,
    instrux + 1835,
    instrux + 1836,
    instrux + 1837,
    instrux + 1838,
    instrux + 1839,
};

static const struct itemplate * const itable_0F256F[] = {
    instrux + 1840,
    instrux + 1841,
    instrux + 1842,
    instrux + 1843,
    instrux + 1844,
    instrux + 1845,
    instrux + 1846,
    instrux + 1847,
    instrux + 1848,
};

static const struct itemplate * const itable_0F28[] = {
    instrux + 1245,
    instrux + 1247,
    instrux + 1475,
    instrux + 1478,
};

static const struct itemplate * const itable_0F29[] = {
    instrux + 1246,
    instrux + 1248,
    instrux + 1476,
    instrux + 1477,
};

static const struct itemplate * const itable_0F2A[] = {
    instrux + 1227,
    instrux + 1229,
    instrux + 1230,
    instrux + 1451,
    instrux + 1459,
    instrux + 1460,
};

static const struct itemplate * const itable_0F2B[] = {
    instrux + 1257,
    instrux + 1320,
    instrux + 1572,
    instrux + 1573,
};

static const struct itemplate * const itable_0F2C[] = {
    instrux + 1235,
    instrux + 1236,
    instrux + 1237,
    instrux + 1462,
    instrux + 1465,
    instrux + 1466,
    instrux + 1467,
    instrux + 1468,
};

static const struct itemplate * const itable_0F2D[] = {
    instrux + 1228,
    instrux + 1231,
    instrux + 1232,
    instrux + 1233,
    instrux + 1234,
    instrux + 1449,
    instrux + 1454,
    instrux + 1455,
    instrux + 1456,
    instrux + 1457,
};

static const struct itemplate * const itable_0F2E[] = {
    instrux + 1280,
    instrux + 1502,
};

static const struct itemplate * const itable_0F2F[] = {
    instrux + 1226,
    instrux + 1445,
};

static const struct itemplate * const itable_0F30[] = {
    instrux + 1126,
};

static const struct itemplate * const itable_0F31[] = {
    instrux + 894,
};

static const struct itemplate * const itable_0F32[] = {
    instrux + 892,
};

static const struct itemplate * const itable_0F33[] = {
    instrux + 893,
};

static const struct itemplate * const itable_0F34[] = {
    instrux + 1087,
};

static const struct itemplate * const itable_0F35[] = {
    instrux + 1088,
};

static const struct itemplate * const itable_0F36[] = {
    instrux + 891,
};

static const struct itemplate * const itable_0F37[] = {
    instrux + 1125,
    instrux + 1930,
};

static const struct itemplate * const itable_0F3800[] = {
    instrux + 1560,
    instrux + 1561,
};

static const struct itemplate * const itable_0F3801[] = {
    instrux + 1544,
    instrux + 1545,
};

static const struct itemplate * const itable_0F3802[] = {
    instrux + 1546,
    instrux + 1547,
};

static const struct itemplate * const itable_0F3803[] = {
    instrux + 1548,
    instrux + 1549,
};

static const struct itemplate * const itable_0F3804[] = {
    instrux + 1556,
    instrux + 1557,
};

static const struct itemplate * const itable_0F3805[] = {
    instrux + 1550,
    instrux + 1551,
};

static const struct itemplate * const itable_0F3806[] = {
    instrux + 1552,
    instrux + 1553,
};

static const struct itemplate * const itable_0F3807[] = {
    instrux + 1554,
    instrux + 1555,
};

static const struct itemplate * const itable_0F3808[] = {
    instrux + 1562,
    instrux + 1563,
};

static const struct itemplate * const itable_0F3809[] = {
    instrux + 1564,
    instrux + 1565,
};

static const struct itemplate * const itable_0F380A[] = {
    instrux + 1566,
    instrux + 1567,
};

static const struct itemplate * const itable_0F380B[] = {
    instrux + 1558,
    instrux + 1559,
};

static const struct itemplate * const itable_0F3810[] = {
    instrux + 1589,
};

static const struct itemplate * const itable_0F3814[] = {
    instrux + 1580,
};

static const struct itemplate * const itable_0F3815[] = {
    instrux + 1579,
};

static const struct itemplate * const itable_0F3817[] = {
    instrux + 1627,
};

static const struct itemplate * const itable_0F381C[] = {
    instrux + 1536,
    instrux + 1537,
};

static const struct itemplate * const itable_0F381D[] = {
    instrux + 1538,
    instrux + 1539,
};

static const struct itemplate * const itable_0F381E[] = {
    instrux + 1540,
    instrux + 1541,
};

static const struct itemplate * const itable_0F3820[] = {
    instrux + 1613,
};

static const struct itemplate * const itable_0F3821[] = {
    instrux + 1614,
};

static const struct itemplate * const itable_0F3822[] = {
    instrux + 1615,
};

static const struct itemplate * const itable_0F3823[] = {
    instrux + 1616,
};

static const struct itemplate * const itable_0F3824[] = {
    instrux + 1617,
};

static const struct itemplate * const itable_0F3825[] = {
    instrux + 1618,
};

static const struct itemplate * const itable_0F3828[] = {
    instrux + 1625,
};

static const struct itemplate * const itable_0F3829[] = {
    instrux + 1591,
};

static const struct itemplate * const itable_0F382A[] = {
    instrux + 1586,
};

static const struct itemplate * const itable_0F382B[] = {
    instrux + 1588,
};

static const struct itemplate * const itable_0F3830[] = {
    instrux + 1619,
};

static const struct itemplate * const itable_0F3831[] = {
    instrux + 1620,
};

static const struct itemplate * const itable_0F3832[] = {
    instrux + 1621,
};

static const struct itemplate * const itable_0F3833[] = {
    instrux + 1622,
};

static const struct itemplate * const itable_0F3834[] = {
    instrux + 1623,
};

static const struct itemplate * const itable_0F3835[] = {
    instrux + 1624,
};

static const struct itemplate * const itable_0F3837[] = {
    instrux + 1641,
};

static const struct itemplate * const itable_0F3838[] = {
    instrux + 1609,
};

static const struct itemplate * const itable_0F3839[] = {
    instrux + 1610,
};

static const struct itemplate * const itable_0F383A[] = {
    instrux + 1612,
};

static const struct itemplate * const itable_0F383B[] = {
    instrux + 1611,
};

static const struct itemplate * const itable_0F383C[] = {
    instrux + 1605,
};

static const struct itemplate * const itable_0F383D[] = {
    instrux + 1606,
};

static const struct itemplate * const itable_0F383E[] = {
    instrux + 1608,
};

static const struct itemplate * const itable_0F383F[] = {
    instrux + 1607,
};

static const struct itemplate * const itable_0F3840[] = {
    instrux + 1626,
};

static const struct itemplate * const itable_0F3841[] = {
    instrux + 1600,
};

static const struct itemplate * const itable_0F3880[] = {
    instrux + 1532,
    instrux + 1533,
};

static const struct itemplate * const itable_0F3881[] = {
    instrux + 1534,
    instrux + 1535,
};

static const struct itemplate * const itable_0F38DB[] = {
    instrux + 1943,
};

static const struct itemplate * const itable_0F38DC[] = {
    instrux + 1939,
};

static const struct itemplate * const itable_0F38DD[] = {
    instrux + 1940,
};

static const struct itemplate * const itable_0F38DE[] = {
    instrux + 1941,
};

static const struct itemplate * const itable_0F38DF[] = {
    instrux + 1942,
};

static const struct itemplate * const itable_0F38F0[] = {
    instrux + 1632,
    instrux + 1635,
    instrux + 1933,
    instrux + 1934,
    instrux + 1935,
};

static const struct itemplate * const itable_0F38F1[] = {
    instrux + 1633,
    instrux + 1634,
    instrux + 1636,
    instrux + 1936,
    instrux + 1937,
    instrux + 1938,
};

static const struct itemplate * const itable_0F39[] = {
    instrux + 249,
};

static const struct itemplate * const itable_0F3A08[] = {
    instrux + 1629,
    instrux + 1926,
    instrux + 1927,
    instrux + 1928,
    instrux + 1929,
};

static const struct itemplate * const itable_0F3A09[] = {
    instrux + 1628,
};

static const struct itemplate * const itable_0F3A0A[] = {
    instrux + 1631,
};

static const struct itemplate * const itable_0F3A0B[] = {
    instrux + 1630,
};

static const struct itemplate * const itable_0F3A0C[] = {
    instrux + 1578,
};

static const struct itemplate * const itable_0F3A0D[] = {
    instrux + 1577,
};

static const struct itemplate * const itable_0F3A0E[] = {
    instrux + 1590,
};

static const struct itemplate * const itable_0F3A0F[] = {
    instrux + 1542,
    instrux + 1543,
};

static const struct itemplate * const itable_0F3A14[] = {
    instrux + 1592,
    instrux + 1593,
    instrux + 1594,
};

static const struct itemplate * const itable_0F3A15[] = {
    instrux + 1597,
    instrux + 1598,
    instrux + 1599,
};

static const struct itemplate * const itable_0F3A16[] = {
    instrux + 1595,
    instrux + 1596,
};

static const struct itemplate * const itable_0F3A17[] = {
    instrux + 1583,
    instrux + 1584,
};

static const struct itemplate * const itable_0F3A20[] = {
    instrux + 1601,
    instrux + 1602,
};

static const struct itemplate * const itable_0F3A21[] = {
    instrux + 1585,
};

static const struct itemplate * const itable_0F3A22[] = {
    instrux + 1603,
    instrux + 1604,
};

static const struct itemplate * const itable_0F3A40[] = {
    instrux + 1582,
};

static const struct itemplate * const itable_0F3A41[] = {
    instrux + 1581,
};

static const struct itemplate * const itable_0F3A42[] = {
    instrux + 1587,
};

static const struct itemplate * const itable_0F3A44[] = {
    instrux + 2992,
    instrux + 2993,
    instrux + 2994,
    instrux + 2995,
    instrux + 2996,
};

static const struct itemplate * const itable_0F3A60[] = {
    instrux + 1638,
};

static const struct itemplate * const itable_0F3A61[] = {
    instrux + 1637,
};

static const struct itemplate * const itable_0F3A62[] = {
    instrux + 1640,
};

static const struct itemplate * const itable_0F3A63[] = {
    instrux + 1639,
};

static const struct itemplate * const itable_0F3ADF[] = {
    instrux + 1944,
};

static const struct itemplate * const itable_0F3C[] = {
    instrux + 233,
};

static const struct itemplate * const itable_0F3D[] = {
    instrux + 232,
};

static const struct itemplate * const itable_0F40[] = {
    instrux + 1190,
    instrux + 1191,
    instrux + 1192,
    instrux + 1193,
    instrux + 1194,
    instrux + 1195,
};

static const struct itemplate * const itable_0F41[] = {
    instrux + 1190,
    instrux + 1191,
    instrux + 1192,
    instrux + 1193,
    instrux + 1194,
    instrux + 1195,
};

static const struct itemplate * const itable_0F42[] = {
    instrux + 1190,
    instrux + 1191,
    instrux + 1192,
    instrux + 1193,
    instrux + 1194,
    instrux + 1195,
};

static const struct itemplate * const itable_0F43[] = {
    instrux + 1190,
    instrux + 1191,
    instrux + 1192,
    instrux + 1193,
    instrux + 1194,
    instrux + 1195,
};

static const struct itemplate * const itable_0F44[] = {
    instrux + 1190,
    instrux + 1191,
    instrux + 1192,
    instrux + 1193,
    instrux + 1194,
    instrux + 1195,
};

static const struct itemplate * const itable_0F45[] = {
    instrux + 1190,
    instrux + 1191,
    instrux + 1192,
    instrux + 1193,
    instrux + 1194,
    instrux + 1195,
};

static const struct itemplate * const itable_0F46[] = {
    instrux + 1190,
    instrux + 1191,
    instrux + 1192,
    instrux + 1193,
    instrux + 1194,
    instrux + 1195,
};

static const struct itemplate * const itable_0F47[] = {
    instrux + 1190,
    instrux + 1191,
    instrux + 1192,
    instrux + 1193,
    instrux + 1194,
    instrux + 1195,
};

static const struct itemplate * const itable_0F48[] = {
    instrux + 1190,
    instrux + 1191,
    instrux + 1192,
    instrux + 1193,
    instrux + 1194,
    instrux + 1195,
};

static const struct itemplate * const itable_0F49[] = {
    instrux + 1190,
    instrux + 1191,
    instrux + 1192,
    instrux + 1193,
    instrux + 1194,
    instrux + 1195,
};

static const struct itemplate * const itable_0F4A[] = {
    instrux + 1190,
    instrux + 1191,
    instrux + 1192,
    instrux + 1193,
    instrux + 1194,
    instrux + 1195,
};

static const struct itemplate * const itable_0F4B[] = {
    instrux + 1190,
    instrux + 1191,
    instrux + 1192,
    instrux + 1193,
    instrux + 1194,
    instrux + 1195,
};

static const struct itemplate * const itable_0F4C[] = {
    instrux + 1190,
    instrux + 1191,
    instrux + 1192,
    instrux + 1193,
    instrux + 1194,
    instrux + 1195,
};

static const struct itemplate * const itable_0F4D[] = {
    instrux + 1190,
    instrux + 1191,
    instrux + 1192,
    instrux + 1193,
    instrux + 1194,
    instrux + 1195,
};

static const struct itemplate * const itable_0F4E[] = {
    instrux + 1190,
    instrux + 1191,
    instrux + 1192,
    instrux + 1193,
    instrux + 1194,
    instrux + 1195,
};

static const struct itemplate * const itable_0F4F[] = {
    instrux + 1190,
    instrux + 1191,
    instrux + 1192,
    instrux + 1193,
    instrux + 1194,
    instrux + 1195,
};

static const struct itemplate * const itable_0F50[] = {
    instrux + 759,
    instrux + 1255,
    instrux + 1256,
    instrux + 1483,
    instrux + 1484,
};

static const struct itemplate * const itable_0F51[] = {
    instrux + 751,
    instrux + 1275,
    instrux + 1276,
    instrux + 1498,
    instrux + 1499,
};

static const struct itemplate * const itable_0F52[] = {
    instrux + 787,
    instrux + 1271,
    instrux + 1272,
};

static const struct itemplate * const itable_0F53[] = {
    instrux + 1269,
    instrux + 1270,
};

static const struct itemplate * const itable_0F54[] = {
    instrux + 767,
    instrux + 1205,
    instrux + 1426,
};

static const struct itemplate * const itable_0F55[] = {
    instrux + 834,
    instrux + 1204,
    instrux + 1425,
};

static const struct itemplate * const itable_0F56[] = {
    instrux + 1268,
    instrux + 1495,
};

static const struct itemplate * const itable_0F57[] = {
    instrux + 1283,
    instrux + 1505,
};

static const struct itemplate * const itable_0F58[] = {
    instrux + 796,
    instrux + 1202,
    instrux + 1203,
    instrux + 1423,
    instrux + 1424,
};

static const struct itemplate * const itable_0F59[] = {
    instrux + 790,
    instrux + 1266,
    instrux + 1267,
    instrux + 1493,
    instrux + 1494,
};

static const struct itemplate * const itable_0F5A[] = {
    instrux + 795,
    instrux + 1450,
    instrux + 1453,
    instrux + 1458,
    instrux + 1461,
};

static const struct itemplate * const itable_0F5B[] = {
    instrux + 794,
    instrux + 1447,
    instrux + 1452,
    instrux + 1464,
};

static const struct itemplate * const itable_0F5C[] = {
    instrux + 793,
    instrux + 1278,
    instrux + 1279,
    instrux + 1500,
    instrux + 1501,
};

static const struct itemplate * const itable_0F5D[] = {
    instrux + 788,
    instrux + 1243,
    instrux + 1244,
    instrux + 1473,
    instrux + 1474,
};

static const struct itemplate * const itable_0F5E[] = {
    instrux + 785,
    instrux + 1238,
    instrux + 1239,
    instrux + 1469,
    instrux + 1470,
};

static const struct itemplate * const itable_0F5F[] = {
    instrux + 1241,
    instrux + 1242,
    instrux + 1471,
    instrux + 1472,
};

static const struct itemplate * const itable_0F60[] = {
    instrux + 842,
    instrux + 1418,
};

static const struct itemplate * const itable_0F61[] = {
    instrux + 844,
    instrux + 1419,
};

static const struct itemplate * const itable_0F62[] = {
    instrux + 843,
    instrux + 1420,
};

static const struct itemplate * const itable_0F63[] = {
    instrux + 746,
    instrux + 1343,
};

static const struct itemplate * const itable_0F64[] = {
    instrux + 764,
    instrux + 1362,
};

static const struct itemplate * const itable_0F65[] = {
    instrux + 766,
    instrux + 1363,
};

static const struct itemplate * const itable_0F66[] = {
    instrux + 765,
    instrux + 1364,
};

static const struct itemplate * const itable_0F67[] = {
    instrux + 747,
    instrux + 1345,
};

static const struct itemplate * const itable_0F68[] = {
    instrux + 839,
    instrux + 1414,
};

static const struct itemplate * const itable_0F69[] = {
    instrux + 841,
    instrux + 1415,
};

static const struct itemplate * const itable_0F6A[] = {
    instrux + 840,
    instrux + 1416,
};

static const struct itemplate * const itable_0F6B[] = {
    instrux + 745,
    instrux + 1344,
};

static const struct itemplate * const itable_0F6C[] = {
    instrux + 1421,
};

static const struct itemplate * const itable_0F6D[] = {
    instrux + 1417,
};

static const struct itemplate * const itable_0F6E[] = {
    instrux + 660,
    instrux + 661,
    instrux + 664,
    instrux + 665,
    instrux + 670,
    instrux + 1323,
    instrux + 1326,
    instrux + 1340,
};

static const struct itemplate * const itable_0F6F[] = {
    instrux + 668,
    instrux + 1327,
    instrux + 1329,
    instrux + 1331,
    instrux + 1333,
};

static const struct itemplate * const itable_0F70[] = {
    instrux + 1309,
    instrux + 1381,
    instrux + 1382,
    instrux + 1383,
    instrux + 1384,
    instrux + 1385,
    instrux + 1386,
};

static const struct itemplate * const itable_0F71[] = {
    instrux + 820,
    instrux + 824,
    instrux + 830,
    instrux + 1389,
    instrux + 1395,
    instrux + 1400,
};

static const struct itemplate * const itable_0F72[] = {
    instrux + 816,
    instrux + 822,
    instrux + 826,
    instrux + 1391,
    instrux + 1397,
    instrux + 1402,
};

static const struct itemplate * const itable_0F73[] = {
    instrux + 818,
    instrux + 828,
    instrux + 1387,
    instrux + 1393,
    instrux + 1398,
    instrux + 1404,
};

static const struct itemplate * const itable_0F74[] = {
    instrux + 761,
    instrux + 1359,
};

static const struct itemplate * const itable_0F75[] = {
    instrux + 763,
    instrux + 1360,
};

static const struct itemplate * const itable_0F76[] = {
    instrux + 762,
    instrux + 1361,
};

static const struct itemplate * const itable_0F77[] = {
    instrux + 250,
};

static const struct itemplate * const itable_0F78[] = {
    instrux + 1083,
    instrux + 1523,
    instrux + 1524,
    instrux + 1568,
    instrux + 1570,
};

static const struct itemplate * const itable_0F79[] = {
    instrux + 926,
    instrux + 1528,
    instrux + 1529,
    instrux + 1569,
    instrux + 1571,
};

static const struct itemplate * const itable_0F7A10[] = {
    instrux + 1901,
};

static const struct itemplate * const itable_0F7A11[] = {
    instrux + 1902,
};

static const struct itemplate * const itable_0F7A12[] = {
    instrux + 1903,
};

static const struct itemplate * const itable_0F7A13[] = {
    instrux + 1904,
};

static const struct itemplate * const itable_0F7A30[] = {
    instrux + 1905,
};

static const struct itemplate * const itable_0F7A31[] = {
    instrux + 1906,
};

static const struct itemplate * const itable_0F7A41[] = {
    instrux + 1907,
};

static const struct itemplate * const itable_0F7A42[] = {
    instrux + 1908,
};

static const struct itemplate * const itable_0F7A43[] = {
    instrux + 1909,
};

static const struct itemplate * const itable_0F7A46[] = {
    instrux + 1910,
};

static const struct itemplate * const itable_0F7A47[] = {
    instrux + 1911,
};

static const struct itemplate * const itable_0F7A4B[] = {
    instrux + 1912,
};

static const struct itemplate * const itable_0F7A51[] = {
    instrux + 1913,
};

static const struct itemplate * const itable_0F7A52[] = {
    instrux + 1914,
};

static const struct itemplate * const itable_0F7A53[] = {
    instrux + 1915,
};

static const struct itemplate * const itable_0F7A56[] = {
    instrux + 1916,
};

static const struct itemplate * const itable_0F7A57[] = {
    instrux + 1917,
};

static const struct itemplate * const itable_0F7A5B[] = {
    instrux + 1918,
};

static const struct itemplate * const itable_0F7A61[] = {
    instrux + 1919,
};

static const struct itemplate * const itable_0F7A62[] = {
    instrux + 1920,
};

static const struct itemplate * const itable_0F7A63[] = {
    instrux + 1921,
};

static const struct itemplate * const itable_0F7B[] = {
    instrux + 927,
    instrux + 1922,
    instrux + 1923,
    instrux + 1924,
    instrux + 1925,
};

static const struct itemplate * const itable_0F7C[] = {
    instrux + 1084,
    instrux + 1508,
    instrux + 1509,
};

static const struct itemplate * const itable_0F7D[] = {
    instrux + 929,
    instrux + 1510,
    instrux + 1511,
};

static const struct itemplate * const itable_0F7E[] = {
    instrux + 662,
    instrux + 663,
    instrux + 666,
    instrux + 667,
    instrux + 671,
    instrux + 1324,
    instrux + 1325,
    instrux + 1336,
    instrux + 1339,
    instrux + 1341,
};

static const struct itemplate * const itable_0F7F[] = {
    instrux + 669,
    instrux + 1328,
    instrux + 1330,
    instrux + 1332,
    instrux + 1334,
};

static const struct itemplate * const itable_0F80[] = {
    instrux + 1196,
    instrux + 1197,
    instrux + 1198,
};

static const struct itemplate * const itable_0F81[] = {
    instrux + 1196,
    instrux + 1197,
    instrux + 1198,
};

static const struct itemplate * const itable_0F82[] = {
    instrux + 1196,
    instrux + 1197,
    instrux + 1198,
};

static const struct itemplate * const itable_0F83[] = {
    instrux + 1196,
    instrux + 1197,
    instrux + 1198,
};

static const struct itemplate * const itable_0F84[] = {
    instrux + 1196,
    instrux + 1197,
    instrux + 1198,
};

static const struct itemplate * const itable_0F85[] = {
    instrux + 1196,
    instrux + 1197,
    instrux + 1198,
};

static const struct itemplate * const itable_0F86[] = {
    instrux + 1196,
    instrux + 1197,
    instrux + 1198,
};

static const struct itemplate * const itable_0F87[] = {
    instrux + 1196,
    instrux + 1197,
    instrux + 1198,
};

static const struct itemplate * const itable_0F88[] = {
    instrux + 1196,
    instrux + 1197,
    instrux + 1198,
};

static const struct itemplate * const itable_0F89[] = {
    instrux + 1196,
    instrux + 1197,
    instrux + 1198,
};

static const struct itemplate * const itable_0F8A[] = {
    instrux + 1196,
    instrux + 1197,
    instrux + 1198,
};

static const struct itemplate * const itable_0F8B[] = {
    instrux + 1196,
    instrux + 1197,
    instrux + 1198,
};

static const struct itemplate * const itable_0F8C[] = {
    instrux + 1196,
    instrux + 1197,
    instrux + 1198,
};

static const struct itemplate * const itable_0F8D[] = {
    instrux + 1196,
    instrux + 1197,
    instrux + 1198,
};

static const struct itemplate * const itable_0F8E[] = {
    instrux + 1196,
    instrux + 1197,
    instrux + 1198,
};

static const struct itemplate * const itable_0F8F[] = {
    instrux + 1196,
    instrux + 1197,
    instrux + 1198,
};

static const struct itemplate * const itable_0F90[] = {
    instrux + 1200,
    instrux + 1201,
};

static const struct itemplate * const itable_0F91[] = {
    instrux + 1200,
    instrux + 1201,
};

static const struct itemplate * const itable_0F92[] = {
    instrux + 1200,
    instrux + 1201,
};

static const struct itemplate * const itable_0F93[] = {
    instrux + 1200,
    instrux + 1201,
};

static const struct itemplate * const itable_0F94[] = {
    instrux + 1200,
    instrux + 1201,
};

static const struct itemplate * const itable_0F95[] = {
    instrux + 1200,
    instrux + 1201,
};

static const struct itemplate * const itable_0F96[] = {
    instrux + 1200,
    instrux + 1201,
};

static const struct itemplate * const itable_0F97[] = {
    instrux + 1200,
    instrux + 1201,
};

static const struct itemplate * const itable_0F98[] = {
    instrux + 1200,
    instrux + 1201,
};

static const struct itemplate * const itable_0F99[] = {
    instrux + 1200,
    instrux + 1201,
};

static const struct itemplate * const itable_0F9A[] = {
    instrux + 1200,
    instrux + 1201,
};

static const struct itemplate * const itable_0F9B[] = {
    instrux + 1200,
    instrux + 1201,
};

static const struct itemplate * const itable_0F9C[] = {
    instrux + 1200,
    instrux + 1201,
};

static const struct itemplate * const itable_0F9D[] = {
    instrux + 1200,
    instrux + 1201,
};

static const struct itemplate * const itable_0F9E[] = {
    instrux + 1200,
    instrux + 1201,
};

static const struct itemplate * const itable_0F9F[] = {
    instrux + 1200,
    instrux + 1201,
};

static const struct itemplate * const itable_0FA0[] = {
    instrux + 853,
};

static const struct itemplate * const itable_0FA1[] = {
    instrux + 804,
};

static const struct itemplate * const itable_0FA2[] = {
    instrux + 231,
};

static const struct itemplate * const itable_0FA3[] = {
    instrux + 115,
    instrux + 116,
    instrux + 117,
    instrux + 118,
    instrux + 119,
    instrux + 120,
};

static const struct itemplate * const itable_0FA4[] = {
    instrux + 992,
    instrux + 993,
    instrux + 994,
    instrux + 995,
    instrux + 996,
    instrux + 997,
};

static const struct itemplate * const itable_0FA5[] = {
    instrux + 998,
    instrux + 999,
    instrux + 1000,
    instrux + 1001,
    instrux + 1002,
    instrux + 1003,
};

static const struct itemplate * const itable_0FA6C0[] = {
    instrux + 3067,
};

static const struct itemplate * const itable_0FA6C8[] = {
    instrux + 3068,
};

static const struct itemplate * const itable_0FA6D0[] = {
    instrux + 3069,
};

static const struct itemplate * const itable_0FA7C0[] = {
    instrux + 3061,
};

static const struct itemplate * const itable_0FA7C8[] = {
    instrux + 3062,
};

static const struct itemplate * const itable_0FA7D0[] = {
    instrux + 3063,
};

static const struct itemplate * const itable_0FA7D8[] = {
    instrux + 3064,
};

static const struct itemplate * const itable_0FA7E0[] = {
    instrux + 3065,
};

static const struct itemplate * const itable_0FA7E8[] = {
    instrux + 3066,
};

static const struct itemplate * const itable_0FA8[] = {
    instrux + 853,
};

static const struct itemplate * const itable_0FA9[] = {
    instrux + 804,
};

static const struct itemplate * const itable_0FAA[] = {
    instrux + 928,
};

static const struct itemplate * const itable_0FAB[] = {
    instrux + 142,
    instrux + 143,
    instrux + 144,
    instrux + 145,
    instrux + 146,
    instrux + 147,
};

static const struct itemplate * const itable_0FAC[] = {
    instrux + 1016,
    instrux + 1017,
    instrux + 1018,
    instrux + 1019,
    instrux + 1020,
    instrux + 1021,
};

static const struct itemplate * const itable_0FAD[] = {
    instrux + 1022,
    instrux + 1023,
    instrux + 1024,
    instrux + 1025,
    instrux + 1026,
    instrux + 1027,
};

static const struct itemplate * const itable_0FAE[] = {
    instrux + 554,
    instrux + 608,
    instrux + 978,
    instrux + 1240,
    instrux + 1277,
    instrux + 1284,
    instrux + 1285,
    instrux + 1288,
    instrux + 1289,
    instrux + 1294,
    instrux + 1316,
    instrux + 1321,
    instrux + 1322,
};

static const struct itemplate * const itable_0FAF[] = {
    instrux + 449,
    instrux + 450,
    instrux + 451,
    instrux + 452,
    instrux + 453,
    instrux + 454,
};

static const struct itemplate * const itable_0FB0[] = {
    instrux + 221,
    instrux + 222,
};

static const struct itemplate * const itable_0FB1[] = {
    instrux + 223,
    instrux + 224,
    instrux + 225,
    instrux + 226,
    instrux + 227,
    instrux + 228,
};

static const struct itemplate * const itable_0FB2[] = {
    instrux + 603,
    instrux + 604,
};

static const struct itemplate * const itable_0FB3[] = {
    instrux + 133,
    instrux + 134,
    instrux + 135,
    instrux + 136,
    instrux + 137,
    instrux + 138,
};

static const struct itemplate * const itable_0FB4[] = {
    instrux + 555,
    instrux + 556,
};

static const struct itemplate * const itable_0FB5[] = {
    instrux + 558,
    instrux + 559,
};

static const struct itemplate * const itable_0FB6[] = {
    instrux + 683,
    instrux + 684,
    instrux + 685,
    instrux + 687,
};

static const struct itemplate * const itable_0FB7[] = {
    instrux + 686,
    instrux + 688,
};

static const struct itemplate * const itable_0FB8[] = {
    instrux + 529,
    instrux + 530,
    instrux + 531,
    instrux + 1642,
    instrux + 1643,
    instrux + 1644,
};

static const struct itemplate * const itable_0FB9[] = {
    instrux + 1114,
};

static const struct itemplate * const itable_0FBA[] = {
    instrux + 121,
    instrux + 122,
    instrux + 123,
    instrux + 130,
    instrux + 131,
    instrux + 132,
    instrux + 139,
    instrux + 140,
    instrux + 141,
    instrux + 148,
    instrux + 149,
    instrux + 150,
};

static const struct itemplate * const itable_0FBB[] = {
    instrux + 124,
    instrux + 125,
    instrux + 126,
    instrux + 127,
    instrux + 128,
    instrux + 129,
};

static const struct itemplate * const itable_0FBC[] = {
    instrux + 101,
    instrux + 102,
    instrux + 103,
    instrux + 104,
    instrux + 105,
    instrux + 106,
};

static const struct itemplate * const itable_0FBD[] = {
    instrux + 107,
    instrux + 108,
    instrux + 109,
    instrux + 110,
    instrux + 111,
    instrux + 112,
    instrux + 1574,
    instrux + 1575,
    instrux + 1576,
};

static const struct itemplate * const itable_0FBE[] = {
    instrux + 676,
    instrux + 677,
    instrux + 678,
    instrux + 680,
};

static const struct itemplate * const itable_0FBF[] = {
    instrux + 679,
    instrux + 681,
};

static const struct itemplate * const itable_0FC0[] = {
    instrux + 1127,
    instrux + 1128,
};

static const struct itemplate * const itable_0FC1[] = {
    instrux + 1129,
    instrux + 1130,
    instrux + 1131,
    instrux + 1132,
    instrux + 1133,
    instrux + 1134,
};

static const struct itemplate * const itable_0FC2[] = {
    instrux + 1206,
    instrux + 1207,
    instrux + 1208,
    instrux + 1209,
    instrux + 1210,
    instrux + 1211,
    instrux + 1212,
    instrux + 1213,
    instrux + 1214,
    instrux + 1215,
    instrux + 1216,
    instrux + 1217,
    instrux + 1218,
    instrux + 1219,
    instrux + 1220,
    instrux + 1221,
    instrux + 1222,
    instrux + 1223,
    instrux + 1224,
    instrux + 1225,
    instrux + 1427,
    instrux + 1428,
    instrux + 1429,
    instrux + 1430,
    instrux + 1431,
    instrux + 1432,
    instrux + 1433,
    instrux + 1434,
    instrux + 1435,
    instrux + 1436,
    instrux + 1437,
    instrux + 1438,
    instrux + 1439,
    instrux + 1440,
    instrux + 1441,
    instrux + 1442,
    instrux + 1443,
    instrux + 1444,
};

static const struct itemplate * const itable_0FC3[] = {
    instrux + 1318,
    instrux + 1319,
};

static const struct itemplate * const itable_0FC4[] = {
    instrux + 1300,
    instrux + 1301,
    instrux + 1366,
    instrux + 1367,
};

static const struct itemplate * const itable_0FC5[] = {
    instrux + 1299,
    instrux + 1365,
};

static const struct itemplate * const itable_0FC6[] = {
    instrux + 1273,
    instrux + 1274,
    instrux + 1496,
    instrux + 1497,
};

static const struct itemplate * const itable_0FC7[] = {
    instrux + 229,
    instrux + 230,
    instrux + 1517,
    instrux + 1521,
    instrux + 1522,
    instrux + 1531,
};

static const struct itemplate * const itable_0FC8[] = {
    instrux + 113,
    instrux + 114,
};

static const struct itemplate * const itable_0FC9[] = {
    instrux + 113,
    instrux + 114,
};

static const struct itemplate * const itable_0FCA[] = {
    instrux + 113,
    instrux + 114,
};

static const struct itemplate * const itable_0FCB[] = {
    instrux + 113,
    instrux + 114,
};

static const struct itemplate * const itable_0FCC[] = {
    instrux + 113,
    instrux + 114,
};

static const struct itemplate * const itable_0FCD[] = {
    instrux + 113,
    instrux + 114,
};

static const struct itemplate * const itable_0FCE[] = {
    instrux + 113,
    instrux + 114,
};

static const struct itemplate * const itable_0FCF[] = {
    instrux + 113,
    instrux + 114,
};

static const struct itemplate * const itable_0FD0[] = {
    instrux + 1506,
    instrux + 1507,
};

static const struct itemplate * const itable_0FD1[] = {
    instrux + 829,
    instrux + 1399,
};

static const struct itemplate * const itable_0FD2[] = {
    instrux + 825,
    instrux + 1401,
};

static const struct itemplate * const itable_0FD3[] = {
    instrux + 827,
    instrux + 1403,
};

static const struct itemplate * const itable_0FD4[] = {
    instrux + 1349,
    instrux + 1350,
};

static const struct itemplate * const itable_0FD5[] = {
    instrux + 792,
    instrux + 1376,
};

static const struct itemplate * const itable_0FD6[] = {
    instrux + 1335,
    instrux + 1337,
    instrux + 1338,
    instrux + 1342,
};

static const struct itemplate * const itable_0FD7[] = {
    instrux + 1306,
    instrux + 1373,
};

static const struct itemplate * const itable_0FD8[] = {
    instrux + 836,
    instrux + 1412,
};

static const struct itemplate * const itable_0FD9[] = {
    instrux + 837,
    instrux + 1413,
};

static const struct itemplate * const itable_0FDA[] = {
    instrux + 1305,
    instrux + 1372,
};

static const struct itemplate * const itable_0FDB[] = {
    instrux + 756,
    instrux + 1355,
};

static const struct itemplate * const itable_0FDC[] = {
    instrux + 753,
    instrux + 1353,
};

static const struct itemplate * const itable_0FDD[] = {
    instrux + 754,
    instrux + 1354,
};

static const struct itemplate * const itable_0FDE[] = {
    instrux + 1303,
    instrux + 1370,
};

static const struct itemplate * const itable_0FDF[] = {
    instrux + 757,
    instrux + 1356,
};

static const struct itemplate * const itable_0FE0[] = {
    instrux + 1297,
    instrux + 1357,
};

static const struct itemplate * const itable_0FE1[] = {
    instrux + 823,
    instrux + 1394,
};

static const struct itemplate * const itable_0FE2[] = {
    instrux + 821,
    instrux + 1396,
};

static const struct itemplate * const itable_0FE3[] = {
    instrux + 1298,
    instrux + 1358,
};

static const struct itemplate * const itable_0FE4[] = {
    instrux + 1307,
    instrux + 1374,
};

static const struct itemplate * const itable_0FE5[] = {
    instrux + 791,
    instrux + 1375,
};

static const struct itemplate * const itable_0FE6[] = {
    instrux + 1446,
    instrux + 1448,
    instrux + 1463,
};

static const struct itemplate * const itable_0FE7[] = {
    instrux + 1296,
    instrux + 1317,
};

static const struct itemplate * const itable_0FE8[] = {
    instrux + 833,
    instrux + 1410,
};

static const struct itemplate * const itable_0FE9[] = {
    instrux + 835,
    instrux + 1411,
};

static const struct itemplate * const itable_0FEA[] = {
    instrux + 1304,
    instrux + 1371,
};

static const struct itemplate * const itable_0FEB[] = {
    instrux + 812,
    instrux + 1379,
};

static const struct itemplate * const itable_0FEC[] = {
    instrux + 750,
    instrux + 1351,
};

static const struct itemplate * const itable_0FED[] = {
    instrux + 752,
    instrux + 1352,
};

static const struct itemplate * const itable_0FEE[] = {
    instrux + 1302,
    instrux + 1369,
};

static const struct itemplate * const itable_0FEF[] = {
    instrux + 866,
    instrux + 1422,
};

static const struct itemplate * const itable_0FF0[] = {
    instrux + 1512,
};

static const struct itemplate * const itable_0FF1[] = {
    instrux + 819,
    instrux + 1388,
};

static const struct itemplate * const itable_0FF2[] = {
    instrux + 815,
    instrux + 1390,
};

static const struct itemplate * const itable_0FF3[] = {
    instrux + 817,
    instrux + 1392,
};

static const struct itemplate * const itable_0FF4[] = {
    instrux + 1377,
    instrux + 1378,
};

static const struct itemplate * const itable_0FF5[] = {
    instrux + 786,
    instrux + 1368,
};

static const struct itemplate * const itable_0FF6[] = {
    instrux + 1308,
    instrux + 1380,
};

static const struct itemplate * const itable_0FF7[] = {
    instrux + 1295,
    instrux + 1315,
};

static const struct itemplate * const itable_0FF8[] = {
    instrux + 831,
    instrux + 1405,
};

static const struct itemplate * const itable_0FF9[] = {
    instrux + 838,
    instrux + 1406,
};

static const struct itemplate * const itable_0FFA[] = {
    instrux + 832,
    instrux + 1407,
};

static const struct itemplate * const itable_0FFB[] = {
    instrux + 1408,
    instrux + 1409,
};

static const struct itemplate * const itable_0FFC[] = {
    instrux + 748,
    instrux + 1346,
};

static const struct itemplate * const itable_0FFD[] = {
    instrux + 755,
    instrux + 1347,
};

static const struct itemplate * const itable_0FFE[] = {
    instrux + 749,
    instrux + 1348,
};

static const struct itemplate * const itable_0FFF[] = {
    instrux + 1113,
};

static const struct itemplate * const itable_10[] = {
    instrux + 7,
    instrux + 8,
};

static const struct itemplate * const itable_11[] = {
    instrux + 9,
    instrux + 10,
    instrux + 11,
    instrux + 12,
    instrux + 13,
    instrux + 14,
};

static const struct itemplate * const itable_12[] = {
    instrux + 15,
    instrux + 16,
};

static const struct itemplate * const itable_13[] = {
    instrux + 17,
    instrux + 18,
    instrux + 19,
    instrux + 20,
    instrux + 21,
    instrux + 22,
};

static const struct itemplate * const itable_14[] = {
    instrux + 26,
};

static const struct itemplate * const itable_15[] = {
    instrux + 27,
    instrux + 28,
    instrux + 29,
};

static const struct itemplate * const itable_16[] = {
    instrux + 851,
    instrux + 852,
};

static const struct itemplate * const itable_17[] = {
    instrux + 803,
};

static const struct itemplate * const itable_18[] = {
    instrux + 944,
    instrux + 945,
};

static const struct itemplate * const itable_19[] = {
    instrux + 946,
    instrux + 947,
    instrux + 948,
    instrux + 949,
    instrux + 950,
    instrux + 951,
};

static const struct itemplate * const itable_1A[] = {
    instrux + 952,
    instrux + 953,
};

static const struct itemplate * const itable_1B[] = {
    instrux + 954,
    instrux + 955,
    instrux + 956,
    instrux + 957,
    instrux + 958,
    instrux + 959,
};

static const struct itemplate * const itable_1C[] = {
    instrux + 963,
};

static const struct itemplate * const itable_1D[] = {
    instrux + 964,
    instrux + 965,
    instrux + 966,
};

static const struct itemplate * const itable_1E[] = {
    instrux + 851,
    instrux + 852,
};

static const struct itemplate * const itable_1F[] = {
    instrux + 803,
};

static const struct itemplate * const itable_20[] = {
    instrux + 67,
    instrux + 68,
};

static const struct itemplate * const itable_21[] = {
    instrux + 69,
    instrux + 70,
    instrux + 71,
    instrux + 72,
    instrux + 73,
    instrux + 74,
};

static const struct itemplate * const itable_22[] = {
    instrux + 75,
    instrux + 76,
};

static const struct itemplate * const itable_23[] = {
    instrux + 77,
    instrux + 78,
    instrux + 79,
    instrux + 80,
    instrux + 81,
    instrux + 82,
};

static const struct itemplate * const itable_24[] = {
    instrux + 86,
};

static const struct itemplate * const itable_25[] = {
    instrux + 87,
    instrux + 88,
    instrux + 89,
};

static const struct itemplate * const itable_27[] = {
    instrux + 237,
};

static const struct itemplate * const itable_28[] = {
    instrux + 1053,
    instrux + 1054,
};

static const struct itemplate * const itable_29[] = {
    instrux + 1055,
    instrux + 1056,
    instrux + 1057,
    instrux + 1058,
    instrux + 1059,
    instrux + 1060,
};

static const struct itemplate * const itable_2A[] = {
    instrux + 1061,
    instrux + 1062,
};

static const struct itemplate * const itable_2B[] = {
    instrux + 1063,
    instrux + 1064,
    instrux + 1065,
    instrux + 1066,
    instrux + 1067,
    instrux + 1068,
};

static const struct itemplate * const itable_2C[] = {
    instrux + 1072,
};

static const struct itemplate * const itable_2D[] = {
    instrux + 1073,
    instrux + 1074,
    instrux + 1075,
};

static const struct itemplate * const itable_2F[] = {
    instrux + 238,
};

static const struct itemplate * const itable_30[] = {
    instrux + 1160,
    instrux + 1161,
};

static const struct itemplate * const itable_31[] = {
    instrux + 1162,
    instrux + 1163,
    instrux + 1164,
    instrux + 1165,
    instrux + 1166,
    instrux + 1167,
};

static const struct itemplate * const itable_32[] = {
    instrux + 1168,
    instrux + 1169,
};

static const struct itemplate * const itable_33[] = {
    instrux + 1170,
    instrux + 1171,
    instrux + 1172,
    instrux + 1173,
    instrux + 1174,
    instrux + 1175,
};

static const struct itemplate * const itable_34[] = {
    instrux + 1179,
};

static const struct itemplate * const itable_35[] = {
    instrux + 1180,
    instrux + 1181,
    instrux + 1182,
};

static const struct itemplate * const itable_37[] = {
    instrux + 1,
};

static const struct itemplate * const itable_38[] = {
    instrux + 187,
    instrux + 188,
};

static const struct itemplate * const itable_39[] = {
    instrux + 189,
    instrux + 190,
    instrux + 191,
    instrux + 192,
    instrux + 193,
    instrux + 194,
};

static const struct itemplate * const itable_3A[] = {
    instrux + 195,
    instrux + 196,
};

static const struct itemplate * const itable_3B[] = {
    instrux + 197,
    instrux + 198,
    instrux + 199,
    instrux + 200,
    instrux + 201,
    instrux + 202,
};

static const struct itemplate * const itable_3C[] = {
    instrux + 206,
};

static const struct itemplate * const itable_3D[] = {
    instrux + 207,
    instrux + 208,
    instrux + 209,
};

static const struct itemplate * const itable_3F[] = {
    instrux + 6,
};

static const struct itemplate * const itable_40[] = {
    instrux + 479,
    instrux + 480,
};

static const struct itemplate * const itable_41[] = {
    instrux + 479,
    instrux + 480,
};

static const struct itemplate * const itable_42[] = {
    instrux + 479,
    instrux + 480,
};

static const struct itemplate * const itable_43[] = {
    instrux + 479,
    instrux + 480,
};

static const struct itemplate * const itable_44[] = {
    instrux + 479,
    instrux + 480,
};

static const struct itemplate * const itable_45[] = {
    instrux + 479,
    instrux + 480,
};

static const struct itemplate * const itable_46[] = {
    instrux + 479,
    instrux + 480,
};

static const struct itemplate * const itable_47[] = {
    instrux + 479,
    instrux + 480,
};

static const struct itemplate * const itable_48[] = {
    instrux + 239,
    instrux + 240,
};

static const struct itemplate * const itable_49[] = {
    instrux + 239,
    instrux + 240,
};

static const struct itemplate * const itable_4A[] = {
    instrux + 239,
    instrux + 240,
};

static const struct itemplate * const itable_4B[] = {
    instrux + 239,
    instrux + 240,
};

static const struct itemplate * const itable_4C[] = {
    instrux + 239,
    instrux + 240,
};

static const struct itemplate * const itable_4D[] = {
    instrux + 239,
    instrux + 240,
};

static const struct itemplate * const itable_4E[] = {
    instrux + 239,
    instrux + 240,
};

static const struct itemplate * const itable_4F[] = {
    instrux + 239,
    instrux + 240,
};

static const struct itemplate * const itable_50[] = {
    instrux + 845,
    instrux + 846,
    instrux + 847,
};

static const struct itemplate * const itable_51[] = {
    instrux + 845,
    instrux + 846,
    instrux + 847,
};

static const struct itemplate * const itable_52[] = {
    instrux + 845,
    instrux + 846,
    instrux + 847,
};

static const struct itemplate * const itable_53[] = {
    instrux + 845,
    instrux + 846,
    instrux + 847,
};

static const struct itemplate * const itable_54[] = {
    instrux + 845,
    instrux + 846,
    instrux + 847,
};

static const struct itemplate * const itable_55[] = {
    instrux + 845,
    instrux + 846,
    instrux + 847,
};

static const struct itemplate * const itable_56[] = {
    instrux + 845,
    instrux + 846,
    instrux + 847,
};

static const struct itemplate * const itable_57[] = {
    instrux + 845,
    instrux + 846,
    instrux + 847,
};

static const struct itemplate * const itable_58[] = {
    instrux + 797,
    instrux + 798,
    instrux + 799,
};

static const struct itemplate * const itable_59[] = {
    instrux + 797,
    instrux + 798,
    instrux + 799,
};

static const struct itemplate * const itable_5A[] = {
    instrux + 797,
    instrux + 798,
    instrux + 799,
};

static const struct itemplate * const itable_5B[] = {
    instrux + 797,
    instrux + 798,
    instrux + 799,
};

static const struct itemplate * const itable_5C[] = {
    instrux + 797,
    instrux + 798,
    instrux + 799,
};

static const struct itemplate * const itable_5D[] = {
    instrux + 797,
    instrux + 798,
    instrux + 799,
};

static const struct itemplate * const itable_5E[] = {
    instrux + 797,
    instrux + 798,
    instrux + 799,
};

static const struct itemplate * const itable_5F[] = {
    instrux + 797,
    instrux + 798,
    instrux + 799,
};

static const struct itemplate * const itable_60[] = {
    instrux + 859,
    instrux + 860,
    instrux + 861,
};

static const struct itemplate * const itable_61[] = {
    instrux + 805,
    instrux + 806,
    instrux + 807,
};

static const struct itemplate * const itable_62[] = {
    instrux + 99,
    instrux + 100,
};

static const struct itemplate * const itable_63[] = {
    instrux + 97,
    instrux + 98,
    instrux + 682,
};

static const struct itemplate * const itable_68[] = {
    instrux + 855,
    instrux + 856,
    instrux + 857,
    instrux + 858,
};

static const struct itemplate * const itable_69[] = {
    instrux + 456,
    instrux + 458,
    instrux + 460,
    instrux + 462,
    instrux + 464,
    instrux + 466,
    instrux + 468,
    instrux + 470,
    instrux + 472,
};

static const struct itemplate * const itable_6A[] = {
    instrux + 854,
    instrux + 855,
    instrux + 856,
    instrux + 857,
    instrux + 858,
};

static const struct itemplate * const itable_6B[] = {
    instrux + 455,
    instrux + 457,
    instrux + 459,
    instrux + 461,
    instrux + 463,
    instrux + 465,
    instrux + 467,
    instrux + 469,
    instrux + 471,
};

static const struct itemplate * const itable_6C[] = {
    instrux + 485,
};

static const struct itemplate * const itable_6D[] = {
    instrux + 486,
    instrux + 487,
};

static const struct itemplate * const itable_6E[] = {
    instrux + 742,
};

static const struct itemplate * const itable_6F[] = {
    instrux + 743,
    instrux + 744,
};

static const struct itemplate * const itable_70[] = {
    instrux + 1199,
};

static const struct itemplate * const itable_71[] = {
    instrux + 1199,
};

static const struct itemplate * const itable_72[] = {
    instrux + 1199,
};

static const struct itemplate * const itable_73[] = {
    instrux + 1199,
};

static const struct itemplate * const itable_74[] = {
    instrux + 1199,
};

static const struct itemplate * const itable_75[] = {
    instrux + 1199,
};

static const struct itemplate * const itable_76[] = {
    instrux + 1199,
};

static const struct itemplate * const itable_77[] = {
    instrux + 1199,
};

static const struct itemplate * const itable_78[] = {
    instrux + 1199,
};

static const struct itemplate * const itable_79[] = {
    instrux + 1199,
};

static const struct itemplate * const itable_7A[] = {
    instrux + 1199,
};

static const struct itemplate * const itable_7B[] = {
    instrux + 1199,
};

static const struct itemplate * const itable_7C[] = {
    instrux + 1199,
};

static const struct itemplate * const itable_7D[] = {
    instrux + 1199,
};

static const struct itemplate * const itable_7E[] = {
    instrux + 1199,
};

static const struct itemplate * const itable_7F[] = {
    instrux + 1199,
};

static const struct itemplate * const itable_80[] = {
    instrux + 30,
    instrux + 34,
    instrux + 60,
    instrux + 64,
    instrux + 90,
    instrux + 94,
    instrux + 210,
    instrux + 214,
    instrux + 729,
    instrux + 733,
    instrux + 967,
    instrux + 971,
    instrux + 1076,
    instrux + 1080,
    instrux + 1183,
    instrux + 1187,
};

static const struct itemplate * const itable_81[] = {
    instrux + 31,
    instrux + 32,
    instrux + 33,
    instrux + 35,
    instrux + 36,
    instrux + 61,
    instrux + 62,
    instrux + 63,
    instrux + 65,
    instrux + 66,
    instrux + 91,
    instrux + 92,
    instrux + 93,
    instrux + 95,
    instrux + 96,
    instrux + 211,
    instrux + 212,
    instrux + 213,
    instrux + 215,
    instrux + 216,
    instrux + 730,
    instrux + 731,
    instrux + 732,
    instrux + 734,
    instrux + 735,
    instrux + 968,
    instrux + 969,
    instrux + 970,
    instrux + 972,
    instrux + 973,
    instrux + 1077,
    instrux + 1078,
    instrux + 1079,
    instrux + 1081,
    instrux + 1082,
    instrux + 1184,
    instrux + 1185,
    instrux + 1186,
    instrux + 1188,
    instrux + 1189,
};

static const struct itemplate * const itable_83[] = {
    instrux + 23,
    instrux + 24,
    instrux + 25,
    instrux + 31,
    instrux + 32,
    instrux + 33,
    instrux + 35,
    instrux + 36,
    instrux + 53,
    instrux + 54,
    instrux + 55,
    instrux + 61,
    instrux + 62,
    instrux + 63,
    instrux + 65,
    instrux + 66,
    instrux + 83,
    instrux + 84,
    instrux + 85,
    instrux + 91,
    instrux + 92,
    instrux + 93,
    instrux + 95,
    instrux + 96,
    instrux + 203,
    instrux + 204,
    instrux + 205,
    instrux + 211,
    instrux + 212,
    instrux + 213,
    instrux + 215,
    instrux + 216,
    instrux + 722,
    instrux + 723,
    instrux + 724,
    instrux + 730,
    instrux + 731,
    instrux + 732,
    instrux + 734,
    instrux + 735,
    instrux + 960,
    instrux + 961,
    instrux + 962,
    instrux + 968,
    instrux + 969,
    instrux + 970,
    instrux + 972,
    instrux + 973,
    instrux + 1069,
    instrux + 1070,
    instrux + 1071,
    instrux + 1077,
    instrux + 1078,
    instrux + 1079,
    instrux + 1081,
    instrux + 1082,
    instrux + 1176,
    instrux + 1177,
    instrux + 1178,
    instrux + 1184,
    instrux + 1185,
    instrux + 1186,
    instrux + 1188,
    instrux + 1189,
};

static const struct itemplate * const itable_84[] = {
    instrux + 1090,
    instrux + 1091,
    instrux + 1098,
};

static const struct itemplate * const itable_85[] = {
    instrux + 1092,
    instrux + 1093,
    instrux + 1094,
    instrux + 1095,
    instrux + 1096,
    instrux + 1097,
    instrux + 1099,
    instrux + 1100,
    instrux + 1101,
};

static const struct itemplate * const itable_86[] = {
    instrux + 1142,
    instrux + 1143,
    instrux + 1150,
    instrux + 1151,
};

static const struct itemplate * const itable_87[] = {
    instrux + 1144,
    instrux + 1145,
    instrux + 1146,
    instrux + 1147,
    instrux + 1148,
    instrux + 1149,
    instrux + 1152,
    instrux + 1153,
    instrux + 1154,
    instrux + 1155,
    instrux + 1156,
    instrux + 1157,
};

static const struct itemplate * const itable_88[] = {
    instrux + 632,
    instrux + 633,
};

static const struct itemplate * const itable_89[] = {
    instrux + 634,
    instrux + 635,
    instrux + 636,
    instrux + 637,
    instrux + 638,
    instrux + 639,
};

static const struct itemplate * const itable_8A[] = {
    instrux + 640,
    instrux + 641,
};

static const struct itemplate * const itable_8B[] = {
    instrux + 642,
    instrux + 643,
    instrux + 644,
    instrux + 645,
    instrux + 646,
    instrux + 647,
};

static const struct itemplate * const itable_8C[] = {
    instrux + 610,
    instrux + 611,
    instrux + 612,
};

static const struct itemplate * const itable_8D[] = {
    instrux + 548,
    instrux + 549,
    instrux + 550,
};

static const struct itemplate * const itable_8E[] = {
    instrux + 613,
    instrux + 614,
    instrux + 615,
};

static const struct itemplate * const itable_8F[] = {
    instrux + 800,
    instrux + 801,
    instrux + 802,
};

static const struct itemplate * const itable_90[] = {
    instrux + 698,
    instrux + 758,
    instrux + 1135,
    instrux + 1136,
    instrux + 1137,
    instrux + 1138,
    instrux + 1139,
    instrux + 1140,
    instrux + 1141,
};

static const struct itemplate * const itable_91[] = {
    instrux + 1135,
    instrux + 1136,
    instrux + 1137,
    instrux + 1138,
    instrux + 1139,
    instrux + 1140,
};

static const struct itemplate * const itable_92[] = {
    instrux + 1135,
    instrux + 1136,
    instrux + 1137,
    instrux + 1138,
    instrux + 1139,
    instrux + 1140,
};

static const struct itemplate * const itable_93[] = {
    instrux + 1135,
    instrux + 1136,
    instrux + 1137,
    instrux + 1138,
    instrux + 1139,
    instrux + 1140,
};

static const struct itemplate * const itable_94[] = {
    instrux + 1135,
    instrux + 1136,
    instrux + 1137,
    instrux + 1138,
    instrux + 1139,
    instrux + 1140,
};

static const struct itemplate * const itable_95[] = {
    instrux + 1135,
    instrux + 1136,
    instrux + 1137,
    instrux + 1138,
    instrux + 1139,
    instrux + 1140,
};

static const struct itemplate * const itable_96[] = {
    instrux + 1135,
    instrux + 1136,
    instrux + 1137,
    instrux + 1138,
    instrux + 1139,
    instrux + 1140,
};

static const struct itemplate * const itable_97[] = {
    instrux + 1135,
    instrux + 1136,
    instrux + 1137,
    instrux + 1138,
    instrux + 1139,
    instrux + 1140,
};

static const struct itemplate * const itable_98[] = {
    instrux + 178,
    instrux + 180,
    instrux + 236,
};

static const struct itemplate * const itable_99[] = {
    instrux + 179,
    instrux + 234,
    instrux + 235,
};

static const struct itemplate * const itable_9A[] = {
    instrux + 157,
    instrux + 158,
    instrux + 159,
    instrux + 160,
    instrux + 161,
};

static const struct itemplate * const itable_9B[] = {
    instrux + 269,
    instrux + 301,
    instrux + 319,
    instrux + 340,
    instrux + 390,
    instrux + 399,
    instrux + 400,
    instrux + 405,
    instrux + 406,
    instrux + 1122,
    instrux + 1123,
};

static const struct itemplate * const itable_9C[] = {
    instrux + 862,
    instrux + 863,
    instrux + 864,
    instrux + 865,
};

static const struct itemplate * const itable_9D[] = {
    instrux + 808,
    instrux + 809,
    instrux + 810,
    instrux + 811,
};

static const struct itemplate * const itable_9E[] = {
    instrux + 930,
};

static const struct itemplate * const itable_9F[] = {
    instrux + 535,
};

static const struct itemplate * const itable_A0[] = {
    instrux + 616,
};

static const struct itemplate * const itable_A1[] = {
    instrux + 617,
    instrux + 618,
    instrux + 619,
};

static const struct itemplate * const itable_A2[] = {
    instrux + 620,
};

static const struct itemplate * const itable_A3[] = {
    instrux + 621,
    instrux + 622,
    instrux + 623,
};

static const struct itemplate * const itable_A4[] = {
    instrux + 672,
};

static const struct itemplate * const itable_A5[] = {
    instrux + 673,
    instrux + 674,
    instrux + 675,
};

static const struct itemplate * const itable_A6[] = {
    instrux + 217,
};

static const struct itemplate * const itable_A7[] = {
    instrux + 218,
    instrux + 219,
    instrux + 220,
};

static const struct itemplate * const itable_A8[] = {
    instrux + 1102,
};

static const struct itemplate * const itable_A9[] = {
    instrux + 1103,
    instrux + 1104,
    instrux + 1105,
};

static const struct itemplate * const itable_AA[] = {
    instrux + 1044,
};

static const struct itemplate * const itable_AB[] = {
    instrux + 1045,
    instrux + 1046,
    instrux + 1047,
};

static const struct itemplate * const itable_AC[] = {
    instrux + 569,
};

static const struct itemplate * const itable_AD[] = {
    instrux + 570,
    instrux + 571,
    instrux + 572,
};

static const struct itemplate * const itable_AE[] = {
    instrux + 974,
};

static const struct itemplate * const itable_AF[] = {
    instrux + 975,
    instrux + 976,
    instrux + 977,
};

static const struct itemplate * const itable_B0[] = {
    instrux + 648,
};

static const struct itemplate * const itable_B1[] = {
    instrux + 648,
};

static const struct itemplate * const itable_B2[] = {
    instrux + 648,
};

static const struct itemplate * const itable_B3[] = {
    instrux + 648,
};

static const struct itemplate * const itable_B4[] = {
    instrux + 648,
};

static const struct itemplate * const itable_B5[] = {
    instrux + 648,
};

static const struct itemplate * const itable_B6[] = {
    instrux + 648,
};

static const struct itemplate * const itable_B7[] = {
    instrux + 648,
};

static const struct itemplate * const itable_B8[] = {
    instrux + 649,
    instrux + 650,
    instrux + 651,
};

static const struct itemplate * const itable_B9[] = {
    instrux + 649,
    instrux + 650,
    instrux + 651,
};

static const struct itemplate * const itable_BA[] = {
    instrux + 649,
    instrux + 650,
    instrux + 651,
};

static const struct itemplate * const itable_BB[] = {
    instrux + 649,
    instrux + 650,
    instrux + 651,
};

static const struct itemplate * const itable_BC[] = {
    instrux + 649,
    instrux + 650,
    instrux + 651,
};

static const struct itemplate * const itable_BD[] = {
    instrux + 649,
    instrux + 650,
    instrux + 651,
};

static const struct itemplate * const itable_BE[] = {
    instrux + 649,
    instrux + 650,
    instrux + 651,
};

static const struct itemplate * const itable_BF[] = {
    instrux + 649,
    instrux + 650,
    instrux + 651,
};

static const struct itemplate * const itable_C0[] = {
    instrux + 869,
    instrux + 881,
    instrux + 904,
    instrux + 916,
    instrux + 934,
    instrux + 982,
    instrux + 1006,
};

static const struct itemplate * const itable_C1[] = {
    instrux + 872,
    instrux + 875,
    instrux + 878,
    instrux + 884,
    instrux + 887,
    instrux + 890,
    instrux + 907,
    instrux + 910,
    instrux + 913,
    instrux + 919,
    instrux + 922,
    instrux + 925,
    instrux + 937,
    instrux + 940,
    instrux + 943,
    instrux + 985,
    instrux + 988,
    instrux + 991,
    instrux + 1009,
    instrux + 1012,
    instrux + 1015,
};

static const struct itemplate * const itable_C2[] = {
    instrux + 897,
    instrux + 901,
};

static const struct itemplate * const itable_C3[] = {
    instrux + 896,
    instrux + 900,
};

static const struct itemplate * const itable_C4[] = {
    instrux + 552,
    instrux + 553,
};

static const struct itemplate * const itable_C5[] = {
    instrux + 546,
    instrux + 547,
};

static const struct itemplate * const itable_C6[] = {
    instrux + 653,
    instrux + 657,
};

static const struct itemplate * const itable_C7[] = {
    instrux + 652,
    instrux + 654,
    instrux + 655,
    instrux + 656,
    instrux + 658,
    instrux + 659,
};

static const struct itemplate * const itable_C8[] = {
    instrux + 251,
};

static const struct itemplate * const itable_C9[] = {
    instrux + 551,
};

static const struct itemplate * const itable_CA[] = {
    instrux + 899,
};

static const struct itemplate * const itable_CB[] = {
    instrux + 898,
};

static const struct itemplate * const itable_CC[] = {
    instrux + 490,
};

static const struct itemplate * const itable_CD[] = {
    instrux + 488,
};

static const struct itemplate * const itable_CE[] = {
    instrux + 491,
};

static const struct itemplate * const itable_CF[] = {
    instrux + 498,
    instrux + 499,
    instrux + 500,
    instrux + 501,
};

static const struct itemplate * const itable_D0[] = {
    instrux + 867,
    instrux + 879,
    instrux + 902,
    instrux + 914,
    instrux + 932,
    instrux + 980,
    instrux + 1004,
};

static const struct itemplate * const itable_D1[] = {
    instrux + 870,
    instrux + 873,
    instrux + 876,
    instrux + 882,
    instrux + 885,
    instrux + 888,
    instrux + 905,
    instrux + 908,
    instrux + 911,
    instrux + 917,
    instrux + 920,
    instrux + 923,
    instrux + 935,
    instrux + 938,
    instrux + 941,
    instrux + 983,
    instrux + 986,
    instrux + 989,
    instrux + 1007,
    instrux + 1010,
    instrux + 1013,
};

static const struct itemplate * const itable_D2[] = {
    instrux + 868,
    instrux + 880,
    instrux + 903,
    instrux + 915,
    instrux + 933,
    instrux + 981,
    instrux + 1005,
};

static const struct itemplate * const itable_D3[] = {
    instrux + 871,
    instrux + 874,
    instrux + 877,
    instrux + 883,
    instrux + 886,
    instrux + 889,
    instrux + 906,
    instrux + 909,
    instrux + 912,
    instrux + 918,
    instrux + 921,
    instrux + 924,
    instrux + 936,
    instrux + 939,
    instrux + 942,
    instrux + 984,
    instrux + 987,
    instrux + 990,
    instrux + 1008,
    instrux + 1011,
    instrux + 1014,
};

static const struct itemplate * const itable_D4[] = {
    instrux + 4,
    instrux + 5,
};

static const struct itemplate * const itable_D5[] = {
    instrux + 2,
    instrux + 3,
};

static const struct itemplate * const itable_D6[] = {
    instrux + 931,
};

static const struct itemplate * const itable_D7[] = {
    instrux + 1158,
    instrux + 1159,
};

static const struct itemplate * const itable_D8[] = {
    instrux + 256,
    instrux + 259,
    instrux + 261,
    instrux + 286,
    instrux + 288,
    instrux + 289,
    instrux + 294,
    instrux + 296,
    instrux + 297,
    instrux + 302,
    instrux + 305,
    instrux + 307,
    instrux + 310,
    instrux + 314,
    instrux + 315,
    instrux + 366,
    instrux + 370,
    instrux + 371,
    instrux + 407,
    instrux + 411,
    instrux + 412,
    instrux + 415,
    instrux + 419,
    instrux + 420,
};

static const struct itemplate * const itable_D9[] = {
    instrux + 254,
    instrux + 255,
    instrux + 268,
    instrux + 299,
    instrux + 300,
    instrux + 339,
    instrux + 353,
    instrux + 356,
    instrux + 357,
    instrux + 358,
    instrux + 359,
    instrux + 360,
    instrux + 361,
    instrux + 362,
    instrux + 363,
    instrux + 364,
    instrux + 365,
    instrux + 378,
    instrux + 380,
    instrux + 381,
    instrux + 384,
    instrux + 385,
    instrux + 386,
    instrux + 387,
    instrux + 388,
    instrux + 391,
    instrux + 393,
    instrux + 394,
    instrux + 395,
    instrux + 396,
    instrux + 401,
    instrux + 423,
    instrux + 433,
    instrux + 434,
    instrux + 435,
    instrux + 436,
    instrux + 437,
    instrux + 438,
    instrux + 439,
};

static const struct itemplate * const itable_DA[] = {
    instrux + 270,
    instrux + 271,
    instrux + 272,
    instrux + 273,
    instrux + 274,
    instrux + 275,
    instrux + 284,
    instrux + 285,
    instrux + 324,
    instrux + 326,
    instrux + 328,
    instrux + 330,
    instrux + 332,
    instrux + 337,
    instrux + 349,
    instrux + 351,
    instrux + 432,
};

static const struct itemplate * const itable_DB[] = {
    instrux + 276,
    instrux + 277,
    instrux + 278,
    instrux + 279,
    instrux + 280,
    instrux + 281,
    instrux + 282,
    instrux + 283,
    instrux + 290,
    instrux + 291,
    instrux + 334,
    instrux + 341,
    instrux + 343,
    instrux + 347,
    instrux + 355,
    instrux + 374,
    instrux + 375,
    instrux + 376,
    instrux + 377,
    instrux + 392,
    instrux + 403,
    instrux + 426,
    instrux + 427,
};

static const struct itemplate * const itable_DC[] = {
    instrux + 257,
    instrux + 258,
    instrux + 260,
    instrux + 287,
    instrux + 295,
    instrux + 303,
    instrux + 304,
    instrux + 306,
    instrux + 311,
    instrux + 312,
    instrux + 313,
    instrux + 367,
    instrux + 368,
    instrux + 369,
    instrux + 408,
    instrux + 409,
    instrux + 410,
    instrux + 416,
    instrux + 417,
    instrux + 418,
};

static const struct itemplate * const itable_DD[] = {
    instrux + 320,
    instrux + 321,
    instrux + 348,
    instrux + 354,
    instrux + 379,
    instrux + 382,
    instrux + 389,
    instrux + 397,
    instrux + 398,
    instrux + 402,
    instrux + 404,
    instrux + 424,
    instrux + 425,
    instrux + 430,
    instrux + 431,
};

static const struct itemplate * const itable_DE[] = {
    instrux + 262,
    instrux + 263,
    instrux + 298,
    instrux + 308,
    instrux + 309,
    instrux + 316,
    instrux + 317,
    instrux + 325,
    instrux + 327,
    instrux + 329,
    instrux + 331,
    instrux + 333,
    instrux + 338,
    instrux + 350,
    instrux + 352,
    instrux + 372,
    instrux + 373,
    instrux + 413,
    instrux + 414,
    instrux + 421,
    instrux + 422,
};

static const struct itemplate * const itable_DF[] = {
    instrux + 264,
    instrux + 265,
    instrux + 266,
    instrux + 267,
    instrux + 292,
    instrux + 293,
    instrux + 322,
    instrux + 323,
    instrux + 335,
    instrux + 336,
    instrux + 342,
    instrux + 344,
    instrux + 345,
    instrux + 346,
    instrux + 383,
    instrux + 428,
    instrux + 429,
};

static const struct itemplate * const itable_E0[] = {
    instrux + 581,
    instrux + 582,
    instrux + 583,
    instrux + 584,
    instrux + 585,
    instrux + 586,
    instrux + 587,
    instrux + 588,
};

static const struct itemplate * const itable_E1[] = {
    instrux + 577,
    instrux + 578,
    instrux + 579,
    instrux + 580,
    instrux + 589,
    instrux + 590,
    instrux + 591,
    instrux + 592,
};

static const struct itemplate * const itable_E2[] = {
    instrux + 573,
    instrux + 574,
    instrux + 575,
    instrux + 576,
};

static const struct itemplate * const itable_E3[] = {
    instrux + 502,
    instrux + 503,
    instrux + 534,
};

static const struct itemplate * const itable_E4[] = {
    instrux + 473,
};

static const struct itemplate * const itable_E5[] = {
    instrux + 474,
    instrux + 475,
};

static const struct itemplate * const itable_E6[] = {
    instrux + 736,
};

static const struct itemplate * const itable_E7[] = {
    instrux + 737,
    instrux + 738,
};

static const struct itemplate * const itable_E8[] = {
    instrux + 151,
    instrux + 152,
    instrux + 153,
    instrux + 154,
    instrux + 155,
    instrux + 156,
};

static const struct itemplate * const itable_E9[] = {
    instrux + 505,
    instrux + 506,
    instrux + 507,
};

static const struct itemplate * const itable_EA[] = {
    instrux + 508,
    instrux + 509,
    instrux + 510,
    instrux + 511,
    instrux + 512,
};

static const struct itemplate * const itable_EB[] = {
    instrux + 504,
};

static const struct itemplate * const itable_EC[] = {
    instrux + 476,
};

static const struct itemplate * const itable_ED[] = {
    instrux + 477,
    instrux + 478,
};

static const struct itemplate * const itable_EE[] = {
    instrux + 739,
};

static const struct itemplate * const itable_EF[] = {
    instrux + 740,
    instrux + 741,
};

static const struct itemplate * const itable_F1[] = {
    instrux + 489,
    instrux + 1035,
};

static const struct itemplate * const itable_F4[] = {
    instrux + 440,
};

static const struct itemplate * const itable_F5[] = {
    instrux + 186,
};

static const struct itemplate * const itable_F6[] = {
    instrux + 245,
    instrux + 441,
    instrux + 445,
    instrux + 689,
    instrux + 694,
    instrux + 702,
    instrux + 1106,
    instrux + 1110,
};

static const struct itemplate * const itable_F7[] = {
    instrux + 246,
    instrux + 247,
    instrux + 248,
    instrux + 442,
    instrux + 443,
    instrux + 444,
    instrux + 446,
    instrux + 447,
    instrux + 448,
    instrux + 690,
    instrux + 691,
    instrux + 692,
    instrux + 695,
    instrux + 696,
    instrux + 697,
    instrux + 703,
    instrux + 704,
    instrux + 705,
    instrux + 1107,
    instrux + 1108,
    instrux + 1109,
    instrux + 1111,
    instrux + 1112,
};

static const struct itemplate * const itable_F8[] = {
    instrux + 181,
};

static const struct itemplate * const itable_F9[] = {
    instrux + 1040,
};

static const struct itemplate * const itable_FA[] = {
    instrux + 184,
};

static const struct itemplate * const itable_FB[] = {
    instrux + 1043,
};

static const struct itemplate * const itable_FC[] = {
    instrux + 182,
};

static const struct itemplate * const itable_FD[] = {
    instrux + 1041,
};

static const struct itemplate * const itable_FE[] = {
    instrux + 241,
    instrux + 481,
};

static const struct itemplate * const itable_FF[] = {
    instrux + 162,
    instrux + 163,
    instrux + 164,
    instrux + 165,
    instrux + 166,
    instrux + 167,
    instrux + 168,
    instrux + 169,
    instrux + 170,
    instrux + 171,
    instrux + 172,
    instrux + 173,
    instrux + 174,
    instrux + 175,
    instrux + 176,
    instrux + 177,
    instrux + 242,
    instrux + 243,
    instrux + 244,
    instrux + 482,
    instrux + 483,
    instrux + 484,
    instrux + 513,
    instrux + 514,
    instrux + 515,
    instrux + 516,
    instrux + 517,
    instrux + 518,
    instrux + 519,
    instrux + 520,
    instrux + 521,
    instrux + 522,
    instrux + 523,
    instrux + 524,
    instrux + 525,
    instrux + 526,
    instrux + 527,
    instrux + 528,
    instrux + 848,
    instrux + 849,
    instrux + 850,
};

static const struct itemplate * const itable_VEX01010[] = {
    instrux + 2607,
};

static const struct itemplate * const itable_VEX01011[] = {
    instrux + 2608,
};

static const struct itemplate * const itable_VEX01012[] = {
    instrux + 2555,
    instrux + 2556,
    instrux + 2568,
    instrux + 2569,
};

static const struct itemplate * const itable_VEX01013[] = {
    instrux + 2570,
};

static const struct itemplate * const itable_VEX01014[] = {
    instrux + 2978,
    instrux + 2979,
};

static const struct itemplate * const itable_VEX01015[] = {
    instrux + 2970,
    instrux + 2971,
};

static const struct itemplate * const itable_VEX01016[] = {
    instrux + 2560,
    instrux + 2561,
    instrux + 2563,
    instrux + 2564,
};

static const struct itemplate * const itable_VEX01017[] = {
    instrux + 2562,
};

static const struct itemplate * const itable_VEX01028[] = {
    instrux + 2531,
};

static const struct itemplate * const itable_VEX01029[] = {
    instrux + 2532,
};

static const struct itemplate * const itable_VEX0102B[] = {
    instrux + 2585,
};

static const struct itemplate * const itable_VEX0102E[] = {
    instrux + 2965,
};

static const struct itemplate * const itable_VEX0102F[] = {
    instrux + 2408,
};

static const struct itemplate * const itable_VEX01050[] = {
    instrux + 2575,
    instrux + 2576,
};

static const struct itemplate * const itable_VEX01051[] = {
    instrux + 2941,
};

static const struct itemplate * const itable_VEX01052[] = {
    instrux + 2919,
};

static const struct itemplate * const itable_VEX01053[] = {
    instrux + 2915,
};

static const struct itemplate * const itable_VEX01054[] = {
    instrux + 1979,
    instrux + 1980,
};

static const struct itemplate * const itable_VEX01055[] = {
    instrux + 1987,
    instrux + 1988,
};

static const struct itemplate * const itable_VEX01056[] = {
    instrux + 2629,
    instrux + 2630,
};

static const struct itemplate * const itable_VEX01057[] = {
    instrux + 2986,
    instrux + 2987,
};

static const struct itemplate * const itable_VEX01058[] = {
    instrux + 1959,
    instrux + 1960,
};

static const struct itemplate * const itable_VEX01059[] = {
    instrux + 2617,
    instrux + 2618,
};

static const struct itemplate * const itable_VEX0105A[] = {
    instrux + 2423,
};

static const struct itemplate * const itable_VEX0105B[] = {
    instrux + 2411,
};

static const struct itemplate * const itable_VEX0105C[] = {
    instrux + 2952,
    instrux + 2953,
};

static const struct itemplate * const itable_VEX0105D[] = {
    instrux + 2519,
    instrux + 2520,
};

static const struct itemplate * const itable_VEX0105E[] = {
    instrux + 2455,
    instrux + 2456,
};

static const struct itemplate * const itable_VEX0105F[] = {
    instrux + 2507,
    instrux + 2508,
};

static const struct itemplate * const itable_VEX01077[] = {
    instrux + 2991,
};

static const struct itemplate * const itable_VEX010AE[] = {
    instrux + 2493,
    instrux + 2947,
};

static const struct itemplate * const itable_VEX010C2[] = {
    instrux + 2143,
    instrux + 2144,
    instrux + 2147,
    instrux + 2148,
    instrux + 2151,
    instrux + 2152,
    instrux + 2155,
    instrux + 2156,
    instrux + 2159,
    instrux + 2160,
    instrux + 2163,
    instrux + 2164,
    instrux + 2167,
    instrux + 2168,
    instrux + 2171,
    instrux + 2172,
    instrux + 2175,
    instrux + 2176,
    instrux + 2179,
    instrux + 2180,
    instrux + 2183,
    instrux + 2184,
    instrux + 2187,
    instrux + 2188,
    instrux + 2191,
    instrux + 2192,
    instrux + 2195,
    instrux + 2196,
    instrux + 2199,
    instrux + 2200,
    instrux + 2203,
    instrux + 2204,
    instrux + 2207,
    instrux + 2208,
    instrux + 2211,
    instrux + 2212,
    instrux + 2215,
    instrux + 2216,
    instrux + 2219,
    instrux + 2220,
    instrux + 2223,
    instrux + 2224,
    instrux + 2227,
    instrux + 2228,
    instrux + 2231,
    instrux + 2232,
    instrux + 2235,
    instrux + 2236,
    instrux + 2239,
    instrux + 2240,
    instrux + 2243,
    instrux + 2244,
    instrux + 2247,
    instrux + 2248,
    instrux + 2251,
    instrux + 2252,
    instrux + 2255,
    instrux + 2256,
    instrux + 2259,
    instrux + 2260,
    instrux + 2263,
    instrux + 2264,
    instrux + 2267,
    instrux + 2268,
    instrux + 2271,
    instrux + 2272,
};

static const struct itemplate * const itable_VEX010C6[] = {
    instrux + 2935,
    instrux + 2936,
};

static const struct itemplate * const itable_VEX01110[] = {
    instrux + 2603,
};

static const struct itemplate * const itable_VEX01111[] = {
    instrux + 2604,
};

static const struct itemplate * const itable_VEX01112[] = {
    instrux + 2565,
    instrux + 2566,
};

static const struct itemplate * const itable_VEX01113[] = {
    instrux + 2567,
};

static const struct itemplate * const itable_VEX01114[] = {
    instrux + 2974,
    instrux + 2975,
};

static const struct itemplate * const itable_VEX01115[] = {
    instrux + 2966,
    instrux + 2967,
};

static const struct itemplate * const itable_VEX01116[] = {
    instrux + 2557,
    instrux + 2558,
};

static const struct itemplate * const itable_VEX01117[] = {
    instrux + 2559,
};

static const struct itemplate * const itable_VEX01128[] = {
    instrux + 2527,
};

static const struct itemplate * const itable_VEX01129[] = {
    instrux + 2528,
    instrux + 2684,
    instrux + 2685,
};

static const struct itemplate * const itable_VEX0112B[] = {
    instrux + 2583,
};

static const struct itemplate * const itable_VEX0112E[] = {
    instrux + 2964,
};

static const struct itemplate * const itable_VEX0112F[] = {
    instrux + 2407,
};

static const struct itemplate * const itable_VEX01137[] = {
    instrux + 2692,
    instrux + 2693,
};

static const struct itemplate * const itable_VEX01150[] = {
    instrux + 2571,
    instrux + 2572,
};

static const struct itemplate * const itable_VEX01151[] = {
    instrux + 2939,
};

static const struct itemplate * const itable_VEX01154[] = {
    instrux + 1975,
    instrux + 1976,
};

static const struct itemplate * const itable_VEX01155[] = {
    instrux + 1983,
    instrux + 1984,
};

static const struct itemplate * const itable_VEX01156[] = {
    instrux + 2625,
    instrux + 2626,
};

static const struct itemplate * const itable_VEX01157[] = {
    instrux + 2982,
    instrux + 2983,
};

static const struct itemplate * const itable_VEX01158[] = {
    instrux + 1955,
    instrux + 1956,
};

static const struct itemplate * const itable_VEX01159[] = {
    instrux + 2613,
    instrux + 2614,
};

static const struct itemplate * const itable_VEX0115A[] = {
    instrux + 2417,
    instrux + 2418,
};

static const struct itemplate * const itable_VEX0115B[] = {
    instrux + 2421,
};

static const struct itemplate * const itable_VEX0115C[] = {
    instrux + 2948,
    instrux + 2949,
};

static const struct itemplate * const itable_VEX0115D[] = {
    instrux + 2515,
    instrux + 2516,
};

static const struct itemplate * const itable_VEX0115E[] = {
    instrux + 2451,
    instrux + 2452,
};

static const struct itemplate * const itable_VEX0115F[] = {
    instrux + 2503,
    instrux + 2504,
};

static const struct itemplate * const itable_VEX01160[] = {
    instrux + 2905,
    instrux + 2906,
};

static const struct itemplate * const itable_VEX01161[] = {
    instrux + 2907,
    instrux + 2908,
};

static const struct itemplate * const itable_VEX01162[] = {
    instrux + 2909,
    instrux + 2910,
};

static const struct itemplate * const itable_VEX01163[] = {
    instrux + 2636,
    instrux + 2637,
};

static const struct itemplate * const itable_VEX01164[] = {
    instrux + 2686,
    instrux + 2687,
};

static const struct itemplate * const itable_VEX01165[] = {
    instrux + 2688,
    instrux + 2689,
};

static const struct itemplate * const itable_VEX01166[] = {
    instrux + 2690,
    instrux + 2691,
};

static const struct itemplate * const itable_VEX01167[] = {
    instrux + 2640,
    instrux + 2641,
};

static const struct itemplate * const itable_VEX01168[] = {
    instrux + 2897,
    instrux + 2898,
};

static const struct itemplate * const itable_VEX01169[] = {
    instrux + 2899,
    instrux + 2900,
};

static const struct itemplate * const itable_VEX0116A[] = {
    instrux + 2901,
    instrux + 2902,
};

static const struct itemplate * const itable_VEX0116B[] = {
    instrux + 2638,
    instrux + 2639,
};

static const struct itemplate * const itable_VEX0116C[] = {
    instrux + 2911,
    instrux + 2912,
};

static const struct itemplate * const itable_VEX0116D[] = {
    instrux + 2903,
    instrux + 2904,
};

static const struct itemplate * const itable_VEX0116E[] = {
    instrux + 2537,
    instrux + 2538,
};

static const struct itemplate * const itable_VEX0116F[] = {
    instrux + 2543,
};

static const struct itemplate * const itable_VEX01170[] = {
    instrux + 2834,
};

static const struct itemplate * const itable_VEX01171[] = {
    instrux + 2849,
    instrux + 2850,
    instrux + 2861,
    instrux + 2862,
    instrux + 2869,
    instrux + 2870,
};

static const struct itemplate * const itable_VEX01172[] = {
    instrux + 2853,
    instrux + 2854,
    instrux + 2865,
    instrux + 2866,
    instrux + 2873,
    instrux + 2874,
};

static const struct itemplate * const itable_VEX01173[] = {
    instrux + 2843,
    instrux + 2844,
    instrux + 2845,
    instrux + 2846,
    instrux + 2857,
    instrux + 2858,
    instrux + 2877,
    instrux + 2878,
};

static const struct itemplate * const itable_VEX01174[] = {
    instrux + 2678,
    instrux + 2679,
};

static const struct itemplate * const itable_VEX01175[] = {
    instrux + 2680,
    instrux + 2681,
};

static const struct itemplate * const itable_VEX01176[] = {
    instrux + 2682,
    instrux + 2683,
};

static const struct itemplate * const itable_VEX0117C[] = {
    instrux + 2471,
    instrux + 2472,
};

static const struct itemplate * const itable_VEX0117D[] = {
    instrux + 2479,
    instrux + 2480,
};

static const struct itemplate * const itable_VEX0117E[] = {
    instrux + 2539,
    instrux + 2540,
};

static const struct itemplate * const itable_VEX0117F[] = {
    instrux + 2544,
};

static const struct itemplate * const itable_VEX011C2[] = {
    instrux + 2011,
    instrux + 2012,
    instrux + 2015,
    instrux + 2016,
    instrux + 2019,
    instrux + 2020,
    instrux + 2023,
    instrux + 2024,
    instrux + 2027,
    instrux + 2028,
    instrux + 2031,
    instrux + 2032,
    instrux + 2035,
    instrux + 2036,
    instrux + 2039,
    instrux + 2040,
    instrux + 2043,
    instrux + 2044,
    instrux + 2047,
    instrux + 2048,
    instrux + 2051,
    instrux + 2052,
    instrux + 2055,
    instrux + 2056,
    instrux + 2059,
    instrux + 2060,
    instrux + 2063,
    instrux + 2064,
    instrux + 2067,
    instrux + 2068,
    instrux + 2071,
    instrux + 2072,
    instrux + 2075,
    instrux + 2076,
    instrux + 2079,
    instrux + 2080,
    instrux + 2083,
    instrux + 2084,
    instrux + 2087,
    instrux + 2088,
    instrux + 2091,
    instrux + 2092,
    instrux + 2095,
    instrux + 2096,
    instrux + 2099,
    instrux + 2100,
    instrux + 2103,
    instrux + 2104,
    instrux + 2107,
    instrux + 2108,
    instrux + 2111,
    instrux + 2112,
    instrux + 2115,
    instrux + 2116,
    instrux + 2119,
    instrux + 2120,
    instrux + 2123,
    instrux + 2124,
    instrux + 2127,
    instrux + 2128,
    instrux + 2131,
    instrux + 2132,
    instrux + 2135,
    instrux + 2136,
    instrux + 2139,
    instrux + 2140,
};

static const struct itemplate * const itable_VEX011C4[] = {
    instrux + 2764,
    instrux + 2765,
    instrux + 2766,
    instrux + 2767,
};

static const struct itemplate * const itable_VEX011C5[] = {
    instrux + 2738,
    instrux + 2739,
    instrux + 2740,
};

static const struct itemplate * const itable_VEX011C6[] = {
    instrux + 2931,
    instrux + 2932,
};

static const struct itemplate * const itable_VEX011D0[] = {
    instrux + 1967,
    instrux + 1968,
};

static const struct itemplate * const itable_VEX011D1[] = {
    instrux + 2867,
    instrux + 2868,
};

static const struct itemplate * const itable_VEX011D2[] = {
    instrux + 2871,
    instrux + 2872,
};

static const struct itemplate * const itable_VEX011D3[] = {
    instrux + 2875,
    instrux + 2876,
};

static const struct itemplate * const itable_VEX011D4[] = {
    instrux + 2650,
    instrux + 2651,
};

static const struct itemplate * const itable_VEX011D5[] = {
    instrux + 2820,
    instrux + 2821,
};

static const struct itemplate * const itable_VEX011D6[] = {
    instrux + 2536,
};

static const struct itemplate * const itable_VEX011D7[] = {
    instrux + 2800,
    instrux + 2801,
};

static const struct itemplate * const itable_VEX011D8[] = {
    instrux + 2893,
    instrux + 2894,
};

static const struct itemplate * const itable_VEX011D9[] = {
    instrux + 2895,
    instrux + 2896,
};

static const struct itemplate * const itable_VEX011DA[] = {
    instrux + 2794,
    instrux + 2795,
};

static const struct itemplate * const itable_VEX011DB[] = {
    instrux + 2662,
    instrux + 2663,
};

static const struct itemplate * const itable_VEX011DC[] = {
    instrux + 2656,
    instrux + 2657,
};

static const struct itemplate * const itable_VEX011DD[] = {
    instrux + 2658,
    instrux + 2659,
};

static const struct itemplate * const itable_VEX011DE[] = {
    instrux + 2782,
    instrux + 2783,
};

static const struct itemplate * const itable_VEX011DF[] = {
    instrux + 2664,
    instrux + 2665,
};

static const struct itemplate * const itable_VEX011E0[] = {
    instrux + 2666,
    instrux + 2667,
};

static const struct itemplate * const itable_VEX011E1[] = {
    instrux + 2859,
    instrux + 2860,
};

static const struct itemplate * const itable_VEX011E2[] = {
    instrux + 2863,
    instrux + 2864,
};

static const struct itemplate * const itable_VEX011E3[] = {
    instrux + 2668,
    instrux + 2669,
};

static const struct itemplate * const itable_VEX011E4[] = {
    instrux + 2814,
    instrux + 2815,
};

static const struct itemplate * const itable_VEX011E5[] = {
    instrux + 2818,
    instrux + 2819,
};

static const struct itemplate * const itable_VEX011E6[] = {
    instrux + 2441,
    instrux + 2442,
};

static const struct itemplate * const itable_VEX011E7[] = {
    instrux + 2579,
};

static const struct itemplate * const itable_VEX011E8[] = {
    instrux + 2889,
    instrux + 2890,
};

static const struct itemplate * const itable_VEX011E9[] = {
    instrux + 2891,
    instrux + 2892,
};

static const struct itemplate * const itable_VEX011EA[] = {
    instrux + 2790,
    instrux + 2791,
};

static const struct itemplate * const itable_VEX011EB[] = {
    instrux + 2828,
    instrux + 2829,
};

static const struct itemplate * const itable_VEX011EC[] = {
    instrux + 2652,
    instrux + 2653,
};

static const struct itemplate * const itable_VEX011ED[] = {
    instrux + 2654,
    instrux + 2655,
};

static const struct itemplate * const itable_VEX011EE[] = {
    instrux + 2778,
    instrux + 2779,
};

static const struct itemplate * const itable_VEX011EF[] = {
    instrux + 2913,
    instrux + 2914,
};

static const struct itemplate * const itable_VEX011F1[] = {
    instrux + 2847,
    instrux + 2848,
};

static const struct itemplate * const itable_VEX011F2[] = {
    instrux + 2851,
    instrux + 2852,
};

static const struct itemplate * const itable_VEX011F3[] = {
    instrux + 2855,
    instrux + 2856,
};

static const struct itemplate * const itable_VEX011F4[] = {
    instrux + 2824,
    instrux + 2825,
};

static const struct itemplate * const itable_VEX011F5[] = {
    instrux + 2772,
    instrux + 2773,
};

static const struct itemplate * const itable_VEX011F6[] = {
    instrux + 2830,
    instrux + 2831,
};

static const struct itemplate * const itable_VEX011F7[] = {
    instrux + 2494,
};

static const struct itemplate * const itable_VEX011F8[] = {
    instrux + 2881,
    instrux + 2882,
};

static const struct itemplate * const itable_VEX011F9[] = {
    instrux + 2883,
    instrux + 2884,
};

static const struct itemplate * const itable_VEX011FA[] = {
    instrux + 2885,
    instrux + 2886,
};

static const struct itemplate * const itable_VEX011FB[] = {
    instrux + 2887,
    instrux + 2888,
};

static const struct itemplate * const itable_VEX011FC[] = {
    instrux + 2644,
    instrux + 2645,
};

static const struct itemplate * const itable_VEX011FD[] = {
    instrux + 2646,
    instrux + 2647,
};

static const struct itemplate * const itable_VEX011FE[] = {
    instrux + 2648,
    instrux + 2649,
};

static const struct itemplate * const itable_VEX01210[] = {
    instrux + 2597,
    instrux + 2598,
    instrux + 2599,
};

static const struct itemplate * const itable_VEX01211[] = {
    instrux + 2600,
    instrux + 2601,
    instrux + 2602,
};

static const struct itemplate * const itable_VEX01212[] = {
    instrux + 2595,
};

static const struct itemplate * const itable_VEX01216[] = {
    instrux + 2593,
};

static const struct itemplate * const itable_VEX0122A[] = {
    instrux + 2433,
    instrux + 2434,
    instrux + 2435,
    instrux + 2436,
};

static const struct itemplate * const itable_VEX0122C[] = {
    instrux + 2449,
    instrux + 2450,
};

static const struct itemplate * const itable_VEX0122D[] = {
    instrux + 2439,
    instrux + 2440,
};

static const struct itemplate * const itable_VEX01251[] = {
    instrux + 2945,
    instrux + 2946,
};

static const struct itemplate * const itable_VEX01252[] = {
    instrux + 2921,
    instrux + 2922,
};

static const struct itemplate * const itable_VEX01253[] = {
    instrux + 2917,
    instrux + 2918,
};

static const struct itemplate * const itable_VEX01258[] = {
    instrux + 1965,
    instrux + 1966,
};

static const struct itemplate * const itable_VEX01259[] = {
    instrux + 2623,
    instrux + 2624,
};

static const struct itemplate * const itable_VEX0125A[] = {
    instrux + 2437,
    instrux + 2438,
};

static const struct itemplate * const itable_VEX0125B[] = {
    instrux + 2445,
};

static const struct itemplate * const itable_VEX0125C[] = {
    instrux + 2958,
    instrux + 2959,
};

static const struct itemplate * const itable_VEX0125D[] = {
    instrux + 2525,
    instrux + 2526,
};

static const struct itemplate * const itable_VEX0125E[] = {
    instrux + 2461,
    instrux + 2462,
};

static const struct itemplate * const itable_VEX0125F[] = {
    instrux + 2513,
    instrux + 2514,
};

static const struct itemplate * const itable_VEX0126F[] = {
    instrux + 2549,
};

static const struct itemplate * const itable_VEX01270[] = {
    instrux + 2835,
};

static const struct itemplate * const itable_VEX0127E[] = {
    instrux + 2535,
};

static const struct itemplate * const itable_VEX0127F[] = {
    instrux + 2550,
};

static const struct itemplate * const itable_VEX012C2[] = {
    instrux + 2341,
    instrux + 2342,
    instrux + 2343,
    instrux + 2344,
    instrux + 2345,
    instrux + 2346,
    instrux + 2347,
    instrux + 2348,
    instrux + 2349,
    instrux + 2350,
    instrux + 2351,
    instrux + 2352,
    instrux + 2353,
    instrux + 2354,
    instrux + 2355,
    instrux + 2356,
    instrux + 2357,
    instrux + 2358,
    instrux + 2359,
    instrux + 2360,
    instrux + 2361,
    instrux + 2362,
    instrux + 2363,
    instrux + 2364,
    instrux + 2365,
    instrux + 2366,
    instrux + 2367,
    instrux + 2368,
    instrux + 2369,
    instrux + 2370,
    instrux + 2371,
    instrux + 2372,
    instrux + 2373,
    instrux + 2374,
    instrux + 2375,
    instrux + 2376,
    instrux + 2377,
    instrux + 2378,
    instrux + 2379,
    instrux + 2380,
    instrux + 2381,
    instrux + 2382,
    instrux + 2383,
    instrux + 2384,
    instrux + 2385,
    instrux + 2386,
    instrux + 2387,
    instrux + 2388,
    instrux + 2389,
    instrux + 2390,
    instrux + 2391,
    instrux + 2392,
    instrux + 2393,
    instrux + 2394,
    instrux + 2395,
    instrux + 2396,
    instrux + 2397,
    instrux + 2398,
    instrux + 2399,
    instrux + 2400,
    instrux + 2401,
    instrux + 2402,
    instrux + 2403,
    instrux + 2404,
    instrux + 2405,
    instrux + 2406,
};

static const struct itemplate * const itable_VEX012E6[] = {
    instrux + 2409,
};

static const struct itemplate * const itable_VEX01310[] = {
    instrux + 2587,
    instrux + 2588,
    instrux + 2589,
};

static const struct itemplate * const itable_VEX01311[] = {
    instrux + 2590,
    instrux + 2591,
    instrux + 2592,
};

static const struct itemplate * const itable_VEX01312[] = {
    instrux + 2541,
};

static const struct itemplate * const itable_VEX0132A[] = {
    instrux + 2429,
    instrux + 2430,
    instrux + 2431,
    instrux + 2432,
};

static const struct itemplate * const itable_VEX0132C[] = {
    instrux + 2447,
    instrux + 2448,
};

static const struct itemplate * const itable_VEX0132D[] = {
    instrux + 2425,
    instrux + 2426,
};

static const struct itemplate * const itable_VEX01351[] = {
    instrux + 2943,
    instrux + 2944,
};

static const struct itemplate * const itable_VEX01358[] = {
    instrux + 1963,
    instrux + 1964,
};

static const struct itemplate * const itable_VEX01359[] = {
    instrux + 2621,
    instrux + 2622,
};

static const struct itemplate * const itable_VEX0135A[] = {
    instrux + 2427,
    instrux + 2428,
};

static const struct itemplate * const itable_VEX0135C[] = {
    instrux + 2956,
    instrux + 2957,
};

static const struct itemplate * const itable_VEX0135D[] = {
    instrux + 2523,
    instrux + 2524,
};

static const struct itemplate * const itable_VEX0135E[] = {
    instrux + 2459,
    instrux + 2460,
};

static const struct itemplate * const itable_VEX0135F[] = {
    instrux + 2511,
    instrux + 2512,
};

static const struct itemplate * const itable_VEX01370[] = {
    instrux + 2836,
};

static const struct itemplate * const itable_VEX0137C[] = {
    instrux + 2475,
    instrux + 2476,
};

static const struct itemplate * const itable_VEX0137D[] = {
    instrux + 2483,
    instrux + 2484,
};

static const struct itemplate * const itable_VEX013C2[] = {
    instrux + 2275,
    instrux + 2276,
    instrux + 2277,
    instrux + 2278,
    instrux + 2279,
    instrux + 2280,
    instrux + 2281,
    instrux + 2282,
    instrux + 2283,
    instrux + 2284,
    instrux + 2285,
    instrux + 2286,
    instrux + 2287,
    instrux + 2288,
    instrux + 2289,
    instrux + 2290,
    instrux + 2291,
    instrux + 2292,
    instrux + 2293,
    instrux + 2294,
    instrux + 2295,
    instrux + 2296,
    instrux + 2297,
    instrux + 2298,
    instrux + 2299,
    instrux + 2300,
    instrux + 2301,
    instrux + 2302,
    instrux + 2303,
    instrux + 2304,
    instrux + 2305,
    instrux + 2306,
    instrux + 2307,
    instrux + 2308,
    instrux + 2309,
    instrux + 2310,
    instrux + 2311,
    instrux + 2312,
    instrux + 2313,
    instrux + 2314,
    instrux + 2315,
    instrux + 2316,
    instrux + 2317,
    instrux + 2318,
    instrux + 2319,
    instrux + 2320,
    instrux + 2321,
    instrux + 2322,
    instrux + 2323,
    instrux + 2324,
    instrux + 2325,
    instrux + 2326,
    instrux + 2327,
    instrux + 2328,
    instrux + 2329,
    instrux + 2330,
    instrux + 2331,
    instrux + 2332,
    instrux + 2333,
    instrux + 2334,
    instrux + 2335,
    instrux + 2336,
    instrux + 2337,
    instrux + 2338,
    instrux + 2339,
    instrux + 2340,
};

static const struct itemplate * const itable_VEX013E6[] = {
    instrux + 2413,
    instrux + 2414,
};

static const struct itemplate * const itable_VEX013F0[] = {
    instrux + 1971,
    instrux + 1972,
    instrux + 2490,
};

static const struct itemplate * const itable_VEX01410[] = {
    instrux + 2609,
};

static const struct itemplate * const itable_VEX01411[] = {
    instrux + 2610,
};

static const struct itemplate * const itable_VEX01414[] = {
    instrux + 2980,
    instrux + 2981,
};

static const struct itemplate * const itable_VEX01415[] = {
    instrux + 2972,
    instrux + 2973,
};

static const struct itemplate * const itable_VEX01428[] = {
    instrux + 2533,
};

static const struct itemplate * const itable_VEX01429[] = {
    instrux + 2534,
};

static const struct itemplate * const itable_VEX0142B[] = {
    instrux + 2586,
};

static const struct itemplate * const itable_VEX01450[] = {
    instrux + 2577,
    instrux + 2578,
};

static const struct itemplate * const itable_VEX01451[] = {
    instrux + 2942,
};

static const struct itemplate * const itable_VEX01452[] = {
    instrux + 2920,
};

static const struct itemplate * const itable_VEX01453[] = {
    instrux + 2916,
};

static const struct itemplate * const itable_VEX01454[] = {
    instrux + 1981,
    instrux + 1982,
};

static const struct itemplate * const itable_VEX01455[] = {
    instrux + 1989,
    instrux + 1990,
};

static const struct itemplate * const itable_VEX01456[] = {
    instrux + 2631,
    instrux + 2632,
};

static const struct itemplate * const itable_VEX01457[] = {
    instrux + 2988,
    instrux + 2989,
};

static const struct itemplate * const itable_VEX01458[] = {
    instrux + 1961,
    instrux + 1962,
};

static const struct itemplate * const itable_VEX01459[] = {
    instrux + 2619,
    instrux + 2620,
};

static const struct itemplate * const itable_VEX0145A[] = {
    instrux + 2424,
};

static const struct itemplate * const itable_VEX0145B[] = {
    instrux + 2412,
};

static const struct itemplate * const itable_VEX0145C[] = {
    instrux + 2954,
    instrux + 2955,
};

static const struct itemplate * const itable_VEX0145D[] = {
    instrux + 2521,
    instrux + 2522,
};

static const struct itemplate * const itable_VEX0145E[] = {
    instrux + 2457,
    instrux + 2458,
};

static const struct itemplate * const itable_VEX0145F[] = {
    instrux + 2509,
    instrux + 2510,
};

static const struct itemplate * const itable_VEX01477[] = {
    instrux + 2990,
};

static const struct itemplate * const itable_VEX014C2[] = {
    instrux + 2145,
    instrux + 2146,
    instrux + 2149,
    instrux + 2150,
    instrux + 2153,
    instrux + 2154,
    instrux + 2157,
    instrux + 2158,
    instrux + 2161,
    instrux + 2162,
    instrux + 2165,
    instrux + 2166,
    instrux + 2169,
    instrux + 2170,
    instrux + 2173,
    instrux + 2174,
    instrux + 2177,
    instrux + 2178,
    instrux + 2181,
    instrux + 2182,
    instrux + 2185,
    instrux + 2186,
    instrux + 2189,
    instrux + 2190,
    instrux + 2193,
    instrux + 2194,
    instrux + 2197,
    instrux + 2198,
    instrux + 2201,
    instrux + 2202,
    instrux + 2205,
    instrux + 2206,
    instrux + 2209,
    instrux + 2210,
    instrux + 2213,
    instrux + 2214,
    instrux + 2217,
    instrux + 2218,
    instrux + 2221,
    instrux + 2222,
    instrux + 2225,
    instrux + 2226,
    instrux + 2229,
    instrux + 2230,
    instrux + 2233,
    instrux + 2234,
    instrux + 2237,
    instrux + 2238,
    instrux + 2241,
    instrux + 2242,
    instrux + 2245,
    instrux + 2246,
    instrux + 2249,
    instrux + 2250,
    instrux + 2253,
    instrux + 2254,
    instrux + 2257,
    instrux + 2258,
    instrux + 2261,
    instrux + 2262,
    instrux + 2265,
    instrux + 2266,
    instrux + 2269,
    instrux + 2270,
    instrux + 2273,
    instrux + 2274,
};

static const struct itemplate * const itable_VEX014C6[] = {
    instrux + 2937,
    instrux + 2938,
};

static const struct itemplate * const itable_VEX01510[] = {
    instrux + 2605,
};

static const struct itemplate * const itable_VEX01511[] = {
    instrux + 2606,
};

static const struct itemplate * const itable_VEX01514[] = {
    instrux + 2976,
    instrux + 2977,
};

static const struct itemplate * const itable_VEX01515[] = {
    instrux + 2968,
    instrux + 2969,
};

static const struct itemplate * const itable_VEX01528[] = {
    instrux + 2529,
};

static const struct itemplate * const itable_VEX01529[] = {
    instrux + 2530,
};

static const struct itemplate * const itable_VEX0152B[] = {
    instrux + 2584,
};

static const struct itemplate * const itable_VEX01550[] = {
    instrux + 2573,
    instrux + 2574,
};

static const struct itemplate * const itable_VEX01551[] = {
    instrux + 2940,
};

static const struct itemplate * const itable_VEX01554[] = {
    instrux + 1977,
    instrux + 1978,
};

static const struct itemplate * const itable_VEX01555[] = {
    instrux + 1985,
    instrux + 1986,
};

static const struct itemplate * const itable_VEX01556[] = {
    instrux + 2627,
    instrux + 2628,
};

static const struct itemplate * const itable_VEX01557[] = {
    instrux + 2984,
    instrux + 2985,
};

static const struct itemplate * const itable_VEX01558[] = {
    instrux + 1957,
    instrux + 1958,
};

static const struct itemplate * const itable_VEX01559[] = {
    instrux + 2615,
    instrux + 2616,
};

static const struct itemplate * const itable_VEX0155A[] = {
    instrux + 2419,
    instrux + 2420,
};

static const struct itemplate * const itable_VEX0155B[] = {
    instrux + 2422,
};

static const struct itemplate * const itable_VEX0155C[] = {
    instrux + 2950,
    instrux + 2951,
};

static const struct itemplate * const itable_VEX0155D[] = {
    instrux + 2517,
    instrux + 2518,
};

static const struct itemplate * const itable_VEX0155E[] = {
    instrux + 2453,
    instrux + 2454,
};

static const struct itemplate * const itable_VEX0155F[] = {
    instrux + 2505,
    instrux + 2506,
};

static const struct itemplate * const itable_VEX0156F[] = {
    instrux + 2545,
    instrux + 2547,
};

static const struct itemplate * const itable_VEX0157C[] = {
    instrux + 2473,
    instrux + 2474,
};

static const struct itemplate * const itable_VEX0157D[] = {
    instrux + 2481,
    instrux + 2482,
};

static const struct itemplate * const itable_VEX0157F[] = {
    instrux + 2546,
    instrux + 2548,
};

static const struct itemplate * const itable_VEX015C2[] = {
    instrux + 2013,
    instrux + 2014,
    instrux + 2017,
    instrux + 2018,
    instrux + 2021,
    instrux + 2022,
    instrux + 2025,
    instrux + 2026,
    instrux + 2029,
    instrux + 2030,
    instrux + 2033,
    instrux + 2034,
    instrux + 2037,
    instrux + 2038,
    instrux + 2041,
    instrux + 2042,
    instrux + 2045,
    instrux + 2046,
    instrux + 2049,
    instrux + 2050,
    instrux + 2053,
    instrux + 2054,
    instrux + 2057,
    instrux + 2058,
    instrux + 2061,
    instrux + 2062,
    instrux + 2065,
    instrux + 2066,
    instrux + 2069,
    instrux + 2070,
    instrux + 2073,
    instrux + 2074,
    instrux + 2077,
    instrux + 2078,
    instrux + 2081,
    instrux + 2082,
    instrux + 2085,
    instrux + 2086,
    instrux + 2089,
    instrux + 2090,
    instrux + 2093,
    instrux + 2094,
    instrux + 2097,
    instrux + 2098,
    instrux + 2101,
    instrux + 2102,
    instrux + 2105,
    instrux + 2106,
    instrux + 2109,
    instrux + 2110,
    instrux + 2113,
    instrux + 2114,
    instrux + 2117,
    instrux + 2118,
    instrux + 2121,
    instrux + 2122,
    instrux + 2125,
    instrux + 2126,
    instrux + 2129,
    instrux + 2130,
    instrux + 2133,
    instrux + 2134,
    instrux + 2137,
    instrux + 2138,
    instrux + 2141,
    instrux + 2142,
};

static const struct itemplate * const itable_VEX015C6[] = {
    instrux + 2933,
    instrux + 2934,
};

static const struct itemplate * const itable_VEX015D0[] = {
    instrux + 1969,
    instrux + 1970,
};

static const struct itemplate * const itable_VEX015E6[] = {
    instrux + 2443,
    instrux + 2444,
};

static const struct itemplate * const itable_VEX015E7[] = {
    instrux + 2580,
    instrux + 2581,
};

static const struct itemplate * const itable_VEX01612[] = {
    instrux + 2596,
};

static const struct itemplate * const itable_VEX01616[] = {
    instrux + 2594,
};

static const struct itemplate * const itable_VEX0165B[] = {
    instrux + 2446,
};

static const struct itemplate * const itable_VEX0166F[] = {
    instrux + 2551,
    instrux + 2553,
};

static const struct itemplate * const itable_VEX0167F[] = {
    instrux + 2552,
    instrux + 2554,
};

static const struct itemplate * const itable_VEX016E6[] = {
    instrux + 2410,
};

static const struct itemplate * const itable_VEX01712[] = {
    instrux + 2542,
};

static const struct itemplate * const itable_VEX0177C[] = {
    instrux + 2477,
    instrux + 2478,
};

static const struct itemplate * const itable_VEX0177D[] = {
    instrux + 2485,
    instrux + 2486,
};

static const struct itemplate * const itable_VEX017E6[] = {
    instrux + 2415,
    instrux + 2416,
};

static const struct itemplate * const itable_VEX017F0[] = {
    instrux + 1973,
    instrux + 1974,
    instrux + 2491,
    instrux + 2492,
};

static const struct itemplate * const itable_VEX02100[] = {
    instrux + 2832,
    instrux + 2833,
};

static const struct itemplate * const itable_VEX02101[] = {
    instrux + 2747,
    instrux + 2748,
};

static const struct itemplate * const itable_VEX02102[] = {
    instrux + 2749,
    instrux + 2750,
};

static const struct itemplate * const itable_VEX02103[] = {
    instrux + 2751,
    instrux + 2752,
};

static const struct itemplate * const itable_VEX02104[] = {
    instrux + 2774,
    instrux + 2775,
};

static const struct itemplate * const itable_VEX02105[] = {
    instrux + 2754,
    instrux + 2755,
};

static const struct itemplate * const itable_VEX02106[] = {
    instrux + 2756,
    instrux + 2757,
};

static const struct itemplate * const itable_VEX02107[] = {
    instrux + 2758,
    instrux + 2759,
};

static const struct itemplate * const itable_VEX02108[] = {
    instrux + 2837,
    instrux + 2838,
};

static const struct itemplate * const itable_VEX02109[] = {
    instrux + 2839,
    instrux + 2840,
};

static const struct itemplate * const itable_VEX0210A[] = {
    instrux + 2841,
    instrux + 2842,
};

static const struct itemplate * const itable_VEX0210B[] = {
    instrux + 2816,
    instrux + 2817,
};

static const struct itemplate * const itable_VEX0210C[] = {
    instrux + 2714,
};

static const struct itemplate * const itable_VEX0210D[] = {
    instrux + 2694,
};

static const struct itemplate * const itable_VEX0210E[] = {
    instrux + 2960,
};

static const struct itemplate * const itable_VEX0210F[] = {
    instrux + 2962,
};

static const struct itemplate * const itable_VEX02114[] = {
    instrux + 2004,
};

static const struct itemplate * const itable_VEX02115[] = {
    instrux + 2000,
};

static const struct itemplate * const itable_VEX02117[] = {
    instrux + 2879,
};

static const struct itemplate * const itable_VEX02118[] = {
    instrux + 2007,
};

static const struct itemplate * const itable_VEX0211C[] = {
    instrux + 2633,
};

static const struct itemplate * const itable_VEX0211D[] = {
    instrux + 2634,
};

static const struct itemplate * const itable_VEX0211E[] = {
    instrux + 2635,
};

static const struct itemplate * const itable_VEX02120[] = {
    instrux + 2802,
};

static const struct itemplate * const itable_VEX02121[] = {
    instrux + 2803,
};

static const struct itemplate * const itable_VEX02122[] = {
    instrux + 2804,
};

static const struct itemplate * const itable_VEX02123[] = {
    instrux + 2805,
};

static const struct itemplate * const itable_VEX02124[] = {
    instrux + 2806,
};

static const struct itemplate * const itable_VEX02125[] = {
    instrux + 2807,
};

static const struct itemplate * const itable_VEX02128[] = {
    instrux + 2826,
    instrux + 2827,
};

static const struct itemplate * const itable_VEX0212A[] = {
    instrux + 2582,
};

static const struct itemplate * const itable_VEX0212B[] = {
    instrux + 2642,
    instrux + 2643,
};

static const struct itemplate * const itable_VEX0212C[] = {
    instrux + 2495,
};

static const struct itemplate * const itable_VEX0212D[] = {
    instrux + 2499,
};

static const struct itemplate * const itable_VEX0212E[] = {
    instrux + 2497,
};

static const struct itemplate * const itable_VEX0212F[] = {
    instrux + 2501,
};

static const struct itemplate * const itable_VEX02130[] = {
    instrux + 2808,
};

static const struct itemplate * const itable_VEX02131[] = {
    instrux + 2809,
};

static const struct itemplate * const itable_VEX02132[] = {
    instrux + 2810,
};

static const struct itemplate * const itable_VEX02133[] = {
    instrux + 2811,
};

static const struct itemplate * const itable_VEX02134[] = {
    instrux + 2812,
};

static const struct itemplate * const itable_VEX02135[] = {
    instrux + 2813,
};

static const struct itemplate * const itable_VEX02138[] = {
    instrux + 2788,
    instrux + 2789,
};

static const struct itemplate * const itable_VEX02139[] = {
    instrux + 2792,
    instrux + 2793,
};

static const struct itemplate * const itable_VEX0213A[] = {
    instrux + 2796,
    instrux + 2797,
};

static const struct itemplate * const itable_VEX0213B[] = {
    instrux + 2798,
    instrux + 2799,
};

static const struct itemplate * const itable_VEX0213C[] = {
    instrux + 2776,
    instrux + 2777,
};

static const struct itemplate * const itable_VEX0213D[] = {
    instrux + 2780,
    instrux + 2781,
};

static const struct itemplate * const itable_VEX0213E[] = {
    instrux + 2784,
    instrux + 2785,
};

static const struct itemplate * const itable_VEX0213F[] = {
    instrux + 2786,
    instrux + 2787,
};

static const struct itemplate * const itable_VEX02140[] = {
    instrux + 2822,
    instrux + 2823,
};

static const struct itemplate * const itable_VEX02141[] = {
    instrux + 2753,
};

static const struct itemplate * const itable_VEX021DB[] = {
    instrux + 1953,
};

static const struct itemplate * const itable_VEX021DC[] = {
    instrux + 1945,
    instrux + 1946,
};

static const struct itemplate * const itable_VEX021DD[] = {
    instrux + 1947,
    instrux + 1948,
};

static const struct itemplate * const itable_VEX021DE[] = {
    instrux + 1949,
    instrux + 1950,
};

static const struct itemplate * const itable_VEX021DF[] = {
    instrux + 1951,
    instrux + 1952,
};

static const struct itemplate * const itable_VEX0250C[] = {
    instrux + 2715,
};

static const struct itemplate * const itable_VEX0250D[] = {
    instrux + 2695,
};

static const struct itemplate * const itable_VEX0250E[] = {
    instrux + 2961,
};

static const struct itemplate * const itable_VEX0250F[] = {
    instrux + 2963,
};

static const struct itemplate * const itable_VEX02514[] = {
    instrux + 2006,
};

static const struct itemplate * const itable_VEX02515[] = {
    instrux + 2002,
};

static const struct itemplate * const itable_VEX02517[] = {
    instrux + 2880,
};

static const struct itemplate * const itable_VEX02518[] = {
    instrux + 2008,
};

static const struct itemplate * const itable_VEX02519[] = {
    instrux + 2009,
};

static const struct itemplate * const itable_VEX0251A[] = {
    instrux + 2010,
};

static const struct itemplate * const itable_VEX0252C[] = {
    instrux + 2496,
};

static const struct itemplate * const itable_VEX0252D[] = {
    instrux + 2500,
};

static const struct itemplate * const itable_VEX0252E[] = {
    instrux + 2498,
};

static const struct itemplate * const itable_VEX0252F[] = {
    instrux + 2502,
};

static const struct itemplate * const itable_VEX03104[] = {
    instrux + 2716,
};

static const struct itemplate * const itable_VEX03105[] = {
    instrux + 2696,
};

static const struct itemplate * const itable_VEX03108[] = {
    instrux + 2925,
};

static const struct itemplate * const itable_VEX03109[] = {
    instrux + 2923,
};

static const struct itemplate * const itable_VEX0310A[] = {
    instrux + 2929,
    instrux + 2930,
};

static const struct itemplate * const itable_VEX0310B[] = {
    instrux + 2927,
    instrux + 2928,
};

static const struct itemplate * const itable_VEX0310C[] = {
    instrux + 1995,
    instrux + 1996,
};

static const struct itemplate * const itable_VEX0310D[] = {
    instrux + 1991,
    instrux + 1992,
};

static const struct itemplate * const itable_VEX0310E[] = {
    instrux + 2672,
    instrux + 2673,
};

static const struct itemplate * const itable_VEX0310F[] = {
    instrux + 2660,
    instrux + 2661,
};

static const struct itemplate * const itable_VEX03114[] = {
    instrux + 2735,
    instrux + 2736,
    instrux + 2737,
};

static const struct itemplate * const itable_VEX03115[] = {
    instrux + 2741,
    instrux + 2742,
    instrux + 2743,
};

static const struct itemplate * const itable_VEX03116[] = {
    instrux + 2744,
    instrux + 2745,
    instrux + 2746,
};

static const struct itemplate * const itable_VEX03117[] = {
    instrux + 2470,
};

static const struct itemplate * const itable_VEX03120[] = {
    instrux + 2760,
    instrux + 2761,
    instrux + 2762,
    instrux + 2763,
};

static const struct itemplate * const itable_VEX03121[] = {
    instrux + 2488,
    instrux + 2489,
};

static const struct itemplate * const itable_VEX03122[] = {
    instrux + 2768,
    instrux + 2769,
    instrux + 2770,
    instrux + 2771,
};

static const struct itemplate * const itable_VEX03140[] = {
    instrux + 2465,
    instrux + 2466,
};

static const struct itemplate * const itable_VEX03141[] = {
    instrux + 2463,
    instrux + 2464,
};

static const struct itemplate * const itable_VEX03142[] = {
    instrux + 2611,
    instrux + 2612,
};

static const struct itemplate * const itable_VEX03148[] = {
    instrux + 2718,
    instrux + 2719,
    instrux + 2722,
    instrux + 2723,
    instrux + 2726,
    instrux + 2727,
    instrux + 2730,
    instrux + 2731,
};

static const struct itemplate * const itable_VEX03149[] = {
    instrux + 2698,
    instrux + 2699,
    instrux + 2702,
    instrux + 2703,
    instrux + 2706,
    instrux + 2707,
    instrux + 2710,
    instrux + 2711,
};

static const struct itemplate * const itable_VEX0314A[] = {
    instrux + 2003,
};

static const struct itemplate * const itable_VEX0314B[] = {
    instrux + 1999,
};

static const struct itemplate * const itable_VEX0314C[] = {
    instrux + 2670,
    instrux + 2671,
};

static const struct itemplate * const itable_VEX0315C[] = {
    instrux + 3013,
    instrux + 3014,
};

static const struct itemplate * const itable_VEX0315D[] = {
    instrux + 3009,
    instrux + 3010,
};

static const struct itemplate * const itable_VEX0315E[] = {
    instrux + 3021,
    instrux + 3022,
};

static const struct itemplate * const itable_VEX0315F[] = {
    instrux + 3017,
    instrux + 3018,
};

static const struct itemplate * const itable_VEX03160[] = {
    instrux + 2675,
};

static const struct itemplate * const itable_VEX03161[] = {
    instrux + 2674,
};

static const struct itemplate * const itable_VEX03162[] = {
    instrux + 2677,
};

static const struct itemplate * const itable_VEX03163[] = {
    instrux + 2676,
};

static const struct itemplate * const itable_VEX03168[] = {
    instrux + 3001,
    instrux + 3002,
};

static const struct itemplate * const itable_VEX03169[] = {
    instrux + 2997,
    instrux + 2998,
};

static const struct itemplate * const itable_VEX0316A[] = {
    instrux + 3007,
    instrux + 3008,
};

static const struct itemplate * const itable_VEX0316B[] = {
    instrux + 3005,
    instrux + 3006,
};

static const struct itemplate * const itable_VEX0316C[] = {
    instrux + 3029,
    instrux + 3030,
};

static const struct itemplate * const itable_VEX0316D[] = {
    instrux + 3025,
    instrux + 3026,
};

static const struct itemplate * const itable_VEX0316E[] = {
    instrux + 3035,
    instrux + 3036,
};

static const struct itemplate * const itable_VEX0316F[] = {
    instrux + 3033,
    instrux + 3034,
};

static const struct itemplate * const itable_VEX03178[] = {
    instrux + 3041,
    instrux + 3042,
};

static const struct itemplate * const itable_VEX03179[] = {
    instrux + 3037,
    instrux + 3038,
};

static const struct itemplate * const itable_VEX0317A[] = {
    instrux + 3047,
    instrux + 3048,
};

static const struct itemplate * const itable_VEX0317B[] = {
    instrux + 3045,
    instrux + 3046,
};

static const struct itemplate * const itable_VEX0317C[] = {
    instrux + 3053,
    instrux + 3054,
};

static const struct itemplate * const itable_VEX0317D[] = {
    instrux + 3049,
    instrux + 3050,
};

static const struct itemplate * const itable_VEX0317E[] = {
    instrux + 3059,
    instrux + 3060,
};

static const struct itemplate * const itable_VEX0317F[] = {
    instrux + 3057,
    instrux + 3058,
};

static const struct itemplate * const itable_VEX031DF[] = {
    instrux + 1954,
};

static const struct itemplate * const itable_VEX03504[] = {
    instrux + 2717,
};

static const struct itemplate * const itable_VEX03505[] = {
    instrux + 2697,
};

static const struct itemplate * const itable_VEX03506[] = {
    instrux + 2734,
};

static const struct itemplate * const itable_VEX03508[] = {
    instrux + 2926,
};

static const struct itemplate * const itable_VEX03509[] = {
    instrux + 2924,
};

static const struct itemplate * const itable_VEX0350C[] = {
    instrux + 1997,
    instrux + 1998,
};

static const struct itemplate * const itable_VEX0350D[] = {
    instrux + 1993,
    instrux + 1994,
};

static const struct itemplate * const itable_VEX03518[] = {
    instrux + 2487,
};

static const struct itemplate * const itable_VEX03519[] = {
    instrux + 2469,
};

static const struct itemplate * const itable_VEX03540[] = {
    instrux + 2467,
    instrux + 2468,
};

static const struct itemplate * const itable_VEX03548[] = {
    instrux + 2720,
    instrux + 2721,
    instrux + 2724,
    instrux + 2725,
    instrux + 2728,
    instrux + 2729,
    instrux + 2732,
    instrux + 2733,
};

static const struct itemplate * const itable_VEX03549[] = {
    instrux + 2700,
    instrux + 2701,
    instrux + 2704,
    instrux + 2705,
    instrux + 2708,
    instrux + 2709,
    instrux + 2712,
    instrux + 2713,
};

static const struct itemplate * const itable_VEX0354A[] = {
    instrux + 2005,
};

static const struct itemplate * const itable_VEX0354B[] = {
    instrux + 2001,
};

static const struct itemplate * const itable_VEX0355C[] = {
    instrux + 3015,
    instrux + 3016,
};

static const struct itemplate * const itable_VEX0355D[] = {
    instrux + 3011,
    instrux + 3012,
};

static const struct itemplate * const itable_VEX0355E[] = {
    instrux + 3023,
    instrux + 3024,
};

static const struct itemplate * const itable_VEX0355F[] = {
    instrux + 3019,
    instrux + 3020,
};

static const struct itemplate * const itable_VEX03568[] = {
    instrux + 3003,
    instrux + 3004,
};

static const struct itemplate * const itable_VEX03569[] = {
    instrux + 2999,
    instrux + 3000,
};

static const struct itemplate * const itable_VEX0356C[] = {
    instrux + 3031,
    instrux + 3032,
};

static const struct itemplate * const itable_VEX0356D[] = {
    instrux + 3027,
    instrux + 3028,
};

static const struct itemplate * const itable_VEX03578[] = {
    instrux + 3043,
    instrux + 3044,
};

static const struct itemplate * const itable_VEX03579[] = {
    instrux + 3039,
    instrux + 3040,
};

static const struct itemplate * const itable_VEX0357C[] = {
    instrux + 3055,
    instrux + 3056,
};

static const struct itemplate * const itable_VEX0357D[] = {
    instrux + 3051,
    instrux + 3052,
};

static const struct disasm_index itable_VEX010[256] = {
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX01010, 1 },
    { itable_VEX01011, 1 },
    { itable_VEX01012, 4 },
    { itable_VEX01013, 1 },
    { itable_VEX01014, 2 },
    { itable_VEX01015, 2 },
    { itable_VEX01016, 4 },
    { itable_VEX01017, 1 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX01028, 1 },
    { itable_VEX01029, 1 },
    { NULL, 0 },
    { itable_VEX0102B, 1 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX0102E, 1 },
    { itable_VEX0102F, 1 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX01050, 2 },
    { itable_VEX01051, 1 },
    { itable_VEX01052, 1 },
    { itable_VEX01053, 1 },
    { itable_VEX01054, 2 },
    { itable_VEX01055, 2 },
    { itable_VEX01056, 2 },
    { itable_VEX01057, 2 },
    { itable_VEX01058, 2 },
    { itable_VEX01059, 2 },
    { itable_VEX0105A, 1 },
    { itable_VEX0105B, 1 },
    { itable_VEX0105C, 2 },
    { itable_VEX0105D, 2 },
    { itable_VEX0105E, 2 },
    { itable_VEX0105F, 2 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX01077, 1 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX010AE, 2 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX010C2, 66 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX010C6, 2 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
};

static const struct disasm_index itable_VEX011[256] = {
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX01110, 1 },
    { itable_VEX01111, 1 },
    { itable_VEX01112, 2 },
    { itable_VEX01113, 1 },
    { itable_VEX01114, 2 },
    { itable_VEX01115, 2 },
    { itable_VEX01116, 2 },
    { itable_VEX01117, 1 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX01128, 1 },
    { itable_VEX01129, 3 },
    { NULL, 0 },
    { itable_VEX0112B, 1 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX0112E, 1 },
    { itable_VEX0112F, 1 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX01137, 2 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX01150, 2 },
    { itable_VEX01151, 1 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX01154, 2 },
    { itable_VEX01155, 2 },
    { itable_VEX01156, 2 },
    { itable_VEX01157, 2 },
    { itable_VEX01158, 2 },
    { itable_VEX01159, 2 },
    { itable_VEX0115A, 2 },
    { itable_VEX0115B, 1 },
    { itable_VEX0115C, 2 },
    { itable_VEX0115D, 2 },
    { itable_VEX0115E, 2 },
    { itable_VEX0115F, 2 },
    { itable_VEX01160, 2 },
    { itable_VEX01161, 2 },
    { itable_VEX01162, 2 },
    { itable_VEX01163, 2 },
    { itable_VEX01164, 2 },
    { itable_VEX01165, 2 },
    { itable_VEX01166, 2 },
    { itable_VEX01167, 2 },
    { itable_VEX01168, 2 },
    { itable_VEX01169, 2 },
    { itable_VEX0116A, 2 },
    { itable_VEX0116B, 2 },
    { itable_VEX0116C, 2 },
    { itable_VEX0116D, 2 },
    { itable_VEX0116E, 2 },
    { itable_VEX0116F, 1 },
    { itable_VEX01170, 1 },
    { itable_VEX01171, 6 },
    { itable_VEX01172, 6 },
    { itable_VEX01173, 8 },
    { itable_VEX01174, 2 },
    { itable_VEX01175, 2 },
    { itable_VEX01176, 2 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX0117C, 2 },
    { itable_VEX0117D, 2 },
    { itable_VEX0117E, 2 },
    { itable_VEX0117F, 1 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX011C2, 66 },
    { NULL, 0 },
    { itable_VEX011C4, 4 },
    { itable_VEX011C5, 3 },
    { itable_VEX011C6, 2 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX011D0, 2 },
    { itable_VEX011D1, 2 },
    { itable_VEX011D2, 2 },
    { itable_VEX011D3, 2 },
    { itable_VEX011D4, 2 },
    { itable_VEX011D5, 2 },
    { itable_VEX011D6, 1 },
    { itable_VEX011D7, 2 },
    { itable_VEX011D8, 2 },
    { itable_VEX011D9, 2 },
    { itable_VEX011DA, 2 },
    { itable_VEX011DB, 2 },
    { itable_VEX011DC, 2 },
    { itable_VEX011DD, 2 },
    { itable_VEX011DE, 2 },
    { itable_VEX011DF, 2 },
    { itable_VEX011E0, 2 },
    { itable_VEX011E1, 2 },
    { itable_VEX011E2, 2 },
    { itable_VEX011E3, 2 },
    { itable_VEX011E4, 2 },
    { itable_VEX011E5, 2 },
    { itable_VEX011E6, 2 },
    { itable_VEX011E7, 1 },
    { itable_VEX011E8, 2 },
    { itable_VEX011E9, 2 },
    { itable_VEX011EA, 2 },
    { itable_VEX011EB, 2 },
    { itable_VEX011EC, 2 },
    { itable_VEX011ED, 2 },
    { itable_VEX011EE, 2 },
    { itable_VEX011EF, 2 },
    { NULL, 0 },
    { itable_VEX011F1, 2 },
    { itable_VEX011F2, 2 },
    { itable_VEX011F3, 2 },
    { itable_VEX011F4, 2 },
    { itable_VEX011F5, 2 },
    { itable_VEX011F6, 2 },
    { itable_VEX011F7, 1 },
    { itable_VEX011F8, 2 },
    { itable_VEX011F9, 2 },
    { itable_VEX011FA, 2 },
    { itable_VEX011FB, 2 },
    { itable_VEX011FC, 2 },
    { itable_VEX011FD, 2 },
    { itable_VEX011FE, 2 },
    { NULL, 0 },
};

static const struct disasm_index itable_VEX012[256] = {
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX01210, 3 },
    { itable_VEX01211, 3 },
    { itable_VEX01212, 1 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX01216, 1 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX0122A, 4 },
    { NULL, 0 },
    { itable_VEX0122C, 2 },
    { itable_VEX0122D, 2 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX01251, 2 },
    { itable_VEX01252, 2 },
    { itable_VEX01253, 2 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX01258, 2 },
    { itable_VEX01259, 2 },
    { itable_VEX0125A, 2 },
    { itable_VEX0125B, 1 },
    { itable_VEX0125C, 2 },
    { itable_VEX0125D, 2 },
    { itable_VEX0125E, 2 },
    { itable_VEX0125F, 2 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX0126F, 1 },
    { itable_VEX01270, 1 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX0127E, 1 },
    { itable_VEX0127F, 1 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX012C2, 66 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX012E6, 1 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
};

static const struct disasm_index itable_VEX013[256] = {
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX01310, 3 },
    { itable_VEX01311, 3 },
    { itable_VEX01312, 1 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX0132A, 4 },
    { NULL, 0 },
    { itable_VEX0132C, 2 },
    { itable_VEX0132D, 2 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX01351, 2 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX01358, 2 },
    { itable_VEX01359, 2 },
    { itable_VEX0135A, 2 },
    { NULL, 0 },
    { itable_VEX0135C, 2 },
    { itable_VEX0135D, 2 },
    { itable_VEX0135E, 2 },
    { itable_VEX0135F, 2 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX01370, 1 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX0137C, 2 },
    { itable_VEX0137D, 2 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX013C2, 66 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX013E6, 2 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX013F0, 3 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
};

static const struct disasm_index itable_VEX014[256] = {
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX01410, 1 },
    { itable_VEX01411, 1 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX01414, 2 },
    { itable_VEX01415, 2 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX01428, 1 },
    { itable_VEX01429, 1 },
    { NULL, 0 },
    { itable_VEX0142B, 1 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX01450, 2 },
    { itable_VEX01451, 1 },
    { itable_VEX01452, 1 },
    { itable_VEX01453, 1 },
    { itable_VEX01454, 2 },
    { itable_VEX01455, 2 },
    { itable_VEX01456, 2 },
    { itable_VEX01457, 2 },
    { itable_VEX01458, 2 },
    { itable_VEX01459, 2 },
    { itable_VEX0145A, 1 },
    { itable_VEX0145B, 1 },
    { itable_VEX0145C, 2 },
    { itable_VEX0145D, 2 },
    { itable_VEX0145E, 2 },
    { itable_VEX0145F, 2 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX01477, 1 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX014C2, 66 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX014C6, 2 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
};

static const struct disasm_index itable_VEX015[256] = {
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX01510, 1 },
    { itable_VEX01511, 1 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX01514, 2 },
    { itable_VEX01515, 2 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX01528, 1 },
    { itable_VEX01529, 1 },
    { NULL, 0 },
    { itable_VEX0152B, 1 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX01550, 2 },
    { itable_VEX01551, 1 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX01554, 2 },
    { itable_VEX01555, 2 },
    { itable_VEX01556, 2 },
    { itable_VEX01557, 2 },
    { itable_VEX01558, 2 },
    { itable_VEX01559, 2 },
    { itable_VEX0155A, 2 },
    { itable_VEX0155B, 1 },
    { itable_VEX0155C, 2 },
    { itable_VEX0155D, 2 },
    { itable_VEX0155E, 2 },
    { itable_VEX0155F, 2 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX0156F, 2 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX0157C, 2 },
    { itable_VEX0157D, 2 },
    { NULL, 0 },
    { itable_VEX0157F, 2 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX015C2, 66 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX015C6, 2 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX015D0, 2 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX015E6, 2 },
    { itable_VEX015E7, 2 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
};

static const struct disasm_index itable_VEX016[256] = {
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX01612, 1 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX01616, 1 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX0165B, 1 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX0166F, 2 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX0167F, 2 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX016E6, 1 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
};

static const struct disasm_index itable_VEX017[256] = {
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX01712, 1 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX0177C, 2 },
    { itable_VEX0177D, 2 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX017E6, 2 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX017F0, 4 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
};

static const struct disasm_index itable_VEX021[256] = {
    { itable_VEX02100, 2 },
    { itable_VEX02101, 2 },
    { itable_VEX02102, 2 },
    { itable_VEX02103, 2 },
    { itable_VEX02104, 2 },
    { itable_VEX02105, 2 },
    { itable_VEX02106, 2 },
    { itable_VEX02107, 2 },
    { itable_VEX02108, 2 },
    { itable_VEX02109, 2 },
    { itable_VEX0210A, 2 },
    { itable_VEX0210B, 2 },
    { itable_VEX0210C, 1 },
    { itable_VEX0210D, 1 },
    { itable_VEX0210E, 1 },
    { itable_VEX0210F, 1 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX02114, 1 },
    { itable_VEX02115, 1 },
    { NULL, 0 },
    { itable_VEX02117, 1 },
    { itable_VEX02118, 1 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX0211C, 1 },
    { itable_VEX0211D, 1 },
    { itable_VEX0211E, 1 },
    { NULL, 0 },
    { itable_VEX02120, 1 },
    { itable_VEX02121, 1 },
    { itable_VEX02122, 1 },
    { itable_VEX02123, 1 },
    { itable_VEX02124, 1 },
    { itable_VEX02125, 1 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX02128, 2 },
    { NULL, 0 },
    { itable_VEX0212A, 1 },
    { itable_VEX0212B, 2 },
    { itable_VEX0212C, 1 },
    { itable_VEX0212D, 1 },
    { itable_VEX0212E, 1 },
    { itable_VEX0212F, 1 },
    { itable_VEX02130, 1 },
    { itable_VEX02131, 1 },
    { itable_VEX02132, 1 },
    { itable_VEX02133, 1 },
    { itable_VEX02134, 1 },
    { itable_VEX02135, 1 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX02138, 2 },
    { itable_VEX02139, 2 },
    { itable_VEX0213A, 2 },
    { itable_VEX0213B, 2 },
    { itable_VEX0213C, 2 },
    { itable_VEX0213D, 2 },
    { itable_VEX0213E, 2 },
    { itable_VEX0213F, 2 },
    { itable_VEX02140, 2 },
    { itable_VEX02141, 1 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX021DB, 1 },
    { itable_VEX021DC, 2 },
    { itable_VEX021DD, 2 },
    { itable_VEX021DE, 2 },
    { itable_VEX021DF, 2 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
};

static const struct disasm_index itable_VEX025[256] = {
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX0250C, 1 },
    { itable_VEX0250D, 1 },
    { itable_VEX0250E, 1 },
    { itable_VEX0250F, 1 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX02514, 1 },
    { itable_VEX02515, 1 },
    { NULL, 0 },
    { itable_VEX02517, 1 },
    { itable_VEX02518, 1 },
    { itable_VEX02519, 1 },
    { itable_VEX0251A, 1 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX0252C, 1 },
    { itable_VEX0252D, 1 },
    { itable_VEX0252E, 1 },
    { itable_VEX0252F, 1 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
};

static const struct disasm_index itable_VEX031[256] = {
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX03104, 1 },
    { itable_VEX03105, 1 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX03108, 1 },
    { itable_VEX03109, 1 },
    { itable_VEX0310A, 2 },
    { itable_VEX0310B, 2 },
    { itable_VEX0310C, 2 },
    { itable_VEX0310D, 2 },
    { itable_VEX0310E, 2 },
    { itable_VEX0310F, 2 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX03114, 3 },
    { itable_VEX03115, 3 },
    { itable_VEX03116, 3 },
    { itable_VEX03117, 1 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX03120, 4 },
    { itable_VEX03121, 2 },
    { itable_VEX03122, 4 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX03140, 2 },
    { itable_VEX03141, 2 },
    { itable_VEX03142, 2 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX03148, 8 },
    { itable_VEX03149, 8 },
    { itable_VEX0314A, 1 },
    { itable_VEX0314B, 1 },
    { itable_VEX0314C, 2 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX0315C, 2 },
    { itable_VEX0315D, 2 },
    { itable_VEX0315E, 2 },
    { itable_VEX0315F, 2 },
    { itable_VEX03160, 1 },
    { itable_VEX03161, 1 },
    { itable_VEX03162, 1 },
    { itable_VEX03163, 1 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX03168, 2 },
    { itable_VEX03169, 2 },
    { itable_VEX0316A, 2 },
    { itable_VEX0316B, 2 },
    { itable_VEX0316C, 2 },
    { itable_VEX0316D, 2 },
    { itable_VEX0316E, 2 },
    { itable_VEX0316F, 2 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX03178, 2 },
    { itable_VEX03179, 2 },
    { itable_VEX0317A, 2 },
    { itable_VEX0317B, 2 },
    { itable_VEX0317C, 2 },
    { itable_VEX0317D, 2 },
    { itable_VEX0317E, 2 },
    { itable_VEX0317F, 2 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX031DF, 1 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
};

static const struct disasm_index itable_VEX035[256] = {
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX03504, 1 },
    { itable_VEX03505, 1 },
    { itable_VEX03506, 1 },
    { NULL, 0 },
    { itable_VEX03508, 1 },
    { itable_VEX03509, 1 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX0350C, 2 },
    { itable_VEX0350D, 2 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX03518, 1 },
    { itable_VEX03519, 1 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX03540, 2 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX03548, 8 },
    { itable_VEX03549, 8 },
    { itable_VEX0354A, 1 },
    { itable_VEX0354B, 1 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX0355C, 2 },
    { itable_VEX0355D, 2 },
    { itable_VEX0355E, 2 },
    { itable_VEX0355F, 2 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX03568, 2 },
    { itable_VEX03569, 2 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX0356C, 2 },
    { itable_VEX0356D, 2 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX03578, 2 },
    { itable_VEX03579, 2 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_VEX0357C, 2 },
    { itable_VEX0357D, 2 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
};

static const struct disasm_index itable_0F24[256] = {
    { itable_0F2400, 2 },
    { itable_0F2401, 2 },
    { itable_0F2402, 2 },
    { itable_0F2403, 2 },
    { itable_0F2404, 2 },
    { itable_0F2405, 2 },
    { itable_0F2406, 2 },
    { itable_0F2407, 2 },
    { itable_0F2408, 2 },
    { itable_0F2409, 2 },
    { itable_0F240A, 2 },
    { itable_0F240B, 2 },
    { itable_0F240C, 2 },
    { itable_0F240D, 2 },
    { itable_0F240E, 2 },
    { itable_0F240F, 2 },
    { itable_0F2410, 2 },
    { itable_0F2411, 2 },
    { itable_0F2412, 2 },
    { itable_0F2413, 2 },
    { itable_0F2414, 2 },
    { itable_0F2415, 2 },
    { itable_0F2416, 2 },
    { itable_0F2417, 2 },
    { itable_0F2418, 2 },
    { itable_0F2419, 2 },
    { itable_0F241A, 2 },
    { itable_0F241B, 2 },
    { itable_0F241C, 2 },
    { itable_0F241D, 2 },
    { itable_0F241E, 2 },
    { itable_0F241F, 2 },
    { itable_0F2420, 2 },
    { itable_0F2421, 2 },
    { itable_0F2422, 2 },
    { itable_0F2423, 2 },
    { itable_0F2424, 2 },
    { itable_0F2425, 2 },
    { itable_0F2426, 2 },
    { itable_0F2427, 2 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_0F2440, 2 },
    { itable_0F2441, 2 },
    { itable_0F2442, 2 },
    { itable_0F2443, 2 },
    { itable_0F2444, 2 },
    { itable_0F2445, 2 },
    { itable_0F2446, 2 },
    { itable_0F2447, 2 },
    { itable_0F2448, 2 },
    { itable_0F2449, 2 },
    { itable_0F244A, 2 },
    { itable_0F244B, 2 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_0F2485, 1 },
    { itable_0F2486, 1 },
    { itable_0F2487, 1 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_0F248E, 1 },
    { itable_0F248F, 1 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_0F2495, 1 },
    { itable_0F2496, 1 },
    { itable_0F2497, 1 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_0F249E, 1 },
    { itable_0F249F, 1 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_0F24A6, 1 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_0F24B6, 1 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
};

static const struct disasm_index itable_0F25[256] = {
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_0F252C, 17 },
    { itable_0F252D, 17 },
    { itable_0F252E, 17 },
    { itable_0F252F, 17 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_0F254C, 9 },
    { itable_0F254D, 9 },
    { itable_0F254E, 9 },
    { itable_0F254F, 9 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_0F256C, 9 },
    { itable_0F256D, 9 },
    { itable_0F256E, 9 },
    { itable_0F256F, 9 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
};

static const struct disasm_index itable_0F38[256] = {
    { itable_0F3800, 2 },
    { itable_0F3801, 2 },
    { itable_0F3802, 2 },
    { itable_0F3803, 2 },
    { itable_0F3804, 2 },
    { itable_0F3805, 2 },
    { itable_0F3806, 2 },
    { itable_0F3807, 2 },
    { itable_0F3808, 2 },
    { itable_0F3809, 2 },
    { itable_0F380A, 2 },
    { itable_0F380B, 2 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_0F3810, 1 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_0F3814, 1 },
    { itable_0F3815, 1 },
    { NULL, 0 },
    { itable_0F3817, 1 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_0F381C, 2 },
    { itable_0F381D, 2 },
    { itable_0F381E, 2 },
    { NULL, 0 },
    { itable_0F3820, 1 },
    { itable_0F3821, 1 },
    { itable_0F3822, 1 },
    { itable_0F3823, 1 },
    { itable_0F3824, 1 },
    { itable_0F3825, 1 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_0F3828, 1 },
    { itable_0F3829, 1 },
    { itable_0F382A, 1 },
    { itable_0F382B, 1 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_0F3830, 1 },
    { itable_0F3831, 1 },
    { itable_0F3832, 1 },
    { itable_0F3833, 1 },
    { itable_0F3834, 1 },
    { itable_0F3835, 1 },
    { NULL, 0 },
    { itable_0F3837, 1 },
    { itable_0F3838, 1 },
    { itable_0F3839, 1 },
    { itable_0F383A, 1 },
    { itable_0F383B, 1 },
    { itable_0F383C, 1 },
    { itable_0F383D, 1 },
    { itable_0F383E, 1 },
    { itable_0F383F, 1 },
    { itable_0F3840, 1 },
    { itable_0F3841, 1 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_0F3880, 2 },
    { itable_0F3881, 2 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_0F38DB, 1 },
    { itable_0F38DC, 1 },
    { itable_0F38DD, 1 },
    { itable_0F38DE, 1 },
    { itable_0F38DF, 1 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_0F38F0, 5 },
    { itable_0F38F1, 6 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
};

static const struct disasm_index itable_0F3A[256] = {
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_0F3A08, 5 },
    { itable_0F3A09, 1 },
    { itable_0F3A0A, 1 },
    { itable_0F3A0B, 1 },
    { itable_0F3A0C, 1 },
    { itable_0F3A0D, 1 },
    { itable_0F3A0E, 1 },
    { itable_0F3A0F, 2 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_0F3A14, 3 },
    { itable_0F3A15, 3 },
    { itable_0F3A16, 2 },
    { itable_0F3A17, 2 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_0F3A20, 2 },
    { itable_0F3A21, 1 },
    { itable_0F3A22, 2 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_0F3A40, 1 },
    { itable_0F3A41, 1 },
    { itable_0F3A42, 1 },
    { NULL, 0 },
    { itable_0F3A44, 5 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_0F3A60, 1 },
    { itable_0F3A61, 1 },
    { itable_0F3A62, 1 },
    { itable_0F3A63, 1 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_0F3ADF, 1 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
};

static const struct disasm_index itable_0F7A[256] = {
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_0F7A10, 1 },
    { itable_0F7A11, 1 },
    { itable_0F7A12, 1 },
    { itable_0F7A13, 1 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_0F7A30, 1 },
    { itable_0F7A31, 1 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_0F7A41, 1 },
    { itable_0F7A42, 1 },
    { itable_0F7A43, 1 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_0F7A46, 1 },
    { itable_0F7A47, 1 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_0F7A4B, 1 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_0F7A51, 1 },
    { itable_0F7A52, 1 },
    { itable_0F7A53, 1 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_0F7A56, 1 },
    { itable_0F7A57, 1 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_0F7A5B, 1 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_0F7A61, 1 },
    { itable_0F7A62, 1 },
    { itable_0F7A63, 1 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
};

static const struct disasm_index itable_0FA6[256] = {
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_0FA6C0, 1 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_0FA6C8, 1 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_0FA6D0, 1 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
};

static const struct disasm_index itable_0FA7[256] = {
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_0FA7C0, 1 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_0FA7C8, 1 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_0FA7D0, 1 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_0FA7D8, 1 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_0FA7E0, 1 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_0FA7E8, 1 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
};

static const struct disasm_index itable_0F[256] = {
    { itable_0F00, 24 },
    { itable_0F01, 33 },
    { itable_0F02, 10 },
    { itable_0F03, 10 },
    { NULL, 0 },
    { itable_0F05, 2 },
    { itable_0F06, 1 },
    { itable_0F07, 2 },
    { itable_0F08, 1 },
    { itable_0F09, 1 },
    { NULL, 0 },
    { itable_0F0B, 1 },
    { NULL, 0 },
    { itable_0F0D, 2 },
    { itable_0F0E, 1 },
    { itable_0F0F, 26 },
    { itable_0F10, 8 },
    { itable_0F11, 8 },
    { itable_0F12, 5 },
    { itable_0F13, 2 },
    { itable_0F14, 2 },
    { itable_0F15, 2 },
    { itable_0F16, 4 },
    { itable_0F17, 2 },
    { itable_0F18, 28 },
    { itable_0F19, 24 },
    { itable_0F1A, 24 },
    { itable_0F1B, 24 },
    { itable_0F1C, 24 },
    { itable_0F1D, 24 },
    { itable_0F1E, 24 },
    { itable_0F1F, 27 },
    { itable_0F20, 2 },
    { itable_0F21, 2 },
    { itable_0F22, 2 },
    { itable_0F23, 2 },
    { itable_0F24, -1 },
    { itable_0F25, -1 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_0F28, 4 },
    { itable_0F29, 4 },
    { itable_0F2A, 6 },
    { itable_0F2B, 4 },
    { itable_0F2C, 8 },
    { itable_0F2D, 10 },
    { itable_0F2E, 2 },
    { itable_0F2F, 2 },
    { itable_0F30, 1 },
    { itable_0F31, 1 },
    { itable_0F32, 1 },
    { itable_0F33, 1 },
    { itable_0F34, 1 },
    { itable_0F35, 1 },
    { itable_0F36, 1 },
    { itable_0F37, 2 },
    { itable_0F38, -1 },
    { itable_0F39, 1 },
    { itable_0F3A, -1 },
    { NULL, 0 },
    { itable_0F3C, 1 },
    { itable_0F3D, 1 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_0F40, 6 },
    { itable_0F41, 6 },
    { itable_0F42, 6 },
    { itable_0F43, 6 },
    { itable_0F44, 6 },
    { itable_0F45, 6 },
    { itable_0F46, 6 },
    { itable_0F47, 6 },
    { itable_0F48, 6 },
    { itable_0F49, 6 },
    { itable_0F4A, 6 },
    { itable_0F4B, 6 },
    { itable_0F4C, 6 },
    { itable_0F4D, 6 },
    { itable_0F4E, 6 },
    { itable_0F4F, 6 },
    { itable_0F50, 5 },
    { itable_0F51, 5 },
    { itable_0F52, 3 },
    { itable_0F53, 2 },
    { itable_0F54, 3 },
    { itable_0F55, 3 },
    { itable_0F56, 2 },
    { itable_0F57, 2 },
    { itable_0F58, 5 },
    { itable_0F59, 5 },
    { itable_0F5A, 5 },
    { itable_0F5B, 4 },
    { itable_0F5C, 5 },
    { itable_0F5D, 5 },
    { itable_0F5E, 5 },
    { itable_0F5F, 4 },
    { itable_0F60, 2 },
    { itable_0F61, 2 },
    { itable_0F62, 2 },
    { itable_0F63, 2 },
    { itable_0F64, 2 },
    { itable_0F65, 2 },
    { itable_0F66, 2 },
    { itable_0F67, 2 },
    { itable_0F68, 2 },
    { itable_0F69, 2 },
    { itable_0F6A, 2 },
    { itable_0F6B, 2 },
    { itable_0F6C, 1 },
    { itable_0F6D, 1 },
    { itable_0F6E, 8 },
    { itable_0F6F, 5 },
    { itable_0F70, 7 },
    { itable_0F71, 6 },
    { itable_0F72, 6 },
    { itable_0F73, 6 },
    { itable_0F74, 2 },
    { itable_0F75, 2 },
    { itable_0F76, 2 },
    { itable_0F77, 1 },
    { itable_0F78, 5 },
    { itable_0F79, 5 },
    { itable_0F7A, -1 },
    { itable_0F7B, 5 },
    { itable_0F7C, 3 },
    { itable_0F7D, 3 },
    { itable_0F7E, 10 },
    { itable_0F7F, 5 },
    { itable_0F80, 3 },
    { itable_0F81, 3 },
    { itable_0F82, 3 },
    { itable_0F83, 3 },
    { itable_0F84, 3 },
    { itable_0F85, 3 },
    { itable_0F86, 3 },
    { itable_0F87, 3 },
    { itable_0F88, 3 },
    { itable_0F89, 3 },
    { itable_0F8A, 3 },
    { itable_0F8B, 3 },
    { itable_0F8C, 3 },
    { itable_0F8D, 3 },
    { itable_0F8E, 3 },
    { itable_0F8F, 3 },
    { itable_0F90, 2 },
    { itable_0F91, 2 },
    { itable_0F92, 2 },
    { itable_0F93, 2 },
    { itable_0F94, 2 },
    { itable_0F95, 2 },
    { itable_0F96, 2 },
    { itable_0F97, 2 },
    { itable_0F98, 2 },
    { itable_0F99, 2 },
    { itable_0F9A, 2 },
    { itable_0F9B, 2 },
    { itable_0F9C, 2 },
    { itable_0F9D, 2 },
    { itable_0F9E, 2 },
    { itable_0F9F, 2 },
    { itable_0FA0, 1 },
    { itable_0FA1, 1 },
    { itable_0FA2, 1 },
    { itable_0FA3, 6 },
    { itable_0FA4, 6 },
    { itable_0FA5, 6 },
    { itable_0FA6, -1 },
    { itable_0FA7, -1 },
    { itable_0FA8, 1 },
    { itable_0FA9, 1 },
    { itable_0FAA, 1 },
    { itable_0FAB, 6 },
    { itable_0FAC, 6 },
    { itable_0FAD, 6 },
    { itable_0FAE, 13 },
    { itable_0FAF, 6 },
    { itable_0FB0, 2 },
    { itable_0FB1, 6 },
    { itable_0FB2, 2 },
    { itable_0FB3, 6 },
    { itable_0FB4, 2 },
    { itable_0FB5, 2 },
    { itable_0FB6, 4 },
    { itable_0FB7, 2 },
    { itable_0FB8, 6 },
    { itable_0FB9, 1 },
    { itable_0FBA, 12 },
    { itable_0FBB, 6 },
    { itable_0FBC, 6 },
    { itable_0FBD, 9 },
    { itable_0FBE, 4 },
    { itable_0FBF, 2 },
    { itable_0FC0, 2 },
    { itable_0FC1, 6 },
    { itable_0FC2, 38 },
    { itable_0FC3, 2 },
    { itable_0FC4, 4 },
    { itable_0FC5, 2 },
    { itable_0FC6, 4 },
    { itable_0FC7, 6 },
    { itable_0FC8, 2 },
    { itable_0FC9, 2 },
    { itable_0FCA, 2 },
    { itable_0FCB, 2 },
    { itable_0FCC, 2 },
    { itable_0FCD, 2 },
    { itable_0FCE, 2 },
    { itable_0FCF, 2 },
    { itable_0FD0, 2 },
    { itable_0FD1, 2 },
    { itable_0FD2, 2 },
    { itable_0FD3, 2 },
    { itable_0FD4, 2 },
    { itable_0FD5, 2 },
    { itable_0FD6, 4 },
    { itable_0FD7, 2 },
    { itable_0FD8, 2 },
    { itable_0FD9, 2 },
    { itable_0FDA, 2 },
    { itable_0FDB, 2 },
    { itable_0FDC, 2 },
    { itable_0FDD, 2 },
    { itable_0FDE, 2 },
    { itable_0FDF, 2 },
    { itable_0FE0, 2 },
    { itable_0FE1, 2 },
    { itable_0FE2, 2 },
    { itable_0FE3, 2 },
    { itable_0FE4, 2 },
    { itable_0FE5, 2 },
    { itable_0FE6, 3 },
    { itable_0FE7, 2 },
    { itable_0FE8, 2 },
    { itable_0FE9, 2 },
    { itable_0FEA, 2 },
    { itable_0FEB, 2 },
    { itable_0FEC, 2 },
    { itable_0FED, 2 },
    { itable_0FEE, 2 },
    { itable_0FEF, 2 },
    { itable_0FF0, 1 },
    { itable_0FF1, 2 },
    { itable_0FF2, 2 },
    { itable_0FF3, 2 },
    { itable_0FF4, 2 },
    { itable_0FF5, 2 },
    { itable_0FF6, 2 },
    { itable_0FF7, 2 },
    { itable_0FF8, 2 },
    { itable_0FF9, 2 },
    { itable_0FFA, 2 },
    { itable_0FFB, 2 },
    { itable_0FFC, 2 },
    { itable_0FFD, 2 },
    { itable_0FFE, 2 },
    { itable_0FFF, 1 },
};

const struct disasm_index itable[256] = {
    { itable_00, 2 },
    { itable_01, 6 },
    { itable_02, 2 },
    { itable_03, 6 },
    { itable_04, 1 },
    { itable_05, 3 },
    { itable_06, 2 },
    { itable_07, 1 },
    { itable_08, 2 },
    { itable_09, 6 },
    { itable_0A, 2 },
    { itable_0B, 6 },
    { itable_0C, 1 },
    { itable_0D, 3 },
    { itable_0E, 2 },
    { itable_0F, -1 },
    { itable_10, 2 },
    { itable_11, 6 },
    { itable_12, 2 },
    { itable_13, 6 },
    { itable_14, 1 },
    { itable_15, 3 },
    { itable_16, 2 },
    { itable_17, 1 },
    { itable_18, 2 },
    { itable_19, 6 },
    { itable_1A, 2 },
    { itable_1B, 6 },
    { itable_1C, 1 },
    { itable_1D, 3 },
    { itable_1E, 2 },
    { itable_1F, 1 },
    { itable_20, 2 },
    { itable_21, 6 },
    { itable_22, 2 },
    { itable_23, 6 },
    { itable_24, 1 },
    { itable_25, 3 },
    { NULL, 0 },
    { itable_27, 1 },
    { itable_28, 2 },
    { itable_29, 6 },
    { itable_2A, 2 },
    { itable_2B, 6 },
    { itable_2C, 1 },
    { itable_2D, 3 },
    { NULL, 0 },
    { itable_2F, 1 },
    { itable_30, 2 },
    { itable_31, 6 },
    { itable_32, 2 },
    { itable_33, 6 },
    { itable_34, 1 },
    { itable_35, 3 },
    { NULL, 0 },
    { itable_37, 1 },
    { itable_38, 2 },
    { itable_39, 6 },
    { itable_3A, 2 },
    { itable_3B, 6 },
    { itable_3C, 1 },
    { itable_3D, 3 },
    { NULL, 0 },
    { itable_3F, 1 },
    { itable_40, 2 },
    { itable_41, 2 },
    { itable_42, 2 },
    { itable_43, 2 },
    { itable_44, 2 },
    { itable_45, 2 },
    { itable_46, 2 },
    { itable_47, 2 },
    { itable_48, 2 },
    { itable_49, 2 },
    { itable_4A, 2 },
    { itable_4B, 2 },
    { itable_4C, 2 },
    { itable_4D, 2 },
    { itable_4E, 2 },
    { itable_4F, 2 },
    { itable_50, 3 },
    { itable_51, 3 },
    { itable_52, 3 },
    { itable_53, 3 },
    { itable_54, 3 },
    { itable_55, 3 },
    { itable_56, 3 },
    { itable_57, 3 },
    { itable_58, 3 },
    { itable_59, 3 },
    { itable_5A, 3 },
    { itable_5B, 3 },
    { itable_5C, 3 },
    { itable_5D, 3 },
    { itable_5E, 3 },
    { itable_5F, 3 },
    { itable_60, 3 },
    { itable_61, 3 },
    { itable_62, 2 },
    { itable_63, 3 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_68, 4 },
    { itable_69, 9 },
    { itable_6A, 5 },
    { itable_6B, 9 },
    { itable_6C, 1 },
    { itable_6D, 2 },
    { itable_6E, 1 },
    { itable_6F, 2 },
    { itable_70, 1 },
    { itable_71, 1 },
    { itable_72, 1 },
    { itable_73, 1 },
    { itable_74, 1 },
    { itable_75, 1 },
    { itable_76, 1 },
    { itable_77, 1 },
    { itable_78, 1 },
    { itable_79, 1 },
    { itable_7A, 1 },
    { itable_7B, 1 },
    { itable_7C, 1 },
    { itable_7D, 1 },
    { itable_7E, 1 },
    { itable_7F, 1 },
    { itable_80, 16 },
    { itable_81, 40 },
    { NULL, 0 },
    { itable_83, 64 },
    { itable_84, 3 },
    { itable_85, 9 },
    { itable_86, 4 },
    { itable_87, 12 },
    { itable_88, 2 },
    { itable_89, 6 },
    { itable_8A, 2 },
    { itable_8B, 6 },
    { itable_8C, 3 },
    { itable_8D, 3 },
    { itable_8E, 3 },
    { itable_8F, 3 },
    { itable_90, 9 },
    { itable_91, 6 },
    { itable_92, 6 },
    { itable_93, 6 },
    { itable_94, 6 },
    { itable_95, 6 },
    { itable_96, 6 },
    { itable_97, 6 },
    { itable_98, 3 },
    { itable_99, 3 },
    { itable_9A, 5 },
    { itable_9B, 11 },
    { itable_9C, 4 },
    { itable_9D, 4 },
    { itable_9E, 1 },
    { itable_9F, 1 },
    { itable_A0, 1 },
    { itable_A1, 3 },
    { itable_A2, 1 },
    { itable_A3, 3 },
    { itable_A4, 1 },
    { itable_A5, 3 },
    { itable_A6, 1 },
    { itable_A7, 3 },
    { itable_A8, 1 },
    { itable_A9, 3 },
    { itable_AA, 1 },
    { itable_AB, 3 },
    { itable_AC, 1 },
    { itable_AD, 3 },
    { itable_AE, 1 },
    { itable_AF, 3 },
    { itable_B0, 1 },
    { itable_B1, 1 },
    { itable_B2, 1 },
    { itable_B3, 1 },
    { itable_B4, 1 },
    { itable_B5, 1 },
    { itable_B6, 1 },
    { itable_B7, 1 },
    { itable_B8, 3 },
    { itable_B9, 3 },
    { itable_BA, 3 },
    { itable_BB, 3 },
    { itable_BC, 3 },
    { itable_BD, 3 },
    { itable_BE, 3 },
    { itable_BF, 3 },
    { itable_C0, 7 },
    { itable_C1, 21 },
    { itable_C2, 2 },
    { itable_C3, 2 },
    { itable_C4, 2 },
    { itable_C5, 2 },
    { itable_C6, 2 },
    { itable_C7, 6 },
    { itable_C8, 1 },
    { itable_C9, 1 },
    { itable_CA, 1 },
    { itable_CB, 1 },
    { itable_CC, 1 },
    { itable_CD, 1 },
    { itable_CE, 1 },
    { itable_CF, 4 },
    { itable_D0, 7 },
    { itable_D1, 21 },
    { itable_D2, 7 },
    { itable_D3, 21 },
    { itable_D4, 2 },
    { itable_D5, 2 },
    { itable_D6, 1 },
    { itable_D7, 2 },
    { itable_D8, 24 },
    { itable_D9, 39 },
    { itable_DA, 17 },
    { itable_DB, 23 },
    { itable_DC, 20 },
    { itable_DD, 15 },
    { itable_DE, 21 },
    { itable_DF, 17 },
    { itable_E0, 8 },
    { itable_E1, 8 },
    { itable_E2, 4 },
    { itable_E3, 3 },
    { itable_E4, 1 },
    { itable_E5, 2 },
    { itable_E6, 1 },
    { itable_E7, 2 },
    { itable_E8, 6 },
    { itable_E9, 3 },
    { itable_EA, 5 },
    { itable_EB, 1 },
    { itable_EC, 1 },
    { itable_ED, 2 },
    { itable_EE, 1 },
    { itable_EF, 2 },
    { NULL, 0 },
    { itable_F1, 2 },
    { NULL, 0 },
    { NULL, 0 },
    { itable_F4, 1 },
    { itable_F5, 1 },
    { itable_F6, 8 },
    { itable_F7, 23 },
    { itable_F8, 1 },
    { itable_F9, 1 },
    { itable_FA, 1 },
    { itable_FB, 1 },
    { itable_FC, 1 },
    { itable_FD, 1 },
    { itable_FE, 2 },
    { itable_FF, 41 },
};

const struct disasm_index * const itable_VEX[32][8] = {
    {
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
    }, {
        itable_VEX010,
        itable_VEX011,
        itable_VEX012,
        itable_VEX013,
        itable_VEX014,
        itable_VEX015,
        itable_VEX016,
        itable_VEX017,
    }, {
        NULL,
        itable_VEX021,
        NULL,
        NULL,
        NULL,
        itable_VEX025,
        NULL,
        NULL,
    }, {
        NULL,
        itable_VEX031,
        NULL,
        NULL,
        NULL,
        itable_VEX035,
        NULL,
        NULL,
    }, {
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
    }, {
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
    }, {
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
    }, {
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
    }, {
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
    }, {
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
    }, {
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
    }, {
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
    }, {
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
    }, {
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
    }, {
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
    }, {
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
    }, {
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
    }, {
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
    }, {
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
    }, {
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
    }, {
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
    }, {
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
    }, {
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
    }, {
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
    }, {
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
    }, {
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
    }, {
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
    }, {
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
    }, {
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
    }, {
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
    }, {
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
    }, {
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
    },
};
